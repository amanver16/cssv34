#include <sourcemod>
#include <sdktools>
#include <clientprefs>

#pragma semicolon 1
#define PAINTBALL_VERSION "1.2.1"

public Plugin myinfo = 
{
    name = "Paintball",
    author = "otstrel.ru Team, Vertigo™",
    description = "Add paintball impacts on the map after shots.",
    version = PAINTBALL_VERSION,
    url = "otstrel.ru"
}

int g_SpriteIndex[128];
int g_SpriteIndexCount = 0;
int g_clientPrefs[MAXPLAYERS+1];
int g_clientsPaintballEnabled[MAXPLAYERS];
int g_clientsPaintballEnabledTotal = 0;

ConVar g_Cvar_PrefDefault = null;
ConVar g_Cvar_Plugin = null;

Handle g_Cookie_Pref = null;

bool g_bPluginEnabled = false;

public void OnPluginStart()
{
    LoadTranslations("paintball.phrases");
    ConVar Cvar_Version = CreateConVar("sm_paintball_version", PAINTBALL_VERSION, "Paintball Version.", 0|FCVAR_SPONLY|FCVAR_REPLICATED|FCVAR_NOTIFY|FCVAR_DONTRECORD);
    // KLUGE: Update version cvar if plugin updated on map change.
    SetConVarString(Cvar_Version, PAINTBALL_VERSION);
    g_Cvar_PrefDefault = CreateConVar("sm_paintball_prefdefault", "1", "Default setting for new users.");
    g_Cvar_Plugin = CreateConVar("sm_paintball_enabled", "1", "Enable/Disable plugin. (0 = Disabled, 1 = Enabled)", _, true, 0.0, true, 1.0);
    g_Cookie_Pref = RegClientCookie("sm_paintball_pref", "Paintball pref", CookieAccess_Private);
    g_bPluginEnabled = g_Cvar_Plugin.BoolValue;
    g_Cvar_Plugin.AddChangeHook(OnCvarPluginEnabledChanged);

    RegConsoleCmd("sm_paintball", MenuPaintball, "Show paintball settings menu.");
    HookEvent("bullet_impact", Event_BulletImpact);
}

public void OnCvarPluginEnabledChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
    g_bPluginEnabled = cvar.BoolValue;
}
    
public void OnMapStart()
{
    if(g_bPluginEnabled)
    {
        g_SpriteIndexCount = 0;
        // Load config file with colors
        KeyValues KvColors = CreateKeyValues("colors");
        char ConfigFile[PLATFORM_MAX_PATH];
        BuildPath(Path_SM, ConfigFile, sizeof(ConfigFile), "configs/paintball.cfg");

        if(!FileToKeyValues(KvColors, ConfigFile))
        {
            delete KvColors;
            LogError("[ERROR] paintball can not convert file to keyvalues: %s", ConfigFile);
            return;
        }

        // Find first color section
        KvRewind(KvColors);
        bool sectionExists;
        sectionExists = KvGotoFirstSubKey(KvColors);
        
        if(!sectionExists)
        {
            delete KvColors;
            LogError("[ERROR] paintball can not find first keyvalues subkey in file: %s", ConfigFile);
            return;
        }

        char filename[PLATFORM_MAX_PATH];

        // Load all colors
        while(sectionExists)
        {
            if(KvGetNum(KvColors, "enabled"))
            {
                KvGetString(KvColors, "primary", filename, sizeof(filename));
                g_SpriteIndex[g_SpriteIndexCount++] = precachePaintballDecal(filename);
                KvGetString(KvColors, "secondary", filename, sizeof(filename));
                precachePaintballDecal(filename);
            }
            sectionExists = KvGotoNextKey(KvColors);
        }
    
        delete KvColors;
    }
}

stock int precachePaintballDecal(const char[] filename)
{
    char tmpPath[PLATFORM_MAX_PATH];
    int result = 0;
    result = PrecacheDecal(filename, true);
    Format(tmpPath,sizeof(tmpPath),"materials/%s",filename);
    AddFileToDownloadsTable(tmpPath);
    return result;
}

public Action Event_BulletImpact(Event event, const char[] weaponName, bool dontBroadcast)
{
    if(g_bPluginEnabled)
    {    
        float pos[3];
        pos[0] = GetEventFloat(event,"x");
        pos[1] = GetEventFloat(event,"y");
        pos[2] = GetEventFloat(event,"z");

        if(g_clientsPaintballEnabledTotal && g_SpriteIndexCount)
        {
            // Setup new decal
            TE_SetupWorldDecal(pos, g_SpriteIndex[GetRandomInt(0, g_SpriteIndexCount - 1)]);
            TE_Send(g_clientsPaintballEnabled, g_clientsPaintballEnabledTotal);
        }
    }  
}

stock void TE_SetupWorldDecal(const float vecOrigin[3], int index)
{    
    TE_Start("World Decal");
    TE_WriteVector("m_vecOrigin",vecOrigin);
    TE_WriteNum("m_nIndex",index);
}

public Action MenuPaintball(int client, int args)
{
    if(g_bPluginEnabled)
    {
        Menu menu = CreateMenu(MenuHandlerPaintball);
        char buffer[64];
        Format(buffer, sizeof(buffer), "%t", "Paintball settings");
        SetMenuTitle(menu, buffer);
        Format(buffer, sizeof(buffer), "%t %t", "Show paintball impacts", g_clientPrefs[client] ? "Selected" : "NotSelected");
        AddMenuItem(menu, "Show paintball impacts", buffer);
        SetMenuExitButton(menu, true);
        DisplayMenu(menu, client, 20);
    }
    else
    {
        ReplyToCommand(client, "%t", "Plugin Disabled");
    }

    return Plugin_Handled;
}

public int MenuHandlerPaintball(Menu menu, MenuAction action, int client, int item)
{
    if(action == MenuAction_Select) 
    {
        if(item == 0)
        {
            g_clientPrefs[client] = g_clientPrefs[client] ? 0 : 1;
            char buffer[5];
            IntToString(g_clientPrefs[client], buffer, 5);
            SetClientCookie(client, g_Cookie_Pref, buffer);
            recalculateClients(0);
            MenuPaintball(client, 0);
        }
    } 
    else if(action == MenuAction_End)
    {
        delete menu;
    }
}

public void OnClientPutInServer(int client)
{
    if(g_bPluginEnabled)
    {
        g_clientPrefs[client] = GetConVarInt(g_Cvar_PrefDefault);

        if(!IsFakeClient(client))
        {   
            if (AreClientCookiesCached(client))
            {
                loadClientCookies(client);
            } 
        }
    }
}

public void OnClientCookiesCached(int client)
{
    if(g_bPluginEnabled)
    {
        if(IsClientInGame(client) && !IsFakeClient(client))
        {
            loadClientCookies(client);  
        }
    }
}

stock void loadClientCookies(int client)
{
    char buffer[5];
    GetClientCookie(client, g_Cookie_Pref, buffer, 5);

    if(!StrEqual(buffer, ""))
    {
        g_clientPrefs[client] = StringToInt(buffer);
    }

    recalculateClients(0);
}

stock void recalculateClients(int disconnectedClient)
{
    g_clientsPaintballEnabledTotal = 0;

    for(int i=1; i<=MaxClients; i++)
    {
        if(IsClientInGame(i) && g_clientPrefs[i] && (i != disconnectedClient))
        {
            g_clientsPaintballEnabled[g_clientsPaintballEnabledTotal++] = i;
        }
    }
}

public void OnClientDisconnect(int client)
{
    if(g_bPluginEnabled)
    {
        recalculateClients(client);
    }
}