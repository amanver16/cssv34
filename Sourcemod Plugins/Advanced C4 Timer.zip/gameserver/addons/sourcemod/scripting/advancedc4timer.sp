#include <sourcemod>
#include <sdktools>

#pragma semicolon 1
#pragma newdecls required

#define PLUGIN_VERSION "1.4.1"
#define NUM_SOUNDS 12
#define TIMER 30
#define TWENTY 0
#define ONE 1
#define TWO 2
#define THREE 3
#define FOUR 4
#define FIVE 5
#define SIX 6
#define SEVEN 7
#define EIGHT 8
#define NINE 9
#define TEN 10
#define THIRTY 11
#define NUM_PREFS 4
#define SOUND 0
#define HUD 1

public Plugin myinfo = 
{
	name = "Advanced c4 Countdown Timer",
	author = "dalto, Vertigo",
	description = "Plugin that gives a countdown for the C4 explosion in Counter-Strike Source.",
	version = PLUGIN_VERSION,
	url = "http://forums.alliedmods.net"
};

// Global Variables
char g_soundsList[1][NUM_SOUNDS][PLATFORM_MAX_PATH], g_filenameC4[PLATFORM_MAX_PATH], g_planter[40];
int g_c4Preferences[MAXPLAYERS + 1][NUM_PREFS], g_countdown;
Handle g_kvC4 = INVALID_HANDLE, g_CvarEnable = INVALID_HANDLE, g_CvarMPc4Timer = INVALID_HANDLE, g_CvarSoundDefault = INVALID_HANDLE, g_CvarHUDDefault = INVALID_HANDLE, hTimer = INVALID_HANDLE;
float g_explosionTime;
bool g_lateLoaded;
static const char g_soundNames[NUM_SOUNDS][] = {"20", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "30"};

// We need to capture if the plugin was late loaded so we can make sure initializations
// are handled properly
public APLRes AskPluginLoad2(Handle myself, bool late, char[] error, int err_max)
{
	g_lateLoaded = late;
	return APLRes_Success;
}

public void OnPluginStart()
{
	CreateConVar("sm_c4_timer_version", PLUGIN_VERSION, "Advanced c4 Timer Version", FCVAR_SPONLY|FCVAR_REPLICATED|FCVAR_NOTIFY);
	g_CvarEnable = CreateConVar("sm_c4_timer_enable", "1", "Enables the c4 timer");
	g_CvarHUDDefault = CreateConVar("sm_c4_timer_hud_default", "1", "Default setting for HUD preference");
	g_CvarSoundDefault = CreateConVar("sm_c4_timer_sound_default", "1", "Default setting for sound preference");
	
	g_CvarMPc4Timer = FindConVar("mp_c4timer");	
	LoadTranslations("plugin.advancedc4timer");
	AutoExecConfig(true, "advancedc4timer");	
	
	HookEvent("bomb_planted", EventBombPlanted, EventHookMode_Pre);
	HookEvent("round_start", EventRoundStart, EventHookMode_PostNoCopy);
	HookEvent("round_end", EventRoundEnd, EventHookMode_PostNoCopy);
	HookEvent("bomb_exploded", EventBombExploded, EventHookMode_PostNoCopy);
	HookEvent("bomb_defused", EventBombDefused, EventHookMode_Post);
	
	RegConsoleCmd("sm_c4timer", SettingsMenu);
	LoadSounds();	
	g_kvC4 = CreateKeyValues("c4UserSettings");
  	BuildPath(Path_SM, g_filenameC4, PLATFORM_MAX_PATH, "data/c4usersettings.txt");	
	if(!FileToKeyValues(g_kvC4, g_filenameC4)) KeyValuesToFile(g_kvC4, g_filenameC4);
	
	// if the plugin was loaded late we have a bunch of initialization that needs to be done
	if(g_lateLoaded)
	{
		// Next we need to whatever we would have done as each client authorized
		for(int i = 1; i <= GetMaxClients(); i++)
		{
			if(IsClientInGame(i))
			{
				PrepareClient(i);
			}
		}
	}
}

public void OnMapStart()
{
	for(int i = 0; i < NUM_SOUNDS; i++)
	{
		PrepareSound(i);
	}
}

// When a new client is authorized we create sound preferences
// for them if they do not have any already
public void OnClientAuthorized(int client, const char[] auth)
{
	PrepareClient(client);
}

public Action EventBombPlanted(Handle event, const char[] name, bool dontBroadcast)
{
	if(!GetConVarBool(g_CvarEnable))
	{
		return Plugin_Continue;
	}
	
	g_explosionTime = GetEngineTime() + GetConVarFloat(g_CvarMPc4Timer);	
	GetClientName(GetClientOfUserId(GetEventInt(event, "userid")), g_planter, sizeof(g_planter));	
	g_countdown = GetConVarInt(g_CvarMPc4Timer) - 1;
	hTimer = CreateTimer((g_explosionTime - float(g_countdown)) - GetEngineTime(), TimerCountdown);	
	return Plugin_Continue;
}

public void EventBombDefused(Handle event, const char[] name, bool dontBroadcast)
{
	if(!GetConVarBool(g_CvarEnable))
	{
		return;
	}
	
	if(hTimer != INVALID_HANDLE)
	{
		KillTimer(hTimer);
		hTimer = INVALID_HANDLE;
	}
	
	char defuser[40];
	GetClientName(GetClientOfUserId(GetEventInt(event, "userid")), defuser, sizeof(defuser));
	
	for(int i = 1; i <= GetMaxClients(); i++)
	{
		if(IsClientInGame(i) && !IsFakeClient(i) && g_c4Preferences[i][HUD])
		{
			PrintHintText(i, "%T", "bomb defused", i, defuser);
		}
	}
}

public Action TimerCountdown(Handle timer, any data)
{
	BombMessage(g_countdown);
	
	if(--g_countdown)
	{
		hTimer = CreateTimer((g_explosionTime - float(g_countdown)) - GetEngineTime(), TimerCountdown);
	}
	else
    {
        hTimer = INVALID_HANDLE;
    }
}

// Loads the soundsList array with the c4 sounds
public void LoadSounds()
{
	Handle kvQSL = CreateKeyValues("c4SoundsList");
	char fileQSL[PLATFORM_MAX_PATH];
	BuildPath(Path_SM, fileQSL, PLATFORM_MAX_PATH, "configs/c4soundslist.cfg");
	FileToKeyValues(kvQSL, fileQSL);
	
	if(!KvGotoFirstSubKey(kvQSL))
	{
		SetFailState("configs/c4soundslist.cfg not found or not correctly structured");
		CloseHandle(kvQSL);
		return;
	}

	for(int i = 0; i < NUM_SOUNDS; i++)
	{
		KvGetString(kvQSL, g_soundNames[i], g_soundsList[0][i], PLATFORM_MAX_PATH);
	}
	
	CloseHandle(kvQSL);
}

public void PrepareSound(int sound)
{
	char downloadFile[PLATFORM_MAX_PATH];

	if(!StrEqual(g_soundsList[0][sound], ""))
	{
		PrecacheSound(g_soundsList[0][sound], true);
		Format(downloadFile, PLATFORM_MAX_PATH, "sound/%s", g_soundsList[0][sound]);
		AddFileToDownloadsTable(downloadFile);
	}
}

// Sends the bomb message
public void BombMessage(int count)
{
	int soundKey;
	char buffer[200];
	
	switch(count)
	{
		case 1, 2, 3, 4, 5, 6, 7, 8, 9, 10:
			soundKey = count;
		case 20:
			soundKey = TWENTY;
		case 30:
			soundKey = THIRTY;
		default:
			return;
	}

	for(int i = 1; i <= GetMaxClients(); i++)
	{
		if(IsClientInGame(i) && !IsFakeClient(i) && !StrEqual(g_soundsList[0][soundKey], ""))
		{
			Format(buffer, sizeof(buffer), "countdown %i", count);
			Format(buffer, sizeof(buffer), "%T", buffer, i, count);
			if(g_c4Preferences[i][SOUND])
			{
				EmitSoundToClient(i, g_soundsList[0][soundKey]);
			}
			if(g_c4Preferences[i][HUD])
			{
				PrintHintText(i, buffer);
			}
		}
	}
}

//  This selects or disables the c4 settings
public int SettingsMenuHandler(Handle menu, MenuAction action, int param1, int param2)
{
	if(action == MenuAction_Select)
	{
		// Update both the soundPreference array and User Settings KV
		switch(param2)
		{
			case 0:
				g_c4Preferences[param1][SOUND] = Flip(g_c4Preferences[param1][SOUND]);
			case 1:
				g_c4Preferences[param1][HUD] = Flip(g_c4Preferences[param1][HUD]);
		}
		char steamId[20];
		GetClientAuthId(param1, AuthId_Steam2, steamId, sizeof(steamId));
		KvRewind(g_kvC4);
		KvJumpToKey(g_kvC4, steamId);
		KvSetNum(g_kvC4, "sound", g_c4Preferences[param1][SOUND]);
		KvSetNum(g_kvC4, "hud", g_c4Preferences[param1][HUD]);
		KvSetNum(g_kvC4, "timestamp", GetTime());
		SettingsMenu(param1, 0);
	} else if(action == MenuAction_End)	{
		CloseHandle(menu);
	}
}
 
//  This creates the settings panel
public Action SettingsMenu(int client, int args)
{
	char buffer[100];
	Handle menu = CreateMenu(SettingsMenuHandler);
	Format(buffer, sizeof(buffer), "%T", "c4 menu", client);
	SetMenuTitle(menu, buffer);
	
	if(g_c4Preferences[client][SOUND] == 1)
	{
		Format(buffer, sizeof(buffer), "%T", "disable sound", client);
	} else {
		Format(buffer, sizeof(buffer), "%T", "enable sound", client);
	}
	
	AddMenuItem(menu, "menu item", buffer);
	
	if(g_c4Preferences[client][HUD] == 1)
	{
		Format(buffer, sizeof(buffer), "%T", "disable hud", client);
	}
	else {
		Format(buffer, sizeof(buffer), "%T", "enable hud", client);
	}
	
	AddMenuItem(menu, "menu item", buffer);
	DisplayMenu(menu, client, 15);	 
	return Plugin_Handled;
}

// Switches a non-zero number to a 0 and a 0 to a 1
public int Flip(int flipNum)
{
	if(flipNum == 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

// Initializations to be done at the beginning of the round
public void EventRoundStart(Handle event, const char[] name, bool dontBroadcast)
{
	// Save user settings to a file
	KvRewind(g_kvC4);
	KeyValuesToFile(g_kvC4, g_filenameC4);
	
	if(hTimer != INVALID_HANDLE)
	{
		KillTimer(hTimer);
		hTimer = INVALID_HANDLE;
	}
}

public void EventRoundEnd(Handle event, const char[] name, bool dontBroadcast)
{
    if (hTimer != INVALID_HANDLE)
    {
        KillTimer(hTimer);
        hTimer = INVALID_HANDLE;
    }
	
}

// When a user disconnects we need to update their timestamp in kvC4
public void OnClientDisconnect(int client)
{
	char steamId[20];
	
	if(client && !IsFakeClient(client))
	{
		GetClientAuthId(client, AuthId_Steam2, steamId, sizeof(steamId));
		KvRewind(g_kvC4);
		if(KvJumpToKey(g_kvC4, steamId))
		{
			KvSetNum(g_kvC4, "timestamp", GetTime());
		}
	}
}

public void PrepareClient(int client)
{
	char steamId[20];
	
	if(client)
	{
		if(!IsFakeClient(client))
		{
			// Get the users saved setting or create them if they don't exist
			GetClientAuthId(client, AuthId_Steam2, steamId, sizeof(steamId));
			KvRewind(g_kvC4);
			if(KvJumpToKey(g_kvC4, steamId))
			{
				g_c4Preferences[client][SOUND] = KvGetNum(g_kvC4, "sound", GetConVarInt(g_CvarSoundDefault));
				g_c4Preferences[client][HUD] = KvGetNum(g_kvC4, "hud", GetConVarInt(g_CvarHUDDefault));
			} else {
				KvRewind(g_kvC4);
				KvJumpToKey(g_kvC4, steamId, true);
				KvSetNum(g_kvC4, "sound", GetConVarInt(g_CvarSoundDefault));
				KvSetNum(g_kvC4, "hud", GetConVarInt(g_CvarHUDDefault));
				g_c4Preferences[client][SOUND] = GetConVarInt(g_CvarSoundDefault);
				g_c4Preferences[client][HUD] = GetConVarInt(g_CvarHUDDefault);
			}
			KvRewind(g_kvC4);
		}
	}
}

public void EventBombExploded(Handle event, const char[] name, bool dontBroadcast)
{
	if(hTimer != INVALID_HANDLE)
	{
		KillTimer(hTimer);
		hTimer = INVALID_HANDLE;
	}
	
	for(int i = 1; i <= GetMaxClients(); i++)
	{
		if(IsClientInGame(i) && !IsFakeClient(i) && g_c4Preferences[i][HUD])
		{
			PrintHintText(i, "%T", "bomb exploded", i, g_planter);
		}
	}
}
