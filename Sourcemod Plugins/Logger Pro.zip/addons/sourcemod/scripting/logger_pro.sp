#include<sourcemod>
#include<morecolors>
#include<geoip>

#pragma semicolon 1
#pragma newdecls required

#define PLUGIN_VERSION "1.2"
#define nullstr NULL_STRING
#define nullvec NULL_VECTOR
#define nullptr null

public Plugin myinfo = 
{
	name = "Logger Pro [All In One Logger]",
	author = "Vertigo™",
	description = "An all in one logger for server.",
	version = "1.0",
	url = "http://risserver.ddns.net/"
};

char connDirectory[PLATFORM_MAX_PATH], 
	 banDirectory[PLATFORM_MAX_PATH], 
	 chatDirectory[PLATFORM_MAX_PATH],
	 adminsDirectory[PLATFORM_MAX_PATH],
	 reportsDirectory[PLATFORM_MAX_PATH],
	 connFile[PLATFORM_MAX_PATH], 
	 banFile[PLATFORM_MAX_PATH], 
	 unbanFile[PLATFORM_MAX_PATH],
	 chatFile[PLATFORM_MAX_PATH],
	 adminsFile[PLATFORM_MAX_PATH],
	 reportsFile[PLATFORM_MAX_PATH];
ConVar cvarConnLog, 
	   cvarDisConnLog,
	   cvarBanLog,
	   cvarUnbanLog,
	   cvarChatLog,
	   cvarAdminsLog,
	   cvarReportsLog,
	   cvarCooldown;
Handle reportReasons;
int cooldown, approveReport[MAXPLAYERS+1], victim[MAXPLAYERS+1];
bool chatReason[MAXPLAYERS+1];

public void OnPluginStart()
{
	CreateConVar("sm_logger_version", PLUGIN_VERSION, "Logger Version", FCVAR_NOTIFY|FCVAR_DONTRECORD);	

	cvarConnLog = CreateConVar("sm_logger_connlog", "1", "Log connections ? (0 - Disable, 1 - Enable)", 0, true, 0.0, true, 1.0);
	cvarDisConnLog = CreateConVar("sm_logger_disconnlog", "1", "Log disconnections ? (0 - Disable, 1 - Enable)", 0, true, 0.0, true, 1.0);
	cvarBanLog = CreateConVar("sm_logger_banlog", "1", "Log bans ? (0 - Disable, 1 - Enable)", 0, true, 0.0, true, 1.0);
	cvarUnbanLog = CreateConVar("sm_logger_unbanlog", "1", "Log unbans ? (0 - Disable, 1 - Enable)", 0, true, 0.0, true, 1.0);
	cvarChatLog = CreateConVar("sm_logger_chatlog", "1", "Log Chat ? (0 - Disable, 1 - Enable)", 0, true, 0.0, true, 1.0);
	cvarAdminsLog = CreateConVar("sm_logger_adminslog", "1", "Log Admin Actions ? (0 - Disable, 1 - Enable)", 0, true, 0.0, true, 1.0);
	cvarReportsLog = CreateConVar("sm_logger_reportslog", "1", "Log Reports ? (0 - Disable, 1 - Enable)", 0, true, 0.0, true, 1.0);
	cvarCooldown = CreateConVar("sm_logger_report_cooldown", "60", "Cooldown in seconds between each report.", 0, true, 0.0);

	if(cvarReportsLog.BoolValue)
	{
		cvarCooldown.AddChangeHook(CvarCooldownUpdated);
		RegConsoleCmd("sm_report", ReportCommand);
		RegConsoleCmd("sm_rep", ReportCommand);
		RegConsoleCmd("report", ReportCommand);
		RegConsoleCmd("say_team", ChatHook);
		RegConsoleCmd("say", ChatHook);
		for(int i=1; i < MaxClients; i++)
		{
			if(!IsClientInGame(i))
			{
				continue;
			}
			OnClientPutInServer(i);
		}
		reportReasons = CreateArray(ByteCountToCells(256));
	}

	CreateLogDirectories();
	HookEvent("player_disconnect", Event_PlayerDisconnect, EventHookMode_Pre);
	AutoExecConfig(true, "logger_pro");	
}

//------------------------------------------------------------------------------------------------------------------------------------

public void CvarCooldownUpdated(ConVar cvar, char[] oldValue, char[] newValue)
{
	cooldown = cvarCooldown.IntValue;
}

//------------------------------------------------------------------------------------------------------------------------------------

public void OnConfigsExecuted()
{
	cooldown = cvarCooldown.IntValue;
}

//------------------------------------------------------------------------------------------------------------------------------------

public void CreateLogDirectories()
{
	BuildPath(Path_SM, connDirectory, sizeof(connDirectory), "logs/connections/");
	BuildPath(Path_SM, banDirectory, sizeof(banDirectory), "logs/bans/");
	BuildPath(Path_SM, chatDirectory, sizeof(chatDirectory), "logs/chat/");	
	BuildPath(Path_SM, adminsDirectory, sizeof(adminsDirectory), "logs/admins/");
	BuildPath(Path_SM, reportsDirectory, sizeof(reportsDirectory), "logs/reports/");
	
	if(!DirExists(connDirectory))
	{
		CreateDirectory(connDirectory, 511);		
		if (!DirExists(connDirectory))
		{
			SetFailState("Unable to create cstrike/addons/sourcemod/logs/connections folder or directory (Reason: No Permission). Please manually create the folder and reload this plugin.");
		}
	}
	
	if(!DirExists(banDirectory))
	{
		CreateDirectory(banDirectory, 511);		
		if (!DirExists(banDirectory))
		{
			SetFailState("Unable to create cstrike/addons/sourcemod/logs/bans folder or directory (Reason: No Permission). Please manually create the folder and reload this plugin.");
		}
	}
	
	if(!DirExists(chatDirectory))
	{
		CreateDirectory(chatDirectory, 511);		
		if (!DirExists(chatDirectory))
		{
			SetFailState("Unable to create cstrike/addons/sourcemod/logs/chat folder or directory (Reason: No Permission). Please manually create the folder and reload this plugin.");
		}
	}

	if(!DirExists(adminsDirectory))
	{
		CreateDirectory(adminsDirectory, 511);		
		if (!DirExists(adminsDirectory))
		{
			SetFailState("Unable to create cstrike/addons/sourcemod/logs/admins folder or directory (Reason: No Permission). Please manually create the folder and reload this plugin.");
		}
	}

	if(!DirExists(reportsDirectory))
	{
		CreateDirectory(reportsDirectory, 511);		
		if (!DirExists(reportsDirectory))
		{
			SetFailState("Unable to create cstrike/addons/sourcemod/logs/reports folder or directory (Reason: No Permission). Please manually create the folder and reload this plugin.");
		}
	}
}

//------------------------------------------------------------------------------------------------------------------------------------

public void OnMapStart()
{
	char logTime[50], mapuserID[50];	
	int time = GetTime();	
	GetCurrentMap(mapuserID, sizeof(mapuserID));
	FormatTime(logTime, sizeof(logTime), "%d_%b_%Y", time);	
	BuildPath(Path_SM, connFile, sizeof(connFile), "logs/connections/%s.txt", logTime);
	BuildPath(Path_SM, banFile, sizeof(banFile), "logs/bans/bans.txt");
	BuildPath(Path_SM, unbanFile, sizeof(unbanFile), "logs/bans/unbans.txt");
	BuildPath(Path_SM, chatFile, sizeof(chatFile), "logs/chat/%s.txt", logTime);
	BuildPath(Path_SM, reportsFile, sizeof(reportsFile), "logs/reports/%s.txt", logTime);
	LogToFileEx(connFile, "\n\n=================================Current Map : %s=================================\n", mapuserID);
	LogToFileEx(chatFile, "\n\n=================================Current Map : %s=================================\n", mapuserID);
	LoadReportReasons();
}

//------------------------------------------------------------------------------------------------------------------------------------

public void OnClientPutInServer(int client)
{
	if(IsFakeClient(client))
	{
		return;
	}
	
	victim[client] = -1;
	approveReport[client] = -1;
	chatReason[client] = false;
}

//------------------------------------------------------------------------------------------------------------------------------------

public Action ReportCommand(int client, int args)
{
	if(client == 0)
	{
		return Plugin_Handled;
	}
	
	if(approveReport[client] > GetTime())
	{
		CPrintToChat(client, "{yellow}[{aqua}Reports{yellow}] {deeppink}You can use report command again after {lime}%d {deeppink}seconds.", approveReport[client] - GetTime());
		return Plugin_Handled;
	}
	
	Handle mainMenu = CreateMenu(SelectPlayerHandler);
	
	for(int i=1; i < MaxClients; i++)
	{
		if(i == client || !IsClientInGame(i) || IsFakeClient(i))
		{
			continue;
		}
		char userID[13], userName[MAX_TARGET_LENGTH];
		GetClientName(i, userName, sizeof(userName));
		IntToString(GetClientUserId(i), userID, sizeof(userID));
		AddMenuItem(mainMenu, userID, userName);
	}
	
	if(GetMenuItemCount(mainMenu) > 0)
	{
		SetMenuExitBackButton(mainMenu, false);
		SetMenuExitButton(mainMenu, true);
		SetMenuTitle(mainMenu, "Select a player to report", client);
		DisplayMenu(mainMenu, client, MENU_TIME_FOREVER);
		return Plugin_Handled;
	}
	
	CloseHandle(mainMenu);
	CPrintToChat(client, "{yellow}[{aqua}Reports{yellow}] {deeppink}No player are online for reporting.");
	return Plugin_Handled;
}

//------------------------------------------------------------------------------------------------------------------------------------

public Action ChatHook(int client, int args)
{
	if(!client || !chatReason[client])
	{
		return Plugin_Continue;
	}
	
	if(!(victim[client] = GetClientOfUserId(victim[client])))
	{
		CPrintToChat(client, "{yellow}[{aqua}Reports{yellow}] {deeppink}The selected player is no longer online. You can report when the player comes back online.");
		chatReason[client] = false;
		victim[client] = -1;
		return Plugin_Handled;
	}
	
	char reason[256];
	
	if(args == 1)
	{
		GetCmdArg(1, reason, sizeof(reason));
	}
	else
	{
		GetCmdArgString(reason, sizeof(reason));
	}
	
	if(!strcmp(reason, "!cancel"))
	{
		CPrintToChat(client, "{yellow}[{aqua}Reports{yellow}] {deeppink}The report operation has been cancelled successfully.");
		chatReason[client] = false;
		victim[client] = -1;
		return Plugin_Handled;
	}
	
	ProcessReport(client, victim[client], reason);
	return Plugin_Handled;
}

//------------------------------------------------------------------------------------------------------------------------------------

public int SelectPlayerHandler(Handle menu, MenuAction menuAction, int param1, int param2)
{
	switch(menuAction)
	{
		case MenuAction_End :
		{
			CloseHandle(menu);
		}
		case MenuAction_Select :
		{
			char menuUserId[13];
			GetMenuItem(menu, param2, menuUserId, sizeof(menuUserId));
			int userID = GetClientOfUserId(StringToInt(menuUserId));
			if(!userID)
			{
				CPrintToChat(param1, "{yellow}[{aqua}Reports{yellow}] {deeppink}The selected player is no longer online. You can report when the player comes back online.");
				return;
			}
			victim[param1] = GetClientUserId(userID);
			if(GetArraySize(reportReasons) == 0)
			{
				HookChatMessage(param1);
			}
			else
			{
				DrawReasonsMenu(param1);
			}
		}
	}
}

//------------------------------------------------------------------------------------------------------------------------------------

void DrawReasonsMenu(int client)
{
	Handle reasonsMenu = CreateMenu(ReasonsMenuHandler);
	SetMenuExitBackButton(reasonsMenu, true);
	SetMenuExitButton(reasonsMenu, false);
	SetMenuTitle(reasonsMenu, "Select a report reason:\n", client);
	char reasonBuffer[128];
	int length = GetArraySize(reportReasons);
	
	for(int i; i < length; i++)
	{
		GetArrayString(reportReasons, i, reasonBuffer, sizeof(reasonBuffer));
		TrimString(reasonBuffer);
		if(reasonBuffer[0] == 0)
		{
			AddMenuItem(reasonsMenu, nullstr, nullstr, ITEMDRAW_SPACER);
		}
		else
		{
			AddMenuItem(reasonsMenu, reasonBuffer, reasonBuffer, ITEMDRAW_DEFAULT);
		}
	}
	
	AddMenuItem(reasonsMenu, nullstr, nullstr, ITEMDRAW_SPACER);
	FormatEx(reasonBuffer, sizeof(reasonBuffer), "Enter a custom reason in chat", client);
	AddMenuItem(reasonsMenu, "***Custom Reason***", reasonBuffer, ITEMDRAW_DEFAULT);
	DisplayMenu(reasonsMenu, client, MENU_TIME_FOREVER);
}

//------------------------------------------------------------------------------------------------------------------------------------

public int ReasonsMenuHandler(Handle reasonsMenu, MenuAction menuAction, int param1, int param2)
{
	switch(menuAction)
	{
		case MenuAction_End :
		{
			CloseHandle(reasonsMenu);
		}
		case MenuAction_Select :
		{
			char reason[128];
			GetMenuItem(reasonsMenu, param2, reason, sizeof(reason));
			if(!GetClientOfUserId(victim[param1]))
			{
				CPrintToChat(param1, "{yellow}[{aqua}Reports{yellow}] {deeppink}The selected player is no longer online. You can report when the player comes back online.");
				victim[param1] = -1;
				return;
			}
			if(strcmp(reason, "***Custom Reason***", true) == 0)
			{
				HookChatMessage(param1);
				return;
			}
			ProcessReport(param1, GetClientOfUserId(victim[param1]), reason);
		}
	}
}

//------------------------------------------------------------------------------------------------------------------------------------

void HookChatMessage(int client)
{
	chatReason[client] = true;
	CPrintToChat(client, "{yellow}[{aqua}Reports{yellow}] {deeppink}Type your report message in the chat and Press Enter");
	CPrintToChat(client, "{yellow}[{aqua}Reports{yellow}] {deeppink}Type {lime}!cancel, if you want to cancel the submitting the report.");
}

//------------------------------------------------------------------------------------------------------------------------------------

void ProcessReport(int client, int iVictim, const char[] reason) {
	char reporteeName[50], reporteeSteamID[30], reporteeIP[20], victimName[50], victimSteamID[30], victimIP[20];
	GetClientName(client, reporteeName, sizeof(reporteeName));
	GetClientAuthId(client, AuthId_Steam2, reporteeSteamID, sizeof(reporteeSteamID));
	GetClientIP(client, reporteeIP, sizeof(reporteeIP));
	GetClientName(iVictim, victimName, sizeof(victimName));
	GetClientAuthId(iVictim, AuthId_Steam2, victimSteamID, sizeof(victimSteamID));
	GetClientIP(iVictim, victimIP, sizeof(victimIP));
	LogToFileEx(reportsFile, "%s [%s] [%s] reported %s [%s] [%s]. Reason: %s", reporteeName, reporteeSteamID, reporteeIP, victimName, victimSteamID, victimIP, reason);
	CPrintToChat(client, "{yellow}[{aqua}Reports{yellow}] {deeppink}Your report has been successfully submitted.");
	approveReport[client] = GetTime() + cooldown;
	chatReason[client] = false;
	victim[client] = -1;
}

//------------------------------------------------------------------------------------------------------------------------------------

public void OnClientAuthorized(int client)
{	
	if(IsFakeClient(client))
	{
		return;
	}
	
	if(cvarConnLog.BoolValue)
	{		
		char clientName[50], clientSteamID[30], clientIP[20], clientCountry[20];
		GetClientName(client, clientName, sizeof(clientName));
		GetClientAuthId(client, AuthId_Engine, clientSteamID, sizeof(clientSteamID));
		GetClientIP(client, clientIP, sizeof(clientIP));
		GeoipCountry(clientIP, clientCountry, sizeof(clientCountry));
		if(strlen(clientCountry) == 0)
		{
			FormatEx(clientCountry, sizeof(clientCountry), "Unknown");
		}
		LogToFileEx(connFile, "%s [%s] [%s] connected from country %s.", clientName, clientSteamID, clientIP, clientCountry);
	}	
}

//------------------------------------------------------------------------------------------------------------------------------------

public Action Event_PlayerDisconnect(Handle event, const char[] name, bool dontBroadcast)
{	
	int client = GetClientOfUserId(GetEventInt(event, "userid"));
	
	if(client < 1)
	{
		return;
	}
	
	if(IsFakeClient(client))
	{
		return;
	}
	
	if(cvarDisConnLog.BoolValue)
	{		
		char clientName[50], clientID[30], clientIP[20], clientCountry[20], disconnectReason[255];
		int totalConnectionTime = RoundToCeil(GetClientTime(client) / 60);
		GetClientName(client, clientName, sizeof(clientName));
		GetClientAuthId(client, AuthId_Engine, clientID, sizeof(clientID));
		GetClientIP(client, clientIP, sizeof(clientIP));
		GeoipCountry(clientIP, clientCountry, sizeof(clientCountry));
		GetEventString(event, "reason", disconnectReason, sizeof(disconnectReason)); 
		if(strlen(clientCountry) == 0)
		{
			FormatEx(clientCountry, sizeof(clientCountry), "Unknown");
		}
		LogToFileEx(connFile, "%s [%s] [%s] disconnected from country %s (%s). [Total Connection Time : %d minutes]", clientName, clientID, clientIP, clientCountry, disconnectReason, totalConnectionTime);
	}
	
}

//------------------------------------------------------------------------------------------------------------------------------------

public Action OnBanClient(int client, int banTime, int adminFlags, const char[] banReason, const char[] kickMessage, const char[] banCommand, any banAdmin)
{
	if(cvarBanLog.BoolValue)
	{	
		char banDuration[35];	
		if(banTime)
		{
			Format(banDuration, sizeof(banDuration), "%d Minutes", banTime);
		}
		else
		{
			banDuration = "Permanent";
		}	
		char clientName[50], clientID[30], clientIP[20], banAdminName[50];
		GetClientName(client, clientName, sizeof(clientName));
		GetClientAuthId(client, AuthId_Engine, clientID, sizeof(clientID));
		GetClientIP(client, clientIP, sizeof(clientIP));	
		GetClientName(banAdmin, banAdminName, sizeof(banAdminName));		
		LogToFileEx(banFile, "\nPlayer Name       : %s\nPlayer SteamID    : %s\nPlayer IP         : %s\nBan Duration      : %s\nBan Admin         : %s\nBan Reason        : %s\nBan Type          : In Game Ban.\n-------------------------------------------------------------", clientName, clientID, clientIP, banDuration, banAdminName, banReason);
	}
	
	return Plugin_Continue;	
}

//------------------------------------------------------------------------------------------------------------------------------------

public Action OnBanIdentity(const char[] identity, int banTime, int flags, const char[] banReason, const char[] command, any source)
{
	if(cvarBanLog.BoolValue)
	{
		char banDuration[35];		
		if (banTime)
		{
			Format(banDuration, sizeof(banDuration), "%d Minutes", banTime);
		}
		else
		{
			banDuration = "Permanent";
		}		
		char banAdminName[50];
		GetClientName(source, banAdminName, sizeof(banAdminName));	
		if (banReason[0])
		{
			LogToFileEx(banFile, "\nPlayer Name       : Not Applicable\nPlayer SteamID/IP : %s\nBan Duration      : %s\nBan Admin         : %s\nBan Reason        : %s\nBan Type          : Console ban.\n-------------------------------------------------------------", identity, banDuration, banAdminName, banReason);
		}
		else 
		{
			LogToFileEx(banFile, "\nPlayer Name       : Not Applicable\nPlayer SteamID/IP : %s\nBan Duration      : %s\nBan Admin         : %s\nBan Reason        : Not Specified.\nBan Type          : Console ban.\n-------------------------------------------------------------", identity, banDuration, banAdminName);
		}
	}
	
	return Plugin_Continue;
}

//------------------------------------------------------------------------------------------------------------------------------------

public Action OnRemoveBan(const char[] identity, int flags, const char[] command, any source)
{
	if(cvarUnbanLog.BoolValue)
	{
		LogToFileEx(unbanFile, "%L unbanned %s", source, identity);
	}
	
	return Plugin_Continue;
}

//------------------------------------------------------------------------------------------------------------------------------------

public Action OnClientSayCommand(int client, const char[] command, const char[] sArgs)
{
	if(client < 1)
	{
		return;
	}
	
	if(strlen(sArgs) == 0)
	{
		return;
	}
	
	if(cvarChatLog.BoolValue)
	{
		char clientName[50], clientSteamID[30], clientIP[20];
		GetClientName(client, clientName, sizeof(clientName));
		GetClientAuthId(client, AuthId_Engine, clientSteamID, sizeof(clientSteamID));
		GetClientIP(client, clientIP, sizeof(clientIP));
		LogToFileEx(chatFile, "%s [%s] [%s] : %s", clientName, clientSteamID, clientIP, sArgs);
	}
}

//------------------------------------------------------------------------------------------------------------------------------------

public Action OnLogAction(Handle source, Identity ident, int client, int target, const char[] message)
{
	if(client < 1)
	{
		return Plugin_Handled;
	}

	if(cvarAdminsLog.BoolValue)
	{
		if(GetUserAdmin(client) == INVALID_ADMIN_ID)
		{
			return Plugin_Continue;
		}		
		char logtag[64];		
		if(ident == Identity_Plugin)
		{
			GetPluginFilename(source, logtag, sizeof(logtag));
		}
		else
		{
			strcopy(logtag, sizeof(logtag), "SM");
		}		
		char steamid[32];
		if(client > 0)
		{
			GetClientAuthId(client, AuthId_Engine, steamid, sizeof(steamid));
			ReplaceString(steamid, sizeof(steamid), ":", "-");
		}
		else
		{
			FormatEx(steamid, sizeof(steamid), "Console");
		}
		BuildPath(Path_SM, adminsFile, sizeof(adminsFile), "logs/admins/%s.txt", steamid);
		LogToFileEx(adminsFile, "[%s] %s", logtag, message);
	}
	
	return Plugin_Handled;
}

//------------------------------------------------------------------------------------------------------------------------------------

void LoadReportReasons()
{
	static char reasonsPath[PLATFORM_MAX_PATH];
	
	if(GetArraySize(reportReasons) != 0)
	{
		ClearArray(reportReasons);
	}
	
	if (reasonsPath[0] == 0)
	{
		BuildPath(Path_SM, reasonsPath, sizeof(reasonsPath), "configs/report_reasons.ini");
	}
	
	Handle reasonsFile;

	if(!FileExists(reasonsPath) || (reasonsFile = OpenFile(reasonsPath, "rt")) == nullptr)
	{
		SetFailState("Could not load the file cstrike/addons/sourcemod/configs/report_reasons.ini. The file is probably missing or has invalid data.");
		return;
	}
	
	char tempBuffer[128];
	
	while(!IsEndOfFile(reasonsFile))
	{
		ReadFileLine(reasonsFile, tempBuffer, sizeof(tempBuffer));
		if(tempBuffer[0] == '/' && tempBuffer[1] == '/')
		{
			continue;
		}
		PushArrayString(reportReasons, tempBuffer);
	}
	
	CloseHandle(reasonsFile);
}