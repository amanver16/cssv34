#include <sdktools_voice>

new bool:g_EnemyVoice[MAXPLAYERS+1];

public Plugin:myinfo =
{
	name = "SelfMute Toggle",
	author = "vertigo",
	description = "selfMute everyone at once",
	version = "1.0",
	url = "github.com/amanver16"
};

public OnPluginStart()
{
	RegConsoleCmd("voice", voice);
	RegConsoleCmd("shutup", voice);
}

public OnClientPutInServer(client) g_EnemyVoice[client] = true;

public Action:voice(client, args)
{
	if (client > 0)
	{
		if (g_EnemyVoice[client])
		{
			g_EnemyVoice[client] = false;
			PrintInfo(client);
		}
		else
		{
			g_EnemyVoice[client] = true;
			PrintInfo(client);
		}
	}
	return Plugin_Handled;
}

public OnClientDisconnect(client) g_EnemyVoice[client] = true;

PrintInfo(client)
{
	if (!g_EnemyVoice[client])
	{
		for (new i = 1; i <= MaxClients; i++)
		{
			if (IsClientInGame(i) && !IsFakeClient(i) && i != client)
			{
				SetListenOverride(client, i, Listen_No);
			}
		}
	}
	else
	{
		for (new i = 1; i <= MaxClients; i++)
		{
			if (IsClientInGame(i) && !IsFakeClient(i) && i != client)
			{
				SetListenOverride(client, i, Listen_Default);
			}
		}
	}
	if (!g_EnemyVoice[client])
	{
		PrintToChat(client,"[Voice] You have self muted everyone from yourelf.");
	}
	else
	{
		PrintToChat(client,"[Voice] You have self unmuted everyone from yourelf.");
	}
}

public OnClientPostAdminCheck(client)
{
	for (new i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && !IsFakeClient(i) && i != client && !g_EnemyVoice[i])
		{
			SetListenOverride(i, client, Listen_No);
		}
	}
}