#include <sourcemod>
#pragma semicolon 1

#define MAXTEXTCOLORS 100

#define PLUGIN_VERSION "0.32"

public Plugin:myinfo =
{
	name = "Default SM Text Replacer",
	author = "Mitch/Bacardi",
	description = "Replaces the '[SM]' text with more color!",
	version = PLUGIN_VERSION,
	url = ""
};
new CountColors = 0;

new String:TextColors[MAXTEXTCOLORS][256];

public OnPluginStart()
{
	HookUserMessage(GetUserMessageId("TextMsg"), TextMsg, true);
}

public OnConfigsExecuted()
{
	RefreshConfig();
}

stock RefreshConfig()
{
	for (new X = 0; X < MAXTEXTCOLORS; X++)
	{
		TextColors[X] = "";
	}
	decl String:sPaths[PLATFORM_MAX_PATH];
	BuildPath(Path_SM, sPaths, sizeof(sPaths),"configs/textreplace.cfg");
	new Handle:hFile = OpenFile(sPaths, "r");
	new String:sBuffer[256]; 
	CountColors = -1;
	while (ReadFileLine(hFile, sBuffer, sizeof(sBuffer)))
	{
		TrimString(sBuffer);

		if(!StrEqual(sBuffer,"",false))
		{
			ReplaceString(sBuffer, sizeof(sBuffer), "{DEFAULT}", "\x01");
			ReplaceString(sBuffer, sizeof(sBuffer), "{GREEN}", "\x04");
			ReplaceString(sBuffer, sizeof(sBuffer), "{RED}", "\x03");
			CountColors++;
			strcopy(TextColors[CountColors], sizeof(TextColors), sBuffer);
		}
	}
	CloseHandle(hFile);
}

public Action:TextMsg(UserMsg:msg_id, Handle:bf, const players[], playersNum, bool:reliable, bool:init)
{
	if(CountColors != -1)
	{
		if(reliable)
		{
			new String:buffer[256];
			BfReadString(bf, buffer, sizeof(buffer));
			if(StrContains(buffer, "\x03[SM]") == 0)
			{
				new Handle:pack;
				CreateDataTimer(0.0, timer_strip, pack);
				WritePackCell(pack, playersNum);
				for(new i = 0; i < playersNum; i++)
				{
					WritePackCell(pack, players[i]);
				}
				WritePackString(pack, buffer);
				ResetPack(pack);
				return Plugin_Handled;
			}
		}
	}
	return Plugin_Continue;
}

public Action:timer_strip(Handle:timer, Handle:pack)
{
	new playersNum = ReadPackCell(pack);
	new players[playersNum];
	new client, count;
	
	for(new i = 0; i < playersNum; i++)
	{
		client = ReadPackCell(pack);
		if(IsClientInGame(client))
		{
			players[count++] = client;
		}
	}

	if(count < 1) return;
	
	playersNum = count;
	
	new String:buffer[255];
	ReadPackString(pack, buffer, sizeof(buffer));
	new String:QuickFormat[255];
	new ColorChoose = 0;
	ColorChoose = GetRandomInt(0, CountColors);
	FormatEx(QuickFormat, sizeof(QuickFormat), "%s", TextColors[ColorChoose]);
	ReplaceStringEx(buffer, sizeof(buffer), "[SM]", QuickFormat);
	new Handle:bf = StartMessage("SayText2", players, playersNum, USERMSG_RELIABLE|USERMSG_BLOCKHOOKS);
	BfWriteByte(bf, FindPlayerByTeam(2));
	BfWriteByte(bf, true);
	BfWriteString(bf, buffer);
	EndMessage();
}

stock FindPlayerByTeam(iTeam)
{
	for (new i = 1; i <= MaxClients; i++)
	{
		if (IsClientInGame(i) && GetClientTeam(i) == iTeam) return i;
	}
	return -1;
}