#include<sourcemod>

#pragma semicolon 1

#define PLUGIN_VERSION "1.0"

public Plugin myinfo = 
{
	name = "SteamID Checker",
	author = "Vertigo",
	description = "Checks & Kick players using SteamID length less than 7",
	version = "1.0",
	url = "http://risserver.ddns.net/"
};

public OnClientPostAdminCheck(client)
{	
		decl String:clientID[30];
		GetClientAuthId(client, AuthId_Engine, clientID, sizeof(clientID));
	
		if(strlen(clientID) < 17 && !IsFakeClient(client))
		{
			KickClient(client, "SteamID Changer is not allowed on this server.\nIf you think that something went wrong. Contact Vertigo.\nWhatsApp: 8084528590\nDiscord: vertigo#9152");
		}		
}