#pragma semicolon 1
#include <sourcemod>
#include <sdktools>
#define VERSION "1.0.1"

public Plugin:myinfo =
{
	name = "AWP No Scope",
	author = "XARiUS,SuBu",
	description = "Plugin which will force AWP no scoping!",
	version = "1.0.2.awp",
	url = "http://www.the-otc.com/"
};

new String:language[4];
new String:languagecode[4];
new bool:g_enabled;
new bool:g_beam;
new g_laser;
new Handle:g_Cvarenabled = INVALID_HANDLE;
new Handle:g_Cvarbeam = INVALID_HANDLE;

public OnPluginStart()
{
  LoadTranslations("awpns.phrases");
  CreateConVar("sm_awpns_version", VERSION, "AWP No Scope Version", FCVAR_PLUGIN|FCVAR_SPONLY|FCVAR_REPLICATED|FCVAR_NOTIFY|FCVAR_DONTRECORD);
  g_Cvarenabled = CreateConVar("sm_awpns_enabled", "0", "Enable this plugin. 0 = Disabled");
  g_Cvarbeam = CreateConVar("sm_awpns_beam", "0", "Show the bullet path using a small laser beam. 0 = Disabled");
  GetLanguageInfo(GetServerLanguage(), languagecode, sizeof(languagecode), language, sizeof(language));

  HookEvent("weapon_zoom", EventWeaponZoom, EventHookMode_Post);
  HookEvent("bullet_impact", OnBulletImpact, EventHookMode_Post);
  
  HookConVarChange(g_Cvarenabled, OnSettingChanged);
  HookConVarChange(g_Cvarbeam, OnSettingChanged);

  g_enabled = GetConVarBool(g_Cvarenabled);
  g_beam = GetConVarBool(g_Cvarbeam);
}

public OnMapStart()
{
	g_laser = PrecacheModel("materials/sprites/laser.vmt");
}

public OnSettingChanged(Handle:convar, const String:oldValue[], const String:newValue[])
{
  if (convar == g_Cvarenabled)
  {
    if (newValue[0] == '1')
    {
      PrintHintTextToAll("%t", "Noscope enabled");
      EmitSoundToAll("weapons/zoom.wav");
      g_enabled = true;
    }
    else
    {
      PrintHintTextToAll("%t", "Noscope disabled");
      EmitSoundToAll("weapons/zoom.wav");
      g_enabled = false;
    }
  }
  if (convar == g_Cvarbeam)
  {
    if (newValue[0] == '1')
    {
			g_beam = true;
    }
    else
    {
      g_beam = false;
    }
  }
}

public Action:OnBulletImpact(Handle:event,const String:name[],bool:dontBroadcast)
{
  if (g_enabled && g_beam)
	{
		new client = GetClientOfUserId(GetEventInt(event, "userid"));
		new String:weaponname[32];
		GetClientWeapon(client, weaponname, sizeof(weaponname));

		if ( (StrEqual(weaponname, "weapon_awp", false)) || (StrEqual(weaponname, "weapon_scout", false)) )
		{
			new color[4];

			if (GetClientTeam(client) == 3)
			{
				color = {75, 75, 255, 255};
			}
			else
			{
				color = {255, 75, 75, 255};
			}
			
			decl Float:bulletOrigin[3];
			GetClientEyePosition(client, bulletOrigin);
	
			decl Float:bulletDestination[3];
			bulletDestination[0] = GetEventFloat(event, "x");
			bulletDestination[1] = GetEventFloat(event, "y");
			bulletDestination[2] = GetEventFloat(event, "z");

			TE_SetupBeamPoints(bulletOrigin, bulletDestination, g_laser, 0, 0, 0, 0.5, 1.0, 1.0, 10, 0.0, color, 0);
			TE_SendToAll(); 
		}
	}
}

public Action:EventWeaponZoom(Handle:event,const String:name[],bool:dontBroadcast)
{
  if (g_enabled)
  {
    new client = GetClientOfUserId(GetEventInt(event, "userid"));
    new String:weaponname[32];
    GetClientWeapon(client, weaponname, sizeof(weaponname));
    if ( (StrEqual(weaponname, "weapon_awp", false)) || (StrEqual(weaponname, "weapon_scout", false)) )
    {
      new weapon = GetPlayerWeaponSlot(client, 0);
      if (IsValidEdict(weapon))
      {
        RemovePlayerItem(client, weapon);
        RemoveEdict(weapon);
		if ( (StrEqual(weaponname, "weapon_awp", false)) )
			{
				CreateTimer(0.1, GiveAwP, client);
			}
		else if ( (StrEqual(weaponname, "weapon_scout", false)) )
			{
				CreateTimer(0.1, GiveScout, client);
			}
        PrintHintText(client, "%t", "Not Allowed");
      }
      return Plugin_Continue;
    }
    return Plugin_Continue;
  }
  return Plugin_Continue;
}

public Action:GiveAwP(Handle:Timer, any:client)
{
  GivePlayerItem(client, "weapon_awp");
}
public Action:GiveScout(Handle:Timer, any:client)
{
  GivePlayerItem(client, "weapon_scout");
}