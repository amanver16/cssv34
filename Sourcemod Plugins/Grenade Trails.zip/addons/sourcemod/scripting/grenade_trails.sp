#include <sourcemod>
#include <sdktools>
#include <sdkhooks>

#pragma semicolon 1
#pragma newdecls required

public Plugin myinfo = 
{
	name = "Grenade Trails",
	author = "Fredd, Vertigo™",
	description = "Adds a trail to grenades.",
	version = "1.2",
	url = "www.sourcemod.net"
}

#define GrenadeColor 	{255,0,0,255}
#define FlashColor 		{255,255,0,255}
#define SmokeColor		{255,255,255,255}

ConVar cvarGTrailsEnabled, cvarGTrailDuration, cvarGTrailsStartWidth, cvarGTrailsEndWidth, cvarGTrailsFadeDuration, cvarGTrailsHideEnemy;
bool gTrailsEnabled, gTrailsHideEnemy;
float gTrailDuration, gTrailStartWidth, gTrailEndWidth;
int gTrailFadeDuration;
int BeamSprite;
int HaloSprite=0;

public void OnPluginStart()
{
	cvarGTrailsEnabled = CreateConVar("gt_enables", "1", "Enables/Disables Grenade Trails. (0-Disabled, 1-Enabled)", _, true, 0.0, true, 1.0);
	cvarGTrailDuration = CreateConVar("gt_duration", "5", "Time duration in seconds trails to be visible.", _, true, 1.0, true, 20.0);
	cvarGTrailsStartWidth = CreateConVar("gt_start_width", "3.0", "Initial or starting width of the trail.", _, true, 1.0, true, 20.0);
	cvarGTrailsEndWidth = CreateConVar("gt_end_width", "3.0", "Ending or final width of the trail.", _, true, 1.0, true, 20.0);
	cvarGTrailsFadeDuration = CreateConVar("gt_fade_duration", "0", "Time duration in seconds for trails to fade.", _, true, 0.0, true, 20.0);
	cvarGTrailsHideEnemy = CreateConVar("gt_hide_enemy", "1", "Hide trails of grenades thrown by enemy? (0-Unhide, 1-Hide)", _, true, 0.0, true, 1.0);
	
	cvarGTrailsEnabled.AddChangeHook(OnGTrailsEnabledCvarChanged);
	cvarGTrailDuration.AddChangeHook(OnGTrailsDurationCvarChanged);
	cvarGTrailsStartWidth.AddChangeHook(OnGTrailsStartWidthCvarChanged);
	cvarGTrailsEndWidth.AddChangeHook(OnGTrailsEndWidthCvarChanged);
	cvarGTrailsFadeDuration.AddChangeHook(OnGTrailsFadeDurationCvarChanged);
	cvarGTrailsHideEnemy.AddChangeHook(OnGTrailsHideEnemyCvarChanged);
	
	gTrailsEnabled = cvarGTrailsEnabled.BoolValue;
	gTrailDuration = cvarGTrailDuration.FloatValue;
	gTrailStartWidth = cvarGTrailsStartWidth.FloatValue;
	gTrailEndWidth = cvarGTrailsEndWidth.FloatValue;
	gTrailFadeDuration = cvarGTrailsFadeDuration.IntValue;
	gTrailsHideEnemy = cvarGTrailsHideEnemy.BoolValue;
	
	AutoExecConfig(true, "grenade_trails");
}

public void OnGTrailsEnabledCvarChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	gTrailsEnabled = cvarGTrailsEnabled.BoolValue;
}

public void OnGTrailsDurationCvarChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	gTrailDuration = cvarGTrailDuration.FloatValue;
}

public void OnGTrailsStartWidthCvarChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	gTrailStartWidth = cvarGTrailsStartWidth.FloatValue;
}

public void OnGTrailsEndWidthCvarChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	gTrailEndWidth = cvarGTrailsEndWidth.FloatValue;
}

public void OnGTrailsFadeDurationCvarChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	gTrailFadeDuration = cvarGTrailsFadeDuration.IntValue;
}

public void OnGTrailsHideEnemyCvarChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	gTrailsHideEnemy = cvarGTrailsHideEnemy.BoolValue;
}

public void OnMapStart()
{
	if(gTrailsEnabled)
	{
		BeamSprite = PrecacheModel("materials/sprites/laserbeam.vmt");
	}
}

public void OnEntityCreated(int entity, const char[] classname)
{
	if(!gTrailsEnabled)
	{
		return;
	}
	
	if(strcmp(classname, "hegrenade_projectile") == 0)
	{
		if(gTrailsHideEnemy)
		{
			SDKHook(entity, SDKHook_SpawnPost, Grenade_SpawnPost);
		}
		else
		{
			TE_SetupBeamFollow(entity, BeamSprite, HaloSprite, gTrailDuration, gTrailStartWidth, gTrailEndWidth, gTrailFadeDuration, GrenadeColor);
			TE_SendToAll();
		}
	}
	else if(strcmp(classname, "flashbang_projectile") == 0)
	{
		if(gTrailsHideEnemy)
		{
			SDKHook(entity, SDKHook_SpawnPost, Flashbang_SpawnPost);
		}
		else
		{
			TE_SetupBeamFollow(entity, BeamSprite, HaloSprite, gTrailDuration, gTrailStartWidth, gTrailEndWidth, gTrailFadeDuration, FlashColor);
			TE_SendToAll();
		}
	}
	else if(strcmp(classname, "smokegrenade_projectile") == 0)
	{
		if(gTrailsHideEnemy)
		{
			SDKHook(entity, SDKHook_SpawnPost, Smoke_SpawnPost);
		}
		else
		{
			TE_SetupBeamFollow(entity, BeamSprite, HaloSprite, gTrailDuration, gTrailStartWidth, gTrailEndWidth, gTrailFadeDuration, SmokeColor);
			TE_SendToAll();
		}
	}
}

public void Grenade_SpawnPost(int entity)
{
	CreateTimer(0.0, TimerGrenade, entity);
}

public void Flashbang_SpawnPost(int entity)
{
	CreateTimer(0.0, TimerFlashbang, entity);
}

public void Smoke_SpawnPost(int entity)
{
	CreateTimer(0.0, TimerSmoke, entity);
}

public Action TimerGrenade(Handle timer, any entity)
{
	int owner = GetEntPropEnt(entity, Prop_Send, "m_hThrower");

	if(owner != -1)
	{
		int throwerTeam = GetClientTeam(owner);
		TE_SetupBeamFollow(entity, BeamSprite, HaloSprite, gTrailDuration, gTrailStartWidth, gTrailEndWidth, gTrailFadeDuration, GrenadeColor);
		SendTrailToTeam(throwerTeam);
	}
}

public Action TimerFlashbang(Handle timer, any entity)
{
	int owner = GetEntPropEnt(entity, Prop_Send, "m_hThrower");

	if(owner != -1)
	{
		int throwerTeam = GetClientTeam(owner);
		TE_SetupBeamFollow(entity, BeamSprite, HaloSprite, gTrailDuration, gTrailStartWidth, gTrailEndWidth, gTrailFadeDuration, FlashColor);
		SendTrailToTeam(throwerTeam);
	}
}

public Action TimerSmoke(Handle timer, any entity)
{
	int owner = GetEntPropEnt(entity, Prop_Send, "m_hThrower");

	if(owner != -1)
	{
		int throwerTeam = GetClientTeam(owner);
		TE_SetupBeamFollow(entity, BeamSprite, HaloSprite, gTrailDuration, gTrailStartWidth, gTrailEndWidth, gTrailFadeDuration, SmokeColor);
		SendTrailToTeam(throwerTeam);
	}
}

stock void SendTrailToTeam(int throwerTeam)
{
	int[] clients = new int[MaxClients];
	int clientCount;

	for(int i=1; i<=MaxClients; i++)
	{
		if(IsClientInGame(i) && !IsFakeClient(i) && GetClientTeam(i) == throwerTeam)
		{
			clients[clientCount++] = i;
		}
	}

	TE_Send(clients, clientCount);
}