#include <sourcemod>

#pragma semicolon 1
#pragma newdecls required

public Plugin myinfo = 
{
	name = "Stop Music",
	author = "SuBu | return  0;",
	description = "Stops the currently playing music",
	version = "1.1",
	url = "http://risserver.ddns.net"
};

public void OnPluginStart()
{
	RegConsoleCmd("sm_ms", Command_StopMusic, "Stops the music.");
	RegConsoleCmd("sm_stfu", Command_StopMusic, "Stops the music.");
	RegConsoleCmd("showbriefing", Command_StopMusic, "Press i to stop the music.");
}

public Action Command_StopMusic(int client, int args)
{
	if (client <= 0) return Plugin_Handled;
	ClientCommand(client, "play sddgd5dfdgh45a");
	ClientCommand(client, "play eddgd5dfdgh45a");
	ClientCommand(client, "play efdgd5rfdxh15a.mp3");
	ReplyToCommand(client, "\x03[\x04Stop-Music\x03] \x04Music playback stopped.");
	return Plugin_Handled;
}