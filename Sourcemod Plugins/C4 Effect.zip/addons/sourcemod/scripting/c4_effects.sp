#include <sourcemod>
#include <sdktools>

#pragma semicolon 1
#pragma newdecls required

public Plugin myinfo = 
{
	name = "C4 effects",
	author = "NoTiCE, Vertigo™",
	description = "C4 Plant/Defuse Effects",
	version = "1.1",
	url = "http://risserver.ddns.net/"
};

ConVar g_cvC4EffectsEnabled,
	   g_cvC4EffectModel,
	   g_cvC4PlantColor, 
	   g_cvC4StartDefuseColor,  
	   g_cvC4DefusedColor,
	   g_cvC4BaseSpread,
	   g_cvC4SpreadSpeed,
	   g_cvC4Speed,
	   g_cvC4StartSize,
	   g_cvC4EndSize,
	   g_cvC4Rate,
	   g_cvC4JetLength,
	   g_cvC4RenderAmt;
	   
int g_iSmokeEntity, c4Enabled;

char c4Model[128],
	 c4PlantColor[12],
	 c4StartDefuseColor[12],
	 c4DefusedColor[12],
	 c4BaseSpread[3],
	 c4SpreadSpeed[3],
	 c4Speed[3],
	 c4StartSize[3],
	 c4EndSize[3],
	 c4Rate[3],
	 c4JetLength[4],
	 c4RenderAmt[4];

public void OnPluginStart()
{
	g_cvC4EffectsEnabled = CreateConVar("c4_effects_enable", "1", "Enable/Disable Plugin (0 - Disable, 1 - Enable)", _, true, 0.0, true, 1.0);
	g_cvC4EffectModel = CreateConVar("c4_effects_model", "particle/fire.vmt", "VMT model to be used for the effect (Path relative to materials folder)");
	g_cvC4PlantColor = CreateConVar("c4_effects_plant_color", "255 0 0", "Color effect on C4 plant (255 0 0 - Red)");
	g_cvC4StartDefuseColor = CreateConVar("c4_effects_start_defuse_color", "0 0 255", "Color effect on C4 begin defuse (0 0 255 - Blue)");
	g_cvC4DefusedColor = CreateConVar("c4_effects_defused_color", "0 255 0", "Color effect on C4 defused (0 255 0 - Green)");
	g_cvC4BaseSpread = CreateConVar("c4_effects_base_spread", "20", "Base spread size of the effect", _, true, 0.0, true, 50.0);
	g_cvC4SpreadSpeed = CreateConVar("c4_effects_spread_speed", "10", "Spreading speed of the effect", _, true, 0.0, true, 50.0);
	g_cvC4Speed = CreateConVar("c4_effects_speed", "30", "Speed of the effect", _, true, 0.0, true, 50.0);
	g_cvC4StartSize = CreateConVar("c4_effects_start_size", "20", "Starting size of the effect", _, true, 0.0, true, 50.0);
	g_cvC4EndSize = CreateConVar("c4_effects_end_size", "20", "Ending size of the effect", _, true, 0.0, true, 50.0);
	g_cvC4Rate = CreateConVar("c4_effects_rate", "40", "Rate of the effect", _, true, 0.0, true, 100.0);
	g_cvC4JetLength = CreateConVar("c4_effects_jet_length", "200", "Jet Length of the effect", _, true, 0.0, true, 500.0);
	g_cvC4RenderAmt = CreateConVar("c4_effects_render_amt", "100", "Rendering amount of the effect", _, true, 0.0, true, 500.0);
	
	updateVariables();
	
	g_cvC4EffectsEnabled.AddChangeHook(ChangeEnabled);
	g_cvC4EffectModel.AddChangeHook(ChangeModel);
	g_cvC4PlantColor.AddChangeHook(ChangePlantColor);
	g_cvC4StartDefuseColor.AddChangeHook(ChangeStartDefuseColor);
	g_cvC4DefusedColor.AddChangeHook(ChangeDefusedColor);
	g_cvC4BaseSpread.AddChangeHook(ChangeBaseSpread);
	g_cvC4SpreadSpeed.AddChangeHook(ChangeSpreadSpeed);
	g_cvC4Speed.AddChangeHook(ChangeSpeed);
	g_cvC4StartSize.AddChangeHook(ChangeStartSize);
	g_cvC4EndSize.AddChangeHook(ChangeEndSize);
	g_cvC4Rate.AddChangeHook(ChangeRate);
	g_cvC4JetLength.AddChangeHook(ChangeJetLength);
	g_cvC4RenderAmt.AddChangeHook(ChangeRenderAmt);
	
	HookEvent("bomb_planted", Event_BombPlanted);
	HookEvent("bomb_begindefuse", Event_BombBeginDefuse);
	HookEvent("bomb_abortdefuse", Event_BombAbortDefuse);
	HookEvent("bomb_defused", Event_BombDefused);
	HookEvent("bomb_exploded", Event_BombExploded);
	
	AutoExecConfig(true, "c4_effects");
}

public void ChangeEnabled(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	c4Enabled = g_cvC4EffectsEnabled.IntValue;
}

public void ChangeModel(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4EffectModel.GetString(c4Model, sizeof(c4Model));
}

public void ChangePlantColor(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4PlantColor.GetString(c4PlantColor, sizeof(c4PlantColor));
}

public void ChangeStartDefuseColor(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4StartDefuseColor.GetString(c4StartDefuseColor, sizeof(c4StartDefuseColor));
}

public void ChangeDefusedColor(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4DefusedColor.GetString(c4DefusedColor, sizeof(c4DefusedColor));
}

public void ChangeBaseSpread(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4BaseSpread.GetString(c4BaseSpread, sizeof(c4BaseSpread));
}

public void ChangeSpreadSpeed(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4SpreadSpeed.GetString(c4SpreadSpeed, sizeof(c4SpreadSpeed));
}

public void ChangeSpeed(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4Speed.GetString(c4Speed, sizeof(c4Speed));
}

public void ChangeStartSize(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4StartSize.GetString(c4StartSize, sizeof(c4StartSize));
}

public void ChangeEndSize(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4EndSize.GetString(c4EndSize, sizeof(c4EndSize));
}

public void ChangeRate(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4Rate.GetString(c4Rate, sizeof(c4Rate));
}

public void ChangeJetLength(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4JetLength.GetString(c4JetLength, sizeof(c4JetLength));
}

public void ChangeRenderAmt(ConVar convar, char[] oldValue, char[] newValue)
{
	convar.SetString(newValue);
	g_cvC4RenderAmt.GetString(c4RenderAmt, sizeof(c4RenderAmt));
}

stock void updateVariables()
{
	c4Enabled = g_cvC4EffectsEnabled.IntValue;
	g_cvC4EffectModel.GetString(c4Model, sizeof(c4Model));
	g_cvC4PlantColor.GetString(c4PlantColor, sizeof(c4PlantColor));
	g_cvC4StartDefuseColor.GetString(c4StartDefuseColor, sizeof(c4StartDefuseColor));
	g_cvC4DefusedColor.GetString(c4DefusedColor, sizeof(c4DefusedColor));
	g_cvC4BaseSpread.GetString(c4BaseSpread, sizeof(c4BaseSpread));
	g_cvC4SpreadSpeed.GetString(c4SpreadSpeed, sizeof(c4SpreadSpeed));
	g_cvC4Speed.GetString(c4Speed, sizeof(c4Speed));
	g_cvC4StartSize.GetString(c4StartSize, sizeof(c4StartSize));
	g_cvC4EndSize.GetString(c4EndSize, sizeof(c4EndSize));
	g_cvC4Rate.GetString(c4Rate, sizeof(c4Rate));
	g_cvC4JetLength.GetString(c4JetLength, sizeof(c4JetLength));
	g_cvC4RenderAmt.GetString(c4RenderAmt, sizeof(c4RenderAmt));
}

public Action Event_BombPlanted(Handle event, const char[] name, bool dontBroadcast)
{
	if (c4Enabled)
	{
		g_iSmokeEntity = CreateEntityByName("env_smokestack");
		DispatchKeyValue(g_iSmokeEntity, "SmokeMaterial", c4Model);
		DispatchKeyValue(g_iSmokeEntity, "basespread", c4BaseSpread);
		DispatchKeyValue(g_iSmokeEntity, "spreadspeed", c4SpreadSpeed);
		DispatchKeyValue(g_iSmokeEntity, "speed", c4Speed);
		DispatchKeyValue(g_iSmokeEntity, "startsize", c4StartSize);
		DispatchKeyValue(g_iSmokeEntity, "endsize", c4EndSize);
		DispatchKeyValue(g_iSmokeEntity, "rate", c4Rate);
		DispatchKeyValue(g_iSmokeEntity, "jetlength", c4JetLength);
		DispatchKeyValue(g_iSmokeEntity, "renderamt", c4RenderAmt);
		DispatchKeyValue(g_iSmokeEntity, "rendercolor", c4PlantColor);
		int Planted_C4=-1;
		Planted_C4 = FindEntityByClassname(Planted_C4, "planted_c4");
		float flc4_position[3];
		GetEntPropVector(Planted_C4, Prop_Send, "m_vecOrigin", flc4_position);
		TeleportEntity(g_iSmokeEntity, flc4_position, NULL_VECTOR, NULL_VECTOR);
		DispatchSpawn(g_iSmokeEntity);
		AcceptEntityInput(g_iSmokeEntity, "TurnOn");
	}
	return Plugin_Continue;
}

public Action Event_BombBeginDefuse(Handle event, const char[] name, bool dontBroadcast)
{
	AcceptEntityInput(g_iSmokeEntity, "TurnOff");
	DispatchKeyValue(g_iSmokeEntity, "rendercolor", c4StartDefuseColor);
	AcceptEntityInput(g_iSmokeEntity, "TurnOn");
	return Plugin_Continue;
}

public Action Event_BombAbortDefuse(Handle event, const char[] name, bool dontBroadcast)
{
	AcceptEntityInput(g_iSmokeEntity, "TurnOff");
	DispatchKeyValue(g_iSmokeEntity, "rendercolor", c4PlantColor);
	AcceptEntityInput(g_iSmokeEntity, "TurnOn");
	return Plugin_Continue;
}

public Action Event_BombDefused(Handle event, const char[] name, bool dontBroadcast)
{
	AcceptEntityInput(g_iSmokeEntity, "TurnOff");
	DispatchKeyValue(g_iSmokeEntity, "rendercolor", c4DefusedColor);
	AcceptEntityInput(g_iSmokeEntity, "TurnOn");
	return Plugin_Continue;
}

public Action Event_BombExploded(Handle event, const char[] name, bool dontBroadcast)
{
	AcceptEntityInput(g_iSmokeEntity, "TurnOff");
	return Plugin_Continue;
}