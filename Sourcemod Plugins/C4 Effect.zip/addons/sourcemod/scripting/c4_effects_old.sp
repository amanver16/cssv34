#pragma semicolon 1

#include <sourcemod>
#include <sdktools>

public Plugin:myinfo = 
{
	name = "C4 effects",
	author = "NoTiCE",
	description = "C4 bomb Defuse/Plant Effects",
	version = "1.0",
	url = "http://hlmod.ru/"
};

new g_iSmokeEntity;

public OnPluginStart()
{
	HookEvent("bomb_planted", Event_BombPlanted);
	HookEvent("bomb_begindefuse", Event_BombBeginDefuse);
	HookEvent("bomb_abortdefuse", Event_BombAbortDefuse);
	HookEvent("bomb_defused", Event_BombDefused);
	HookEvent("bomb_exploded", Event_BombExploded);
}

public Action:Event_BombPlanted(Handle:event, const String:name[], bool:dontBroadcast)
{
	g_iSmokeEntity = CreateEntityByName("env_smokestack");
	DispatchKeyValue(g_iSmokeEntity, "SmokeMaterial", "particle/smokestack.vmt");
	DispatchKeyValue(g_iSmokeEntity, "basespread", "20");
	DispatchKeyValue(g_iSmokeEntity, "spreadspeed", "10");
	DispatchKeyValue(g_iSmokeEntity, "speed", "30");
	DispatchKeyValue(g_iSmokeEntity, "startsize", "20");
	DispatchKeyValue(g_iSmokeEntity, "endsize", "20");
	DispatchKeyValue(g_iSmokeEntity, "rate", "40");
	DispatchKeyValue(g_iSmokeEntity, "jetlength", "200");
	DispatchKeyValue(g_iSmokeEntity, "renderamt", "100");
	DispatchKeyValue(g_iSmokeEntity, "rendercolor", "255 0 0");
	new Planted_C4=-1;
	Planted_C4 = FindEntityByClassname(Planted_C4, "planted_c4");
	new Float:flc4_position[3];
	GetEntPropVector(Planted_C4, Prop_Send, "m_vecOrigin", flc4_position);
	TeleportEntity(g_iSmokeEntity, flc4_position, NULL_VECTOR, NULL_VECTOR);
	DispatchSpawn(g_iSmokeEntity);
	AcceptEntityInput(g_iSmokeEntity, "TurnOn");
	return Plugin_Continue;
}

public Action:Event_BombBeginDefuse(Handle:event, const String:name[], bool:dontBroadcast)
{
	AcceptEntityInput(g_iSmokeEntity, "TurnOff");
	DispatchKeyValue(g_iSmokeEntity, "rendercolor", "0 0 255");
	AcceptEntityInput(g_iSmokeEntity, "TurnOn");
	return Plugin_Continue;
}

public Action:Event_BombAbortDefuse(Handle:event, const String:name[], bool:dontBroadcast)
{
	AcceptEntityInput(g_iSmokeEntity, "TurnOff");
	DispatchKeyValue(g_iSmokeEntity, "rendercolor", "255 0 0");
	AcceptEntityInput(g_iSmokeEntity, "TurnOn");
	return Plugin_Continue;
}

public Action:Event_BombDefused(Handle:event, const String:name[], bool:dontBroadcast)
{
	AcceptEntityInput(g_iSmokeEntity, "TurnOff");
	DispatchKeyValue(g_iSmokeEntity, "rendercolor", "0 255 0");
	AcceptEntityInput(g_iSmokeEntity, "TurnOn");
	return Plugin_Continue;
}

public Action:Event_BombExploded(Handle:event, const String:name[], bool:dontBroadcast)
{
	AcceptEntityInput(g_iSmokeEntity, "TurnOff");
	return Plugin_Continue;
}