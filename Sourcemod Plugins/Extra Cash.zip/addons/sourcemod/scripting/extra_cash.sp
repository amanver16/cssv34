#include <sourcemod>

#pragma semicolon 1
#pragma newdecls required

#define VERSION "0.3"

int g_iAccount = -1;
Handle Switch, Cash;

public Plugin myinfo = 
{
	name = "Extra Cash",
	author = "Peoples Army, Vertigo™",
	description = "Adds Extra Cash On Each Spawn.",
	version = VERSION,
	url = "www.sourcemod.net"
}

public void OnPluginStart()
{
	g_iAccount = FindSendPropInfo("CCSPlayer", "m_iAccount");
	Switch = CreateConVar("extra_Cash_on","1","1 turns plugin on 0 is off",FCVAR_NOTIFY);
	Cash = CreateConVar("extra_cash_amount","16000","Sets Amount OF Money Given On Spawn",FCVAR_NOTIFY);
	AutoExecConfig(true, "extra_cash");
	HookEvent("player_spawn" , Spawn);
}

public void Spawn(Handle event, const char[] name, bool dontBroadcast)
{
	int clientID = GetEventInt(event,"userid");
	int client = GetClientOfUserId(clientID);
	if(GetConVarInt(Switch))
	{
		SetMoney(client,GetConVarInt(Cash));
	}
}

public void SetMoney(int client, int amount)
{
	if (g_iAccount != -1)
	{
		SetEntData(client, g_iAccount, amount);
	}	
}