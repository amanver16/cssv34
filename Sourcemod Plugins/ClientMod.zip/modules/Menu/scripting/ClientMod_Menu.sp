#include <sourcemod>
#include <clientmod>

#pragma semicolon 1
#pragma newdecls required

public Plugin myinfo = 
{
	name = "[ClientMod] Info Menu",
	author = "KOROVKA, Vertigo™", // Plugin by KOROVKA
	description = "Shows list of old and CM clients in a menu.",
	version = "1.0.2",
	url = "http://risserver.ddns.net/cm"
};

public void OnPluginStart() 
{
	RegConsoleCmd("sm_cml", Cmd_CMInfoMenu);
	RegConsoleCmd("sm_cmlist", Cmd_CMInfoMenu);
	RegConsoleCmd("sm_cm_list", Cmd_CMInfoMenu);
}

public Action Cmd_CMInfoMenu(int client, int args)
{
	if(client > 0) ShowMenu(client);
	return Plugin_Handled;
}

public void ShowMenu(int client)
{
	Handle menu = CreateMenu(MenuHandler_PlayersList);
	char buffer[80];
	
	for (int i = 1; i <= MaxClients; i++) 
	{
		if(IsClientInGame(i) && !IsFakeClient(i) && CM_GetClientModAuth(i) > CM_Auth_Unknown)
		{
			char _version[16];
			if (CM_GetClientModVersion(i, _version, sizeof(_version)))
				FormatEx(buffer, 80, "CMv%s | %N", _version, i);
			else
				FormatEx(buffer, 80, "OLD | %N", i);
			
			AddMenuItem(menu, "", buffer, ITEMDRAW_DISABLED); 
		}
	}

	SetMenuTitle(menu, "OLD - Old CSS Players | CM - ClientMod Players"); 
	DisplayMenu(menu, client, MENU_TIME_FOREVER);
}

public int MenuHandler_PlayersList(Handle menu, MenuAction action, int param1, int param2)
{
	if(action == MenuAction_End) CloseHandle(menu);
}