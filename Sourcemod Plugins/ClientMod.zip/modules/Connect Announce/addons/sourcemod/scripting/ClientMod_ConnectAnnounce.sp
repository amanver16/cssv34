#include <sourcemod>
#include <morecolors>
#include <clientmod>
#include <geoip>

#pragma newdecls required
#pragma semicolon 1
#define PLUGIN_VERSION "1.5"

ConVar cvarConnectAnnounce, cvarDisconnectAnnounce, cvarTeamJoinAnnounce;
ConVar cvarDelayConnAnnounce, cvarAdminHide;
bool connectAnnounce, disconnectAnnounce, teamJoinAnnounce;
bool hideAdmin, isAdmin[MAXPLAYERS+1], isConnected[MAXPLAYERS+1];
float delayConnectAnnounce;

public Plugin myinfo = 
{
	name = "[ClientMod] Connect Announce", 
	author = "Vertigo™",
	description = "Notifies about connections and disconnections and events.", 
	version = PLUGIN_VERSION,
	url = "http://risserver.ddns.net/"
};

public void OnPluginStart()
{
	LoadTranslations("ClientMod_ConnectAnnounce.phrases");

	cvarConnectAnnounce = CreateConVar("cm_connect_announce_msg", "1", "Enable/Disable connect announce message. (0 - Disabled, 1 - Enabled)", 0, true, 0.0, true, 1.0);
	cvarDisconnectAnnounce = CreateConVar("cm_disconnect_announce_msg", "1", "Enable/Disable disconnect announce message. (0 - Disabled, 1 - Enabled)", 0, true, 0.0, true, 1.0);
	cvarTeamJoinAnnounce = CreateConVar("cm_team_join_msg", "1", "Enable/Disable team join message. (0 - Disabled, 1 - Enabled)", 0, true, 0.0, true, 1.0);
	cvarDelayConnAnnounce = CreateConVar("cm_connect_announce_delay", "0", "Delay in seconds to show the connect message. (0 - No Delay)", 0, true, 0.0, true, 10.0);
	cvarAdminHide = CreateConVar("cm_announce_admin_hide", "0", "Hide event announcements for admin ? (0 - Do not hide, 1 - Hide)", 0, true, 0.0, true, 1.0);

	InitializeVariables();

	cvarConnectAnnounce.AddChangeHook(OnConnectAnnounceChanged);
	cvarDisconnectAnnounce.AddChangeHook(OnDisconnectAnnounceChanged);
	cvarTeamJoinAnnounce.AddChangeHook(OnTeamJoinAnnounceChanged);
	cvarDelayConnAnnounce.AddChangeHook(OnDelayConnAnnounceChanged);
	cvarAdminHide.AddChangeHook(OnAdminHideChanged);

	HookEvent("player_disconnect", Event_PlayerDisconnect, EventHookMode_Pre);
	HookEvent("player_team", Event_PlayerTeam, EventHookMode_Pre);

	AutoExecConfig(true, "ClientMod_ConnectAnnounce");
}

stock void InitializeVariables()
{
	connectAnnounce = cvarConnectAnnounce.BoolValue;
	disconnectAnnounce = cvarDisconnectAnnounce.BoolValue;
	teamJoinAnnounce = cvarTeamJoinAnnounce.BoolValue;
	delayConnectAnnounce = cvarDelayConnAnnounce.FloatValue;
	hideAdmin = cvarAdminHide.BoolValue;
}

public void OnConnectAnnounceChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	connectAnnounce = cvarConnectAnnounce.BoolValue;
}

public void OnDisconnectAnnounceChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	disconnectAnnounce = cvarDisconnectAnnounce.BoolValue;
}

public void OnTeamJoinAnnounceChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	teamJoinAnnounce = cvarTeamJoinAnnounce.BoolValue;
}

public void OnDelayConnAnnounceChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	delayConnectAnnounce = cvarDelayConnAnnounce.FloatValue;
}

public void OnAdminHideChanged(ConVar cvar, char[] oldValue, char[] newValue)
{
	hideAdmin = cvarAdminHide.BoolValue;
}

public void OnClientPostAdminCheck(int client)
{
	if(GetUserAdmin(client) == INVALID_ADMIN_ID)
	{
		isAdmin[client] = false;
	}
	else
	{
		isAdmin[client] = true;
	}

	if(FloatCompare(delayConnectAnnounce, 0.0) == 0)
	{
		ConnectAnnounce(client);
	}
	else
	{
		CreateTimer(delayConnectAnnounce, TimerDelayConnectAnnounce, client);
	}
}

public Action Event_PlayerDisconnect(Handle event, const char[] names, bool dontBroadcast)
{
	int client = GetClientOfUserId(GetEventInt(event, "userid"));
	
	if(client < 1 || IsFakeClient(client) || !client)
	{
		return Plugin_Handled;
	}
	
	if(disconnectAnnounce && isConnected[client])
	{
		if(hideAdmin && isAdmin[client])
		{
			return Plugin_Handled;
		}
		isConnected[client] = false;
		char ip[20], name[100], country[50], from[255], reason[364], disconnectMessage[500];
		GetClientName(client, name, sizeof(name));
		if(GetClientIP(client, ip, sizeof(ip)) && GeoipCountry(ip, country, sizeof(country)))
		{
			Format(from, sizeof(from), "%s", country);
		}
		else
		{
			Format(from, sizeof(from), "%t", "CountryUnknown");
		}
		GetEventString(event, "reason", reason, sizeof(reason));
		for(int i=1; i<=MaxClients; i++)
		{
			if(!IsClientInGame(i) || IsFakeClient(i))
			{
				continue;
			}
			if(CM_IsClientModUser(i))
			{
				Format(disconnectMessage, sizeof(disconnectMessage), "%t", "DisconnectMessage", name, from, reason);
				CPrintToChat(i, disconnectMessage);
			}
			else
			{
				Format(disconnectMessage, sizeof(disconnectMessage), "%t", "DisconnectMessage_Old", name, from, reason);
				ReplaceString(disconnectMessage, sizeof(disconnectMessage), "{default}", "\x01", false);
				ReplaceString(disconnectMessage, sizeof(disconnectMessage), "{lightgreen}", "\x03", false);
				ReplaceString(disconnectMessage, sizeof(disconnectMessage), "{teamcolor}", "\x03", false);
				ReplaceString(disconnectMessage, sizeof(disconnectMessage), "{green}", "\x04", false);
				PrintToChat(i, disconnectMessage);
			}
		}
	}
	return Plugin_Continue;
}

public Action Event_PlayerTeam(Handle event, const char[] names, bool dontBroadcast)
{
	if (!dontBroadcast && !GetEventBool(event, "disconnect") && !GetEventBool(event, "silent") && teamJoinAnnounce)
	{
		int target = GetClientOfUserId(GetEventInt(event, "userid"));
		if(hideAdmin && isAdmin[target])
		{
			return Plugin_Handled;
		}
		char name[50], teamJoinMsg[255];
		GetClientName(target, name, sizeof(name));
		SetEventBroadcast(event, true);
		switch(GetEventInt(event, "team"))
		{
			case 1:
			{
				for(int i=1; i<=MaxClients; i++)
				{
					if(IsClientInGame(i) && !IsFakeClient(i))
					{
						if(CM_IsClientModUser(i))
						{
							Format(teamJoinMsg, sizeof(teamJoinMsg), "%t", "TeamJoinSpec", name);
							CPrintToChat(i, teamJoinMsg);
						}
						else
						{
							Format(teamJoinMsg, sizeof(teamJoinMsg), "%t", "TeamJoinSpec_Old", name);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{default}", "\x01", false);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{lightgreen}", "\x03", false);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{teamcolor}", "\x03", false);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{green}", "\x04", false);
							PrintToChat(i, teamJoinMsg);
						}
					}
				}
			}
			case 2:
			{
				for(int i=1; i<=MaxClients; i++)
				{
					if(IsClientInGame(i) && !IsFakeClient(i))
					{
						if(CM_IsClientModUser(i))
						{
							Format(teamJoinMsg, sizeof(teamJoinMsg), "%t", "TeamJoinT", name);
							CPrintToChat(i, teamJoinMsg);
						}
						else
						{
							Format(teamJoinMsg, sizeof(teamJoinMsg), "%t", "TeamJoinT_Old", name);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{default}", "\x01", false);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{lightgreen}", "\x03", false);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{teamcolor}", "\x03", false);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{green}", "\x04", false);
							PrintToChat(i, teamJoinMsg);
						}
					}
				}
			}
			case 3:
			{
				for(int i=1; i<=MaxClients; i++)
				{
					if(IsClientInGame(i) && !IsFakeClient(i))
					{
						if(CM_IsClientModUser(i))
						{
							Format(teamJoinMsg, sizeof(teamJoinMsg), "%t", "TeamJoinCT", name);
							CPrintToChat(i, teamJoinMsg);
						}
						else
						{
							Format(teamJoinMsg, sizeof(teamJoinMsg), "%t", "TeamJoinCT_Old", name);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{default}", "\x01", false);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{lightgreen}", "\x03", false);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{teamcolor}", "\x03", false);
							ReplaceString(teamJoinMsg, sizeof(teamJoinMsg), "{green}", "\x04", false);
							PrintToChat(i, teamJoinMsg);
						}
					}
				}
			}
		}
	}

	return Plugin_Continue;
}

public Action TimerDelayConnectAnnounce(Handle timer, any client)
{
	ConnectAnnounce(client);
}

stock void ConnectAnnounce(int client)
{
	if(IsClientInGame(client) && !IsFakeClient(client) && connectAnnounce)
	{
		if(hideAdmin && isAdmin[client])
		{
			return;
		}
		isConnected[client] = true;
		char ip[20], name[100], country[50], from[255], clientVersion[16], finalVersion[80];
		GetClientName(client, name, sizeof(name));
		if(GetClientIP(client, ip, sizeof(ip)) && GeoipCountry(ip, country, sizeof(country)))
		{
			Format(from, sizeof(from), "%s", country);
		}
		else
		{
			Format(from, sizeof(from), "%t", "CountryUnknown");
		}
		if(CM_GetClientModVersion(client, clientVersion, sizeof(clientVersion)))
		{
			Format(finalVersion, sizeof(finalVersion), "%t", "ClientModVersion", clientVersion);
		}
		else
		{
			Format(finalVersion, sizeof(finalVersion), "%t", "ClientModVersion_Old", clientVersion);
		}
		char connectMessage[500];
		for(int i=1; i<=MaxClients; i++)
		{
			if(!IsClientInGame(i) || IsFakeClient(i))
			{
				continue;
			}
			if(CM_IsClientModUser(i))
			{
				Format(connectMessage, sizeof(connectMessage), "%t", "ConnectMessage", name, finalVersion, from);
				CPrintToChat(i, connectMessage);
			}
			else
			{
				Format(connectMessage, sizeof(connectMessage), "%t", "ConnectMessage_Old", name, finalVersion, from);
				ReplaceString(connectMessage, sizeof(connectMessage), "{default}", "\x01", false);
				ReplaceString(connectMessage, sizeof(connectMessage), "{lightgreen}", "\x03", false);
				ReplaceString(connectMessage, sizeof(connectMessage), "{teamcolor}", "\x03", false);
				ReplaceString(connectMessage, sizeof(connectMessage), "{green}", "\x04", false);
				PrintToChat(i, connectMessage);
			}
		}
	}
}