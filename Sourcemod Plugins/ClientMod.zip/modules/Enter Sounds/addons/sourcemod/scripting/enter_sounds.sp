//===== [INCLUDES] ==============
#include <sourcemod>
#include <sdktools>
#include <morecolors>
#include <clientprefs>

#pragma semicolon 1
#pragma newdecls required

//===== [CONSTANTS] ==============
#define PLUGIN_VERSION "1.7"
#define MAX_FILE_LEN 150
#define MAX_SOUNDS 10
#define MAX_DISPLAY_LENGTH 150

//===== [VARIABLES] ==============
char g_displayNames[MAX_SOUNDS][MAX_FILE_LEN], g_soundNames[MAX_SOUNDS][MAX_DISPLAY_LENGTH];
int g_numSounds;
Handle hEnterSound, hEnterSoundNotify, hEnterSoundNotifyMsg, hEnterSoundDelay, hEnterSoundNotifyDelay, hEnterSoundPlayType, hEnterSoundColorMsg;
Handle cookie_enter_sounds = INVALID_HANDLE;
bool option_enter_sounds[MAXPLAYERS + 1] = {true,...};

//===== [PLUGIN INFO] ==============
public Plugin myinfo = 
{
	name = "Enter server sound",
	author = "Kemsan, Vertigo", //New Syntax + Morecolors
	description = "Play sounds after player connect server",
	version = PLUGIN_VERSION,
	url = "vertigocss@gmail.com"
};

//===== [PLUGIN REGISTER] ==============
public void OnPluginStart()
{
	CreateConVar("sm_enter_sounds_version", PLUGIN_VERSION, "Plugin version",  FCVAR_REPLICATED|FCVAR_NOTIFY);
	hEnterSound = CreateConVar("sm_enter_sound", "1", "Enable/Disable(1/0) enter sounds", 0);
	hEnterSoundNotify = CreateConVar("sm_enter_sound_notify", "1", "Enable/Disable(1/0) notify in enter sounds", 0);
	hEnterSoundNotifyMsg = CreateConVar("sm_enter_sound_notify_msg", "{olive}You listen {green}{SOUND_NAME}{olive}. Have fun", "Sound notify msg", 0);
	hEnterSoundDelay = CreateConVar("sm_enter_sound_delay", "0.1", "Sound play delay", 0, true, 0.1);
	hEnterSoundNotifyDelay = CreateConVar("sm_enter_sound_notify_delay", "0.1", "Sound notify delay", 0, true, 0.1);
	hEnterSoundPlayType = CreateConVar("sm_enter_sound_play_type", "0", "0 - play client command (play), 1 - play from sdk sound command", 0);
	hEnterSoundColorMsg = CreateConVar("sm_enter_sound_color_msg", "1", "0 - don't use color msgs, 1 - use color msgs", 0);
	
	RegConsoleCmd("sm_joinsong", Cmd_JoinSong, "Allows players to stop hearing server join songs.");
	
	AutoExecConfig(true, "enter_sounds");	
	LoadSounds();
	
	cookie_enter_sounds = RegClientCookie("Server Join Songs On/Off", "", CookieAccess_Private);
	int info;
	SetCookieMenuItem(CookieMenuHandler_ShowDamage, view_as<any>(info), "Server Join Songs");
}

public void CookieMenuHandler_ShowDamage(int client, CookieMenuAction action, any info, char[] buffer, int maxlen)
{
	if(action == CookieMenuAction_DisplayOption)
	{
		char status[10];
		if(option_enter_sounds[client])
		{
			Format(status, sizeof(status), "On", client);
		}
		else
		{
			Format(status, sizeof(status), "Off", client);
		}		
		Format(buffer, maxlen, "Server Join Songs: %s", status, client);
	}
	// CookieMenuAction_SelectOption
	else
	{
		option_enter_sounds[client] = !option_enter_sounds[client];		
		if(option_enter_sounds[client])
		{
			SetClientCookie(client, cookie_enter_sounds, "On");
		}
		else
		{
			SetClientCookie(client, cookie_enter_sounds, "Off");
		}		
		ShowCookieMenu(client);
	}
}

public void OnClientCookiesCached(int client)
{
	option_enter_sounds[client] = GetCookieShowDamage(client);
}

bool GetCookieShowDamage(int client)
{
	char buffer[10];
	GetClientCookie(client, cookie_enter_sounds, buffer, sizeof(buffer));	
	return !StrEqual(buffer, "Off");
}

public Action Cmd_JoinSong(int client, int args)
{
	option_enter_sounds[client] = !option_enter_sounds[client];
	
	if(option_enter_sounds[client])
	{
		SetClientCookie(client, cookie_enter_sounds, "On");
		CReplyToCommand(client, "{yellow}[{red}Welcome-Song{yellow}] {orangered}You will hear songs on server join.");
	}
	else
	{
		SetClientCookie(client, cookie_enter_sounds, "Off");
		CReplyToCommand(client, "{yellow}[{red}Welcome-Song{yellow}] {orangered}You will not hear songs on server join now.");
	}
}

public void OnMapStart()
{
	if(GetConVarBool(hEnterSound))
	{
		char buffer[MAX_FILE_LEN];
		for(int i = 0; i < g_numSounds; i++)
		{
			Format(buffer, MAX_FILE_LEN, "sound/%s", g_soundNames[i]);
			AddFileToDownloadsTable(buffer);
			PrecacheSound(g_soundNames[i], true);
		}
	}
}

public void OnClientPostAdminCheck(int iClient)
{
	if(GetConVarBool(hEnterSound))
	{
		int iRandomSound = GetRandomInt(0, g_numSounds - 1);
		Handle hPack, hPackNotify;
		CreateDataTimer(GetConVarFloat(hEnterSoundDelay), Timer_PlaySound, hPack);
		WritePackCell(hPack, iClient);
		WritePackCell(hPack, iRandomSound);		
		if(GetConVarBool(hEnterSoundNotify))
		{
			CreateDataTimer(GetConVarFloat(hEnterSoundNotifyDelay), Timer_ShowNotify, hPackNotify);
			WritePackCell(hPackNotify, iClient);
			WritePackCell(hPackNotify, iRandomSound);
		}
	}
}

//===== [TIMERS] ==============
public Action Timer_PlaySound(Handle hTimer, Handle hPack)
{
	int iClient, iSound;	
	/* Set to the beginning and unpack it */
	ResetPack(hPack);
	iClient = ReadPackCell(hPack);	
	if(!option_enter_sounds[iClient]) return Plugin_Handled;	
	iSound = ReadPackCell(hPack);
	
	//Check for play exists
	if(IsValidClient(iClient))
	{
		if(GetConVarInt(hEnterSoundPlayType) == 0) ClientCommand(iClient, "play %s", g_soundNames[iSound]);
		else EmitSoundToClient(iClient, g_soundNames[iSound]);
	}
	
	return Plugin_Continue;
}

public Action Timer_ShowNotify(Handle hTimer, Handle hPack)
{
	int iClient, iSound;	
	/* Set to the beginning and unpack it */
	ResetPack(hPack);
	iClient = ReadPackCell(hPack);
	if(!option_enter_sounds[iClient]) return Plugin_Handled;
	iSound = ReadPackCell(hPack);
	
	//Check for play exists
	if(IsValidClient(iClient))
	{
		char strBuffer[512];
		GetConVarString(hEnterSoundNotifyMsg, strBuffer, sizeof(strBuffer));		
		ReplaceString(strBuffer, sizeof(strBuffer), "{SOUND_NAME}", g_displayNames[iSound]);		
		if(GetConVarInt(hEnterSoundColorMsg) == 1) CPrintToChat(iClient, strBuffer);
		else PrintToChat(iClient, strBuffer);
	}
	
	return Plugin_Continue;
}

//===== [SOUNDS] ==============
public void LoadSounds()
{
	if(GetConVarBool(hEnterSound))
	{
		char filename[MAX_FILE_LEN];
		BuildPath(Path_SM, filename, MAX_FILE_LEN, "configs/enter_sounds.txt");
		Handle hFile = OpenFile(filename, "r");		
		if(hFile == INVALID_HANDLE)
		{
			SetFailState("addons/sourcemod/configs/enter_sounds.txt not found");
			return;
		}		
		g_numSounds = 0;		
		while(!IsEndOfFile(hFile))
		{
			char line[255];
			if(!ReadFileLine(hFile, line, sizeof(line)))
			{
				break;
			}			
			/* Trim comments */
			int len = strlen(line);
			bool ignoring = false;
			for(int i = 0; i < len; i++)
			{
				if(ignoring)
				{
					if(line[i] == '"')
					{
						ignoring = false;
					}
				} 
				else 
				{
					if(line[i] == '"')
					{
						ignoring = true;
					} 
					else if(line[i] == ';') {
						line[i] = '\0';
						break;
					} 
					else if(line[i] == '/' && i != len - 1 && line[i + 1] == '/')
					{
						line[i] = '\0';
						break;
					}
				}
			}		
			TrimString(line);		
			if((line[0] == '/' && line[1] == '/') || (line[0] == ';' || line[0] == '\0'))
			{
				continue;
			}		
			g_displayNames[g_numSounds][0] = 0;
			g_soundNames[g_numSounds][0] = 0;			
			char file_name[MAX_DISPLAY_LENGTH], file_sound[MAX_FILE_LEN];	
			int cur_idx, idx;			
			cur_idx = BreakString(line, file_name, sizeof(file_name));
			strcopy(g_displayNames[g_numSounds], sizeof(g_displayNames[]), file_name);			
			idx = cur_idx;
			cur_idx = BreakString(line[idx], file_sound, sizeof(file_sound));
			strcopy(g_soundNames[g_numSounds], sizeof(g_soundNames[]), file_sound);			
			g_numSounds++;
		}	
		CloseHandle(hFile);
	}
}

//===== [STOCKS] ==============
stock bool IsValidClient(int iClient, bool bNoBots = true)
{
	if(iClient <= 0 || iClient > MaxClients || !IsClientConnected(iClient) || (bNoBots && IsFakeClient(iClient)))
	{
		return false;
	}
	
	return IsClientInGame(iClient);
}