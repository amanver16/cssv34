#include <sourcemod>
#include <clientprefs>
#include <clientmod>
#include <clientmod/multicolors>
#undef REQUIRE_PLUGIN
#include <shop>
#include <lvl_ranks>
#include <rankme>
#define REQUIRE_PLUGIN

#pragma semicolon 1
#pragma newdecls required

public Plugin myinfo =
{
	name = "[ClientMod] Rewards",
	author = "Vertigo™",
	description = "Gives rewards to players who installed ClientMod for the first time.",
	version = "1.0",
	url = "http://risserver.ddns.net/"
};

ConVar cvarShop;
ConVar cvarLR;
ConVar cvarShopCredits;
ConVar cvarLRExp;
ConVar cvarRankMe;
ConVar cvarRankMePoints;
ConVar cvarChatNotify;
ConVar cvarAdvert;
ConVar cvarAdvertInterval;

Handle g_hCMRewardCookie;
Handle g_hAdvertTimer;

bool g_bGiveRewards[MAXPLAYERS+1] = {false, ...};
bool g_bLibraryShop = false;
bool g_bLibraryLR = false;
bool g_bLibraryRankMe = false;
bool g_bShop;
bool g_bLR;
bool g_bRankMe;
bool g_bChatNotify;
bool g_bAdvert;

float g_fAdvertInterval;

int g_iShopCredits;
int g_iLRExp;
int g_iRankMePoints;


public void OnPluginStart()
{
    g_bLibraryShop = LibraryExists("shop");
    g_bLibraryLR = LibraryExists("lvl_ranks");
    g_bLibraryRankMe = LibraryExists("rankme");

    cvarShop = CreateConVar("sm_clientmod_rewards_shop", "1", "Enable/Disable shop rewards. (0 = Disabled, 1 = Enabled)", _, true, 0.0, true, 1.0);
    cvarShopCredits = CreateConVar("sm_clientmod_rewards_shop_credits", "50000", "How many shop credits to give in reward ?", _, true, 1.0);
    cvarLR = CreateConVar("sm_clientmod_rewards_lr", "1", "Enable/Disable levels ranks rewards (0 = Disabled, 1 = Enabled). [It will work only if server is using Levels Ranks ranking system]", _, true, 0.0, true, 1.0);
    cvarLRExp = CreateConVar("sm_clientmod_rewards_lr_exp", "1000", "How many LR EXPs (experience points) to give in reward ?", _, true, 1.0);
    cvarRankMe = CreateConVar("sm_clientmod_rewards_rankme", "0", "Enable/Disable RankMe rewards (0 = Disabled, 1 = Enabled). [It will work only if server is using RankMe ranking system]", _, true, 0.0, true, 1.0);
    cvarRankMePoints = CreateConVar("sm_clientmod_rewards_rankme_points", "2000", "How many RankMe points to give in reward ?", _, true, 1000.0);
    cvarChatNotify = CreateConVar("sm_clientmod_rewards_chat_notify", "1", "Enable/Disable chat notification whenever reward is granted. (0 = Disabled, 1 = Enabled)", _, true, 0.0, true, 1.0);
    cvarAdvert = CreateConVar("sm_clientmod_rewards_advert", "1", "Enable/Disable chat advertisement to old clients about the rewards for intalling ClientMod. (0 = Disabled, 1 = Enabled)", _, true, 0.0, true, 1.0);
    cvarAdvertInterval = CreateConVar("sm_clientmod_rewards_advert_interval", "20.0", "Time interval in seconds to show the advertisement.", _, true, 1.0, true, 500.0);

    g_bShop = cvarShop.BoolValue;
    g_iShopCredits = cvarShopCredits.IntValue;
    g_bLR = cvarLR.BoolValue;
    g_iLRExp =cvarLRExp.IntValue;
    g_bRankMe = cvarRankMe.BoolValue;
    g_iRankMePoints =cvarRankMePoints.IntValue;
    g_bChatNotify =cvarChatNotify.BoolValue;
    g_bAdvert =cvarAdvert.BoolValue;
    g_fAdvertInterval =cvarAdvertInterval.FloatValue;
    
    cvarShop.AddChangeHook(OnShopCvarChanged);
    cvarShopCredits.AddChangeHook(OnShopCreditsCvarChanged);
    cvarLR.AddChangeHook(OnLRCvarChanged);
    cvarLRExp.AddChangeHook(OnLRExpCvarChanged);
    cvarRankMe.AddChangeHook(OnRankMeCvarChanged);
    cvarRankMePoints.AddChangeHook(OnRankMePointsCvarChanged);
    cvarChatNotify.AddChangeHook(OnChatNotifyCvarChanged);
    cvarAdvert.AddChangeHook(OnAdvertCvarChanged);
    cvarAdvertInterval.AddChangeHook(OnAdvertIntervalCvarChanged);

    g_hCMRewardCookie = RegClientCookie("clientmod_rewards", "Cookie for ClientMod Rewards", CookieAccess_Private);
    AutoExecConfig(true, "clientmod_rewards");
    LoadTranslations("clientmod_rewards.phrases");

    if(g_bAdvert)
    {
        g_hAdvertTimer = CreateTimer(g_fAdvertInterval, Timer_ShowAdvert, _, TIMER_REPEAT);
    }
}

public void OnPluginEnd()
{
    if(g_hAdvertTimer != null)
    {
        delete g_hAdvertTimer;
    }
}

public void OnShopCvarChanged(ConVar cvar, const char[] oldValue, const char[] newValue)
{
    g_bShop = cvar.BoolValue;
}

public void OnShopCreditsCvarChanged(ConVar cvar, const char[] oldValue, const char[] newValue)
{
    g_iShopCredits = cvar.IntValue;
}

public void OnLRCvarChanged(ConVar cvar, const char[] oldValue, const char[] newValue)
{
    g_bLR = cvar.BoolValue;
}

public void OnLRExpCvarChanged(ConVar cvar, const char[] oldValue, const char[] newValue)
{
    g_iLRExp =cvar.IntValue;
}

public void OnRankMeCvarChanged(ConVar cvar, const char[] oldValue, const char[] newValue)
{
    g_bRankMe = cvar.BoolValue;
}

public void OnRankMePointsCvarChanged(ConVar cvar, const char[] oldValue, const char[] newValue)
{
    g_iRankMePoints =cvar.IntValue;
}

public void OnChatNotifyCvarChanged(ConVar cvar, const char[] oldValue, const char[] newValue)
{
    g_bChatNotify =cvar.BoolValue;
}

public void OnAdvertCvarChanged(ConVar cvar, const char[] oldValue, const char[] newValue)
{
    g_bAdvert =cvar.BoolValue;

    if(!g_bAdvert && g_hAdvertTimer != null)
    {
        delete g_hAdvertTimer;
    }
}

public void OnAdvertIntervalCvarChanged(ConVar cvar, const char[] oldValue, const char[] newValue)
{
    g_fAdvertInterval =cvar.FloatValue;
}

public void OnLibraryRemoved(const char[] name)
{
    if(StrEqual(name, "shop"))
    {
        g_bLibraryShop = false;
    }

    if(StrEqual(name, "lvl_ranks"))
    {
        g_bLibraryLR = false;
    }

    if(StrEqual(name, "rankme"))
    {
        g_bLibraryRankMe = false;
    }
}

public void OnLibraryAdded(const char[] name)
{
    if(StrEqual(name, "shop"))
    {
        g_bLibraryShop = true;
    }

    if(StrEqual(name, "lvl_ranks"))
    {
        g_bLibraryLR = true;
    }

    if(StrEqual(name, "rankme"))
    {
        g_bLibraryRankMe = true;
    }
}

public Action Timer_ShowAdvert(Handle timer)
{
    if(g_bLibraryShop && g_bShop)
    {
        C_PrintToChatAll("%t%t", "Prefix_Old", "Shop_Advert_Old", g_iShopCredits);
    }
    
    if(g_bLibraryLR && g_bLR)
    {
        C_PrintToChatAll("%t%t", "Prefix_Old", "LR_Advert_Old", g_iLRExp);
    }
    
    if(g_bLibraryRankMe && g_bRankMe)
    {
        C_PrintToChatAll("%t%t", "Prefix_Old", "RankMe_Advert_Old", g_iRankMePoints);
    }

    return Plugin_Continue;
}

public void OnClientCookiesCached(int client)
{
	if(!IsFakeClient(client)) 
	{
		char cookie[3];
		GetClientCookie(client, g_hCMRewardCookie, cookie, sizeof(cookie));
		if(cookie[0])
        {
            g_bGiveRewards[client] = view_as<bool>(StringToInt(cookie));
        }
	}
}

public void OnClientPostAdminCheck(int client)
{
    if(client && !IsFakeClient(client) && CM_IsClientModUser(client))
    {
        CreateTimer(3.0, Timer_GiveRewards, GetClientSerial(client), TIMER_FLAG_NO_MAPCHANGE);
    }
}

public Action Timer_GiveRewards(Handle timer, int clientSerial)
{
    int client = GetClientFromSerial(clientSerial);

    if(IsClientInGame(client) && !g_bGiveRewards[client])
    {
        if(g_bLibraryShop && g_bShop)
        {
            if(!Shop_IsStarted())
            {
                return Plugin_Handled;
            }
            int currentCredits = Shop_GetClientCredits(client);
            if(currentCredits != -1 && currentCredits > 10)
            {
                return Plugin_Handled;
            }
            int totalShopCredits = Shop_GiveClientCredits(client, g_iShopCredits);
            if(totalShopCredits >= g_iShopCredits && g_bChatNotify)
            {
                MC_PrintToChat(client, "%t%t", "Prefix", "Shop_Reward", g_iShopCredits);
                C_PrintToChatAll("%t%t", "Prefix_Old", "Shop_Reward_Old", client, g_iShopCredits);
            }
        }
        if(g_bLibraryLR && g_bLR)
        {
            if(!LR_IsLoaded())
            {
                return Plugin_Handled;
            }
            int currentExp = LR_GetClientInfo(client, ST_EXP, false);
            if(currentExp > 10)
            {
                return Plugin_Handled;
            }
            bool isExpGranted = LR_ChangeClientValue(client, g_iLRExp);
            if(isExpGranted && g_bChatNotify)
            {
                MC_PrintToChat(client, "%t%t", "Prefix", "LR_Reward", g_iLRExp);
                C_PrintToChatAll("%t%t", "Prefix_Old", "LR_Reward_Old", client, g_iLRExp);
            }
        }
        if(g_bLibraryRankMe && g_bRankMe)
        {
            int currentPoints = RankMe_GetPoints(client);
            if(currentPoints > 1010)
            {
                return Plugin_Handled;
            }
            RankMe_GivePoint(client, g_iRankMePoints, "", 0, 0);
            if(g_bChatNotify)
            {
                MC_PrintToChat(client, "%t%t", "Prefix", "RankMe_Reward", g_iRankMePoints);
                C_PrintToChatAll("%t%t", "Prefix_Old", "RankMe_Reward_Old", client, g_iRankMePoints);
            }
        }
        g_bGiveRewards[client] = true;
        SetClientCookie(client, g_hCMRewardCookie, "1");
    }

    return Plugin_Handled;
}

public void OnClientDisconnect(int client)
{
    g_bGiveRewards[client] = false;
}