#include <sourcemod>
#include <clientmod>

#pragma semicolon 1
#pragma newdecls required

public Plugin myinfo =
{
	name = "ClientMod Tags",
	author = "Reg1oxeN, Vertigo™",
	description = "Adds tags to server in internet Tab.",
	version = CM_VERSION,
	url = CM_URL
};

ConVar g_DefaultTags;
bool isRemoveDefaultTags;

public void OnPluginStart()
{
	g_DefaultTags = CreateConVar("clientmod_tags_default", "0", "Remove default tags? [cm, private] (0 - Don't Remove, 1 - Remove).", 0, true, 0.0, true, 1.0);
	g_DefaultTags.AddChangeHook(DefaultTagsCvarHook);
	
	AutoExecConfig(true, "ClientMod_Tags");
}

public void DefaultTagsCvarHook(ConVar convar, const char[] oldValue, const char[] newValue)
{
	isRemoveDefaultTags = g_DefaultTags.BoolValue;
}

public void OnAllPluginsLoaded()
{
	isRemoveDefaultTags = g_DefaultTags.BoolValue;

	if(isRemoveDefaultTags)
	{
		CM_RemoveTag("cm");
		CM_RemoveTag("private");
	}
	
	char clFilepath[PLATFORM_MAX_PATH], tag[30];
	Handle clFileHandle;
	BuildPath(Path_SM, clFilepath, PLATFORM_MAX_PATH, "configs/clientmod_tags.txt");
	clFileHandle = OpenFile(clFilepath, "r");
	
	while(!IsEndOfFile(clFileHandle))
	{
		ReadFileLine(clFileHandle, tag, sizeof(tag));
		TrimString(tag);
		CM_AddTag(tag);
	}
	
	CloseHandle(clFileHandle);
}
