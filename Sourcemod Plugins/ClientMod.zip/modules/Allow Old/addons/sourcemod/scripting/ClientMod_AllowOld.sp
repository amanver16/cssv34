#include <sourcemod>
#include <sdktools>
#include <clientmod>

#pragma semicolon 1
#pragma newdecls required

ConVar cvarAllowOldUserJoinTeam, cvarNotifyUser, cvarAccessDeniedSound, cvarAdminFlags;
bool g_bAllowOldUserJoinTeam, g_bAccessDeniedSound;
int g_iNotifyUser, g_iAdminFlags;
char sAdminFlags[26];
ArrayList whitelistedSteamIdList = null;

public Plugin myinfo =
{
	name = "[ClientMod] Allow Old",
	author = "Vertigo™",
	description = "Allow Old",
	version = "1.2",
	url = "https://risserver.in/forum/resources/clientmod-allow-old.164/"
};

public void OnPluginStart()
{
	cvarAllowOldUserJoinTeam = CreateConVar("sm_clientmod_allow_old_user_teamjoin", "0", "Allow non-clientmod users to join a team ? (0 - Don't allow, 1- Allow)", _, true, 0.0, true, 1.0);
	cvarNotifyUser = CreateConVar("sm_clientmod_user_notify", "3", "How to notify users if non-clientmod users are not allowed to join team ?\n0 - Do not notify\n1 - Notify in chat only\n2 - Notify in menu only\n3 - Notify in both chat and menu.", _, true, 0.0, true, 3.0);
	cvarAccessDeniedSound = CreateConVar("sm_clientmod_access_denied_sound", "1", "Play sound if non-clientmod users are not allowed to join team ? (0 - Do not play sound, 1- Play Sound)", _, true, 0.0, true, 1.0);
	cvarAdminFlags = CreateConVar("sm_clientmod_aw_admin_flags", "", "Specify admin flags immune to this plugin check. You can use one or more flags.\nEx: zabc, Empty flag means all players are checked.");

	cvarAllowOldUserJoinTeam.AddChangeHook(JoinTeam_Cvar_Changed);
	cvarNotifyUser.AddChangeHook(NotifyUser_Cvar_Changed);
	cvarAccessDeniedSound.AddChangeHook(AccessDenied_Cvar_Changed);
	cvarAdminFlags.AddChangeHook(AdminFlags_Cvar_Changed);

	g_iNotifyUser = cvarNotifyUser.IntValue;
	g_bAllowOldUserJoinTeam = cvarAllowOldUserJoinTeam.BoolValue;
	g_bAccessDeniedSound = cvarAccessDeniedSound.BoolValue;
	cvarAdminFlags.GetString(sAdminFlags, 26);
	g_iAdminFlags = ReadFlagString(sAdminFlags);

	LoadWhitelistedSteamIDs();
	RegConsoleCmd("jointeam", ChooseTeam);
	RegAdminCmd("sm_reload_allow_old_config", Command_ReloadConfig, ADMFLAG_ROOT, "Reloads the steamid whitelist config.");
	AutoExecConfig(true, "clientmod/ClientMod_AllowOld");
}

public void JoinTeam_Cvar_Changed(ConVar cvar, char[] oldValue, char[] newValue)
{
	g_bAllowOldUserJoinTeam = cvar.BoolValue;
}

public void NotifyUser_Cvar_Changed(ConVar cvar, char[] oldValue, char[] newValue)
{
	g_iNotifyUser = cvar.IntValue;
}

public void AccessDenied_Cvar_Changed(ConVar cvar, char[] oldValue, char[] newValue)
{
	g_bAccessDeniedSound = cvar.BoolValue;
}

public void AdminFlags_Cvar_Changed(ConVar cvar, char[] oldValue, char[] newValue)
{
	cvar.GetString(sAdminFlags, 26);
	g_iAdminFlags = ReadFlagString(sAdminFlags);
}

public void OnConfigsExecuted()
{
	ServerCommand("sm_cvar clientmod_private 0");
	g_iNotifyUser = cvarNotifyUser.IntValue;
	g_bAllowOldUserJoinTeam = cvarAllowOldUserJoinTeam.BoolValue;
	g_bAccessDeniedSound = cvarAccessDeniedSound.BoolValue;
}

public Action ChooseTeam(int iClient, int iArgs)     
{
	char sName[100], sSteamID[100];
	GetClientName(iClient, sName, 100);
	GetClientAuthId(iClient, AuthId_Engine, sSteamID, 100);

	if (whitelistedSteamIdList.FindString(sSteamID) > -1)
	{
		return Plugin_Continue;
	}

	if (GetUserFlagBits(iClient) & g_iAdminFlags == g_iAdminFlags)
	{
		return Plugin_Continue;
	}
	
	if(!CM_IsClientModUser(iClient) && !g_bAllowOldUserJoinTeam)
	{
		ChangeClientTeam(iClient, 1);
		if(g_bAccessDeniedSound)
		{
			ClientCommand(iClient, "playgamesound buttons/weapon_cant_buy.wav");
		}
		if(g_iNotifyUser==1 || g_iNotifyUser==3)
		{
			PrintToChat(iClient, "\x04----------------------------------------------------");
			PrintToChat(iClient, "\x04Welcome \x03%s.", sName);
			PrintToChat(iClient, "\x04----------------------------------------------------");
			PrintToChat(iClient, "\x03[\x04ClientMod\x03] \x04You are not a \x03ClientMod \x04user, so you can not join any team to play.");
			PrintToChat(iClient, "\x03[\x04ClientMod\x03] \x04Download and install Clientmod in order to play on this server.");
			PrintToChat(iClient, "\x03[\x04ClientMod\x03] \x04Download Link \x01: \x03https://risserver.in/cm");
			PrintToChat(iClient, "\x03[\x04ClientMod\x03] \x04Download Link \x01: \x03https://clientmod.ru/");
		}
		if(g_iNotifyUser==2 || g_iNotifyUser==3)
		{
			Panel panel = new Panel();
			char title[256];
			FormatEx(title, sizeof(title), "-------------Welcome %s-------------", sName);
			panel.SetTitle(title);
			panel.DrawItem("You are not allowed to join any team.", ITEMDRAW_RAWLINE);
			panel.DrawItem("Because you are not a ClientMod user.", ITEMDRAW_RAWLINE);
			panel.DrawItem("ClientMod is enhanced version of CSS v34 with many features.", ITEMDRAW_RAWLINE);
			panel.DrawItem("You must download & Install ClientMod to play on this server.", ITEMDRAW_RAWLINE);
			panel.DrawItem("Download link : https://risserver.in/cm", ITEMDRAW_RAWLINE);
			panel.DrawItem("Download link : https://clientmod.ru/", ITEMDRAW_RAWLINE);
			panel.DrawItem(" ", ITEMDRAW_RAWLINE);
			panel.DrawItem("You can copy the link from the chat below.", ITEMDRAW_RAWLINE);
			panel.DrawItem(" ", ITEMDRAW_RAWLINE);
			panel.DrawItem("Exit", ITEMDRAW_CONTROL);
			panel.Send(iClient, Panel_HandlerCM, MENU_TIME_FOREVER);
			delete panel;
		}

		LogMessage("Non-Clientmod user [%s] is not allowed to join the team.", sName);
	}
	else
	{
		LogMessage("Clientmod user [%s] is allowed to join the team.", sName);
	}

	return Plugin_Continue;
}

public int Panel_HandlerCM(Menu menu, MenuAction action, int param1, int param2)
{
	// Do nothing
}

stock void LoadWhitelistedSteamIDs()
{
	char sWhitelistFile[PLATFORM_MAX_PATH];
	BuildPath(Path_SM, sWhitelistFile, PLATFORM_MAX_PATH, "configs/clientmod/allow_old_whitelist.cfg");
	File file = OpenFile(sWhitelistFile, "r");
	
	if (file == null)
	{
		SetFailState("The file %s does not exist. Please check if file exists in mentioned folder.", sWhitelistFile);
	}
	
	delete whitelistedSteamIdList;
	whitelistedSteamIdList = new ArrayList(ByteCountToCells(64));
	char sSteamID[100];
	
	while(!IsEndOfFile(file) && ReadFileLine(file, sSteamID, 100))
	{
		TrimString(sSteamID);
		if (sSteamID[0] == '/' || StrContains(sSteamID, "STEAM", false) == -1)
		{
			continue;
		}
		whitelistedSteamIdList.PushString(sSteamID);
	}
}

public Action Command_ReloadConfig(int iClient, int iArgs)
{
	LoadWhitelistedSteamIDs();
	ReplyToCommand(iClient, "[ClientMod] Successfully reloaded config.");
}