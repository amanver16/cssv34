#include <sdktools>

public Plugin:myinfo =
{
	name = "Leaves | de_dust2",
	author = "Incognito | OLD Freelance",
	description = "Листья на Middle около респавна CT на de_dust2",
	version = "1.0",
	url = "https://vk.com/oldfreelance"
}

public OnMapStart()
{
    new String:m[256];
    GetCurrentMap(m,256);
    if(strcmp(m,"de_dust2"))
        UnhookEvent("round_start",E,EventHookMode_PostNoCopy);
    PrecacheModel("models/props/cs_militia/fern01lg.mdl");
    HookEvent("round_start",E,EventHookMode_PostNoCopy);
}

public E(Handle:event, const String:name[], bool:dontBroadcast)
{
    new Float:angels[][] = 
    {
        {0.0,      164.0  , 0.0},
        {-10.9374, 200.25 , -42.3712},
        {-6.22507, 185.384, -20.1112},
        {-6.22507, 205.884, -20.1112},
        {-6.22507, 145.384, -20.1112},
        {-6.22507, 157.884, -20.1112},
        {0.0,      164.0  ,  0.0},
        {-6.31013, 165.267, -22.6834},
        {-6.31013, 142.767, -22.6834},
        {-6.31013, 194.267, -22.6834}, 
        {-6.31013, 222.767, -22.6834},
        {-3.31426, 197.938, -30.6671},
        {-3.31426, 230.438, -30.6671},
        {-3.31426, 155.438, -30.6671},
        {-1.96249, 175.937, -9.1861},
        {-1.96249, 175.937, -9.1861}
    };
    new Float:origin[][] = 
    {
        {-1015.0,2585.0, 55.0},
        {-700.0, 2642.0, 126.58},
        {-770.0, 2602.0, 35.0},
        {-672.0, 2509.0, -38.0},
        {-385.0, 2473.0, -54.0},
        {-349.0, 2566.0, 156.0},
        {-1190.0,2764.0, 276.0},
        {-988.0, 2685.0, 410.0},
        {-1112.0,2794.0, 479.0},
        {-944.0, 2802.0, 502.0},
        {-786.0, 2771.0, 473.0},
        {-635.0, 2733.0, 292.0},
        {-504.0, 2673.0, 284.0},
        {-409.0, 2695.0, 443.0},
        {-589.0, 2872.0, 384.0},
        {-545.0, 2528.0, 173.0}
    };
    decl e,entity;
    e = 0;
    entity = 0;
    while(e < 16)
    {
        entity = CreateEntityByName("prop_dynamic_override");
        
        if (entity == -1)
            return;
        
        SetEntityModel(entity, "models/props/cs_militia/fern01lg.mdl");
        DispatchSpawn(entity);
        TeleportEntity(entity,origin[e], angels[e], NULL_VECTOR);
        e++;
    }
}