#include <sourcemod>
#include <sdkhooks>
#include <morecolors>

#pragma semicolon 1
#pragma newdecls required

#define PLUGIN_VERSION "1.4.3"

public Plugin myinfo = 
{
    name = "NoBlock",
    author = "Otstrel.ru Team, Vertigo",
    description = "Removes player collisions.",
    version = PLUGIN_VERSION,
    url = "http://otstrel.ru"
};

// ===========================================================================
// GLOBALS
// ===========================================================================

int g_offsCollisionGroup;
bool g_enabled, g_enabled_nades, g_enabled_hostages, g_noblock_allow_block;
float g_noblock_allow_block_time, g_blockTime;
Handle sm_noblock, sm_noblock_nades, sm_noblock_hostages, sm_noblock_allow_block, sm_noblock_allow_block_time, g_hTimer[MAXPLAYERS+1], sm_noblock_blockafterspawn_time;

// ===========================================================================
// LOAD & UNLOAD
// ===========================================================================

public void OnPluginStart()
{
    Handle Cvar_Version = CreateConVar("sm_noblock_version", PLUGIN_VERSION, "NoBlock Version", FCVAR_SPONLY|FCVAR_REPLICATED|FCVAR_NOTIFY);
    /* Just to make sure they it updates the convar version if they just had the plugin reload on map change */
    SetConVarString(Cvar_Version, PLUGIN_VERSION);
    
    g_offsCollisionGroup = FindSendPropInfo("CBaseEntity", "m_CollisionGroup");
	
    if(g_offsCollisionGroup == -1)
    {
        SetFailState("[NoBlock] Failed to get offset for CBaseEntity::m_CollisionGroup.");
    }
    
    sm_noblock = CreateConVar("sm_noblock", "1", "Removes player vs. player collisions");
    g_enabled = GetConVarBool(sm_noblock);
    HookConVarChange(sm_noblock, OnConVarChange);

    sm_noblock_nades = CreateConVar("sm_noblock_nades", "1", "Removes player vs. nade collisions");
    g_enabled_nades = GetConVarBool(sm_noblock_nades);
    HookConVarChange(sm_noblock_nades, OnConVarChange);

    sm_noblock_hostages = CreateConVar("sm_noblock_hostages", "0", "Removes player vs. hostage collisions");
    g_enabled_hostages = GetConVarBool(sm_noblock_hostages);
    HookConVarChange(sm_noblock_hostages, OnConVarChange);

    sm_noblock_allow_block = CreateConVar("sm_noblock_allow_block", "1.0", "Allow players to use say !block", _, true, 0.0, true, 1.0);
    g_noblock_allow_block = GetConVarBool(sm_noblock_allow_block);
    HookConVarChange(sm_noblock_allow_block, OnConVarChange);

    sm_noblock_allow_block_time = CreateConVar("sm_noblock_allow_block_time", "15.0", "Time limit to say !block command", _, true, 0.0, true, 600.0);
    g_noblock_allow_block_time = GetConVarFloat(sm_noblock_allow_block_time);
    HookConVarChange(sm_noblock_allow_block_time, OnConVarChange);

    sm_noblock_blockafterspawn_time = CreateConVar("sm_noblock_blockafterspawn_time", "0.0", "Disable blocking only for that time from spawn.", _, true, 0.0, true, 600.0);
    g_blockTime = GetConVarFloat(sm_noblock_blockafterspawn_time);
    HookConVarChange(sm_noblock_blockafterspawn_time, OnConVarChange);
    
    if(g_enabled)
	{
        StartHook();
    }

    RegConsoleCmd("say", Command_Say);
    RegConsoleCmd("say_team", Command_Say);
}

// ===========================================================================
// EVENTS
// ===========================================================================

public void OnConVarChange(Handle hCvar, const char[] oldValue, const char[] newValue)
{
    if(hCvar == sm_noblock){
        g_enabled = GetConVarBool(sm_noblock);
        if(g_enabled) {
            UnblockClientAll();
            if(sm_noblock_hostages) {
                UnblockHostages();
            }
            StartHook();
        } else {
            StopHook();
            BlockClientAll();
            if(sm_noblock_hostages) {
                BlockHostages();
            }
        }
        return;
    }
	
    if(hCvar == sm_noblock_nades) {
        g_enabled_nades = GetConVarBool(sm_noblock_nades);
        return;
    }
	
    if(hCvar == sm_noblock_hostages) {
        g_enabled_hostages = GetConVarBool(sm_noblock_hostages);
        if(g_enabled) {
            if(g_enabled_hostages) {
                UnblockHostages();
                HookEvent("round_start", OnRoundStart, EventHookMode_Post);
            } else {
                UnhookEvent("round_start", OnRoundStart, EventHookMode_Post);
                BlockHostages();
            }
        }
        return;
    }
	
    if(hCvar == sm_noblock_blockafterspawn_time) {
        g_blockTime = GetConVarFloat(sm_noblock_blockafterspawn_time);
        return;
    }
	
    if(hCvar == sm_noblock_allow_block) {
        g_noblock_allow_block = GetConVarBool(sm_noblock_allow_block);
        return;
    }
	
    if(hCvar == sm_noblock_allow_block_time) {
        g_noblock_allow_block_time = GetConVarFloat(sm_noblock_allow_block_time);
        return;
    }
}

public void OnSpawn(Handle event, const char[] name, bool dontBroadcast)
{
    int userid = GetEventInt(event, "userid");
    int client = GetClientOfUserId(userid);
	
    if(g_hTimer[client] != INVALID_HANDLE)
    {
        CloseHandle(g_hTimer[client]);
        g_hTimer[client] = INVALID_HANDLE;
        CPrintToChat(client, "{white}[{fullblue}NoBlock{white}] {teal}Blocking has been Disabled because of respawn.");
    }

    UnblockEntity(client);
    
    if(g_blockTime)
    {
        CreateTimer(g_blockTime, Timer_PlayerBlock, client);
    }
}

//Enable NoBlock on hostages on roundstart
public void OnRoundStart(Handle event, const char[] name, bool dontBroadcast)
{
   UnblockHostages();
}

public Action Command_Say(int client, int args)
{
    if(!g_enabled || !client || !g_noblock_allow_block)
    {
        return Plugin_Continue;
    }

    char text[192], command[64];
    int startidx = 0;
	
    if(GetCmdArgString(text, sizeof(text)) < 1)
    {
        return Plugin_Continue;
    }
 
    if(text[strlen(text)-1] == '"')
    {
        text[strlen(text)-1] = '\0';
        startidx = 1;
    }

    if(strcmp(command, "say2", false) == 0)
    {
        startidx += 4;
    }

    if((strcmp(text[startidx], "!block", false) == 0) && !g_blockTime)
    {
        if(g_hTimer[client] != INVALID_HANDLE)
        {
            CloseHandle(g_hTimer[client]);
            g_hTimer[client] = INVALID_HANDLE;            
            CPrintToChat(client, "{white}[{fullblue}NoBlock{white}] {teal}Blocking has been Disabled by the client.");
            UnblockEntity(client);
            return Plugin_Continue;
        }
        g_hTimer[client] = CreateTimer(g_noblock_allow_block_time, Timer_PlayerUnblock, client);
        CPrintToChat(client, "{white}[{fullblue}NoBlock{white}] {teal}Blocking has been Enabled for {fullred}%.0f {teal}seconds.", g_noblock_allow_block_time);
        BlockEntity(client);
    }
 
    return Plugin_Continue;
}

//Player Blocking Expires
public Action Timer_PlayerUnblock(Handle timer, any client)
{
    //Disable Blocking on the Client
    g_hTimer[client] = INVALID_HANDLE;
	
    if(!g_enabled || !client || !IsClientInGame(client) || !IsPlayerAlive(client))
    {
        return Plugin_Continue;
    }
    
    CPrintToChat(client, "{white}[{fullblue}NoBlock{white}] {teal}Blocking is now Disabled.");
    UnblockEntity(client);
    return Plugin_Continue;
}

public Action Timer_PlayerBlock(Handle timer, any client)
{
    //Enable Blocking on the Client
    if(!g_enabled || !client || !IsClientInGame(client) || !IsPlayerAlive(client))
    {
        return Plugin_Continue;
    }
    
    BlockEntity(client);
    return Plugin_Continue;
}

public void OnEntityCreated(int entity, const char[] classname)
{
    if(g_enabled_nades)
    {
        //Enable NoBlock on Nades
        if(StrEqual(classname, "hegrenade_projectile")) {
            UnblockEntity(entity);
        } else if(StrEqual(classname, "flashbang_projectile")) {
            UnblockEntity(entity);
        } else if(StrEqual(classname, "smokegrenade_projectile")) {
            UnblockEntity(entity);
        }
    }
}

// ===========================================================================
// HELPERS
// ===========================================================================

void StartHook() {
    HookEvent("player_spawn", OnSpawn, EventHookMode_Post);
	
    if(g_enabled_hostages) {
        HookEvent("round_start", OnRoundStart, EventHookMode_Post);
    }
}

void StopHook() {
    UnhookEvent("player_spawn", OnSpawn, EventHookMode_Post);
	
    if(g_enabled_hostages) {
        UnhookEvent("round_start", OnRoundStart, EventHookMode_Post);
    }
}

void UnblockHostages() {
    char sClassName[32];
    int iMaxEntities = GetMaxEntities();
    
    /* Apparently the clients are always at the start of the entity list,
        so we can skip them in hopes of reducing roundstart lag */        
    for(int iEntity = MaxClients + 1; iEntity < iMaxEntities; iEntity++)
    {
        if(!IsValidEntity(iEntity) || !IsValidEdict(iEntity)) {
            continue;
        }        
        GetEdictClassname(iEntity, sClassName, sizeof(sClassName));
        if(StrEqual("hostage_entity", sClassName)) {
            UnblockEntity(iEntity);
        }
    }
}    

void BlockHostages() {
    char sClassName[32];
    int iMaxEntities = GetMaxEntities();
    
    /* Apparently the clients are always at the start of the entity list,
        so we can skip them in hopes of reducing roundstart lag */        
    for(int iEntity = MaxClients + 1; iEntity < iMaxEntities; iEntity++)
    {
        if(!IsValidEntity(iEntity) || !IsValidEdict(iEntity)) {
            continue;
        }        
        GetEdictClassname(iEntity, sClassName, sizeof(sClassName));
        if(StrEqual("hostage_entity", sClassName)) {
            BlockEntity(iEntity);
        }
    }
}    

void BlockEntity(int client)
{
    SetEntData(client, g_offsCollisionGroup, 5, 4, true);
}

void UnblockEntity(int client)
{
    SetEntData(client, g_offsCollisionGroup, 2, 4, true);
}

void BlockClientAll()
{
    for(int i = 1; i <= MaxClients; i++)
    {
        if(IsClientInGame(i) && IsPlayerAlive(i))
        {
            BlockEntity(i);
        }
    }
}

void UnblockClientAll()
{
    for(int i = 1; i <= MaxClients; i++)
    {
        if(IsClientInGame(i) && IsPlayerAlive(i))
        {
            UnblockEntity(i);
        }
    }
}