#include <sourcemod>
#include <sdktools>

#pragma semicolon 1
#pragma newdecls required

#define PLUGIN_NAME	"Quick Join"
#define PLUGIN_VERSION	"1.1"
#define PLUGIN_URL	"www.sourcemod.net"

public Plugin myinfo = 
{
	name = PLUGIN_NAME,
	author = "NineTyNine, Vertigo™, SuBu aka return 0;",
	description = "A simple plugin that lets a player join a team quickly.",
	version = PLUGIN_VERSION,
	url = PLUGIN_URL
}

public void OnPluginStart()
{	
	RegConsoleCmd("sm_sp", QJTurnClientToSpectate);
	RegConsoleCmd("sm_away", QJTurnClientToSpectate);
	RegConsoleCmd("sm_afk", QJTurnClientToSpectate);
	RegConsoleCmd("sm_ct", QJTurnClientToCounterTerrorist);
	RegConsoleCmd("sm_t", QJTurnClientToTerrorist);
}

public Action QJTurnClientToSpectate(int client, int argCount)
{
	if(client <= 0) return Plugin_Handled;
	if(IsPlayerAlive(client)) ForcePlayerSuicide(client);
	ChangeClientTeam(client, 1);
	PrintToChat(client, "\x03[\x04QuickJoin\x03] \x01You Have Been Moved To Spectators.");
	return Plugin_Handled;
}

public Action QJTurnClientToTerrorist(int client, int args)
{ 
	ClientCommand(client, "jointeam 2");
	PrintToChat(client, "\x03[\x04QuickJoin\x03] \x01You Have Been Moved To Team Terrorists.");
	return Plugin_Handled;
}
public Action QJTurnClientToCounterTerrorist(int client, int args)
{ 
	ClientCommand(client, "jointeam 3");
	PrintToChat(client, "\x03[\x04QuickJoin\x03] \x01You Have Been Moved To Team Counter-Terrorists.");
	return Plugin_Handled;
}