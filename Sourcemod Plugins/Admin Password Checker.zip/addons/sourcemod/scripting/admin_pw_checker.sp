#include <sourcemod>
#include <regex>

#pragma semicolon 1
#pragma newdecls required

static const char g_sLogPath[] = "addons/sourcemod/logs/admin_password_checker.log";
char sInfoVar[32];

public Plugin myinfo = 
{
	name = "Admin Password Checker", 
	author = "Danyas, Vertigo™",
	description = "Checks admin password at admin connect.",
	version = "1.3.2",
	url = "http://risserver.ddns.net/"
}

public void OnPluginStart()
{
	if(!GetPassInfoVar(sInfoVar, sizeof(sInfoVar)))
	{
		SetFailState("PassInfoVar not found in core.cfg");
	}
}

public Action OnClientPreAdminCheck(int client)
{
	if (client > 0)
	{
		char sBuff[64], sPassword[64];
		GetClientAuthId(client, AuthId_Engine, sBuff, sizeof(sBuff));
		AdminId admin = FindAdminByIdentity(AUTHMETHOD_STEAM, sBuff);
		
		if(admin != INVALID_ADMIN_ID)
		{
			if (GetAdminPassword(admin, sPassword, sizeof(sPassword)))
			{
				if(GetClientInfo(client, sInfoVar, sBuff, sizeof(sBuff)) && sBuff[0] != 0)
				{
					if (!StrEqual(sPassword, sBuff))
					{
						KickClient(client, "Your admin password is wrong. Try again!!\nPassword Used: %s", sBuff);
						LogToFileEx(g_sLogPath, "%L<%s> tried to login with password %s", client, GetClientIP(client, sPassword, 21) ? sPassword : "?", sBuff);
					}
				}
				else 
				{
					KickClient(client, "Please enter the admin password in console and reconnect.\nsetinfo _pw password");
					LogToFileEx(g_sLogPath, "%L<%s> tried to login without password.", client, GetClientIP(client, sPassword, 21) ? sPassword : "?");
				}
			}
		}
	}
}


bool GetPassInfoVar(char[] value, int maxlength)
{
	Handle file = OpenFile("addons/sourcemod/configs/core.cfg", "rt");
	
	if(file != INVALID_HANDLE)
	{
		Handle re = CompileRegex("^\\s+\"PassInfoVar\"\\s+\"(\\w+)\""); // ([^\"]*)
		if(re != INVALID_HANDLE)
		{
			char buffer[PLATFORM_MAX_PATH];
			while(!IsEndOfFile(file) && ReadFileLine(file, buffer, sizeof(buffer)))
			{
				if (MatchRegex(re, buffer) > 0 && GetRegexSubString(re, 1, value, maxlength))
				{
					CloseHandle(re);
					CloseHandle(file);
					return true;
				}
			}
			CloseHandle(re);
		}
		CloseHandle(file);
	}
	
	return false;
}