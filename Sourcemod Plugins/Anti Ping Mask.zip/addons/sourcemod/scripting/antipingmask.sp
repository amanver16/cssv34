#include <sourcemod>
#include <sdktools>
#include <regex>
#include <morecolors>

#pragma semicolon 1
#pragma newdecls required

#define PLUGIN_VERSION "1.6.0"
#define DEFAULT_TIMER_FLAGS TIMER_REPEAT | TIMER_FLAG_NO_MAPCHANGE

public Plugin myinfo = {
	name 		= "Anti-Ping Mask",
	author 		= "atom0s, Vertigo", // Code Optimization
	description 	= "Prevents ping masking via cl_cmdrate exploit.",
	version 		= PLUGIN_VERSION,
	url 			= "vertigocss@gmail.com"
};

Handle t_TimerHandle = INVALID_HANDLE;
Handle g_Cvar_Handler = INVALID_HANDLE;
Handle g_Cvar_BanLength = INVALID_HANDLE;
Handle g_Cvar_TimerInterval = INVALID_HANDLE;

public void OnPluginStart()
{
	CreateConVar("antipingmask_version", PLUGIN_VERSION, "Anti-Ping Mask Version Number", FCVAR_REPLICATED | FCVAR_NOTIFY | FCVAR_DONTRECORD);
	
	g_Cvar_Handler = CreateConVar("apm_handler", "0", "Determines how Anti-Ping Mask should handle ping masked clients. (0 - Kick | 1 -Ban)", 0, true, 0.0, true, 2.0);
	g_Cvar_BanLength = CreateConVar("apm_banlength", "30", "The length in minutes that a player is banned for ping masking.", 0);
	g_Cvar_TimerInterval = CreateConVar("apm_timerinterval", "20", "The interval time, in seconds, that the timer should tick at to check for ping masking clients.", 0);
	
	HookConVarChange(g_Cvar_TimerInterval, TimerIntervalChanged);
	AutoExecConfig(true, "antipingmask");
}

public void OnPluginEnd()
{
	if(t_TimerHandle != INVALID_HANDLE)
	{
		CloseHandle(t_TimerHandle);
		t_TimerHandle = INVALID_HANDLE;
	}
}

public void OnMapStart()
{
	t_TimerHandle = CreateTimer(GetConVarFloat( g_Cvar_TimerInterval ), Timer_CheckAntiPingMask, _, DEFAULT_TIMER_FLAGS);
}

public void OnMapEnd()
{
	if(t_TimerHandle != INVALID_HANDLE)
	{
		CloseHandle(t_TimerHandle);
		t_TimerHandle = INVALID_HANDLE;
	}
}

public void OnClientAuthorized(int client, const char[] auth)
{
	CheckPingMasked(client);
}

public void TimerIntervalChanged(Handle convar, const char[] oldValue, const char[] newValue)
{
	float fOldValue, fNewValue;	
	fOldValue = StringToFloat(oldValue);
	fNewValue = StringToFloat(newValue);	
	if(fOldValue == fNewValue) return;	
	if(fNewValue <= 0) fNewValue = 20.0;
	CloseHandle(t_TimerHandle);
	t_TimerHandle = INVALID_HANDLE;
	t_TimerHandle = CreateTimer(fNewValue, Timer_CheckAntiPingMask, _, DEFAULT_TIMER_FLAGS);
}

public Action Timer_CheckAntiPingMask(Handle Timer)
{
	int _maxClients = GetMaxClients();
	
	for(int i = 1; i < _maxClients; i++)
	{
		CheckPingMasked(i);
	}
	
	return Plugin_Continue;
}

/**
 * Determines if the given command rate has invalid
 * characters other then numbers via a regular expression.
 *
 * @param CmdRate 		The current clients command rate.
 * @return 				True if command rate is valid, false otherwise.
 */
bool IsValidCmdRate(char[] CmdRate)
{
	int nMatches = SimpleRegexMatch(CmdRate, "[^\\d\\s\\.]+");
	if(nMatches >= 1) return false;
	return true;
}

/**
 * Checks the given clients cl_cmdrate for invalid characters
 * which are used to mask pings.
 *
 * @param client 		The client number to check.
 * @noreturn
 */
void CheckPingMasked(int client)
{
	if(!IsClientConnected(client) || !IsClientInGame(client) || IsFakeClient(client)) return;
	char cmdRate[32];
	GetClientInfo(client, "cl_cmdrate", cmdRate, sizeof(cmdRate));
	
	if(!IsValidCmdRate(cmdRate))
	{
		char cl_Name[64];
		GetClientName(client, cl_Name, sizeof(cl_Name));
	
		switch(GetConVarInt(g_Cvar_Handler))
		{
			case 0: // Kick Client
			{
				KickClient(client, "[Anti Ping Mask] You have been kicked for Ping Masking.\nChange value of cl_cmdrate in console and rejoin the server.\nDefault value is : cl_cmdrate 30");				
				CPrintToChatAll("{yellow}[{magenta}Anti Ping Mask{yellow}] {fullblue}%s {deeppink}was kicked for ping masking.", cl_Name);
			}			
			case 1: // Ban Client
			{
				Handle g_Cvar_SourceBans = FindConVar("sb_version");
				if(g_Cvar_SourceBans != INVALID_HANDLE)
				{
					/* Use SourceBans system. */
					ServerCommand("sm_ban #%d %d \"%s\"", GetClientUserId(client), GetConVarInt(g_Cvar_BanLength), "Ping Masking");
					CloseHandle(g_Cvar_SourceBans);
				}
				else
				{
					/* Use the normal ban system. */
					BanClient(client, GetConVarInt(g_Cvar_BanLength), BANFLAG_AUTO, "Ping Masking", "Ping Masking", "CheckPingMasked", client);
				}
				CPrintToChatAll("{yellow}[{magenta}Anti Ping Mask{yellow}] {fullblue}%s {deeppink}was banned for ping masking.", cl_Name);
			}
		}
	}
}