#include <sourcemod>
#include <sdktools>

#pragma semicolon 1
#pragma newdecls required

//Parachute Model
#define PARACHUTE_MODEL "p_cosmos"
//Parachute Textures
#define PARACHUTE_PACK "c_cosmos"
#define PARACHUTE_TEXTURE	"p_cosmos"

int g_iVelocity = -1;
int g_maxplayers = -1;

char path_model[256], path_pack[256], path_texture[256], ButtonText[256];
int x, cl_buttons, USE_BUTTON, Parachute_Ent[MAXPLAYERS+1];
float speed[3];
bool isfallspeed, inUse[MAXPLAYERS+1], hasPara[MAXPLAYERS+1], hasModel[MAXPLAYERS+1];

public Plugin myinfo =
{
	name = "SM Parachute",
	author = "SWAT_88, SuBu, Vertigo",
	description = "To use your parachute press and hold your E(+use) button while falling.",
	version = "2.5 Lite",
	url = "http://www.sourcemod.net/"
};

public void OnPluginStart()
{
	g_iVelocity = FindSendPropInfo("CBasePlayer", "m_vecVelocity[0]");
	g_maxplayers = GetMaxClients();
	
	Format(path_model,255,"models/parachute/%s",PARACHUTE_MODEL);
	Format(path_pack,255,"materials/models/parachute/%s",PARACHUTE_PACK);
	Format(path_texture,255,"materials/models/parachute/%s",PARACHUTE_TEXTURE);
	
	USE_BUTTON = IN_USE;
	ButtonText = "E";
	
	HookEvent("player_death",PlayerDeath);
}

public void OnMapStart()
{
	char path[256];	
	strcopy(path,255,path_model);
	StrCat(path,255,".mdl");
	PrecacheModel(path,true);
	strcopy(path,255,path_model);
	StrCat(path,255,".dx80.vtx");
	AddFileToDownloadsTable(path);
	strcopy(path,255,path_model);
	StrCat(path,255,".dx90.vtx");
	AddFileToDownloadsTable(path);
	strcopy(path,255,path_model);
	StrCat(path,255,".mdl");
	AddFileToDownloadsTable(path);
	strcopy(path,255,path_model);
	StrCat(path,255,".sw.vtx");
	AddFileToDownloadsTable(path);	
	strcopy(path,255,path_model);
	StrCat(path,255,".vvd");
	AddFileToDownloadsTable(path);
	strcopy(path,255,path_model);
	StrCat(path,255,".xbox.vtx");
	AddFileToDownloadsTable(path);
	strcopy(path,255,path_pack);
	StrCat(path,255,".vmt");
	AddFileToDownloadsTable(path);	
	strcopy(path,255,path_pack);
	StrCat(path,255,".vtf");
	AddFileToDownloadsTable(path);	
	strcopy(path,255,path_texture);
	StrCat(path,255,".vmt");
	AddFileToDownloadsTable(path);	
	strcopy(path,255,path_texture);
	StrCat(path,255,".vtf");
	AddFileToDownloadsTable(path);
}

public void OnEventShutdown()
{
	UnhookEvent("player_death",PlayerDeath);
}

public void OnClientPutInServer(int client)
{
	inUse[client] = false;
	hasPara[client] = false;
	hasModel[client] = false;
	g_maxplayers = GetMaxClients();
}

public void OnClientDisconnect(int client)
{
	g_maxplayers = GetMaxClients();
	CloseParachute(client);
}

public Action PlayerDeath(Handle event, const char[] name, bool dontBroadcast)
{
	int client;
	client = GetClientOfUserId(GetEventInt(event, "userid"));
	hasPara[client] = false;
	EndPara(client);
	return Plugin_Continue;
}

public void StartPara(int client, bool open)
{
	float velocity[3];
	if(g_iVelocity == -1) return;
	GetEntDataVector(client, g_iVelocity, velocity);
	
	if(velocity[2] >= -100.0)
	{
		isfallspeed = true;
	}
	
	if(velocity[2] < 0.0)
	{
		if(isfallspeed)
		{
			velocity[2] = -100.0;
		}
		else
		{
			velocity[2] = velocity[2] + 50.0;
		}
		SetEntPropVector(client, Prop_Data, "m_vecAbsVelocity", velocity);
		SetEntDataVector(client, g_iVelocity, velocity);		
		if(open) OpenParachute(client);
	}
}

public void EndPara(int client)
{
	inUse[client]=false;
	CloseParachute(client);
}

public void OpenParachute(int client)
{
	char path[256];
	strcopy(path,255,path_model);
	StrCat(path,255,".mdl");
	Parachute_Ent[client] = CreateEntityByName("prop_dynamic_override");
	DispatchKeyValue(Parachute_Ent[client],"model",path);
	SetEntityMoveType(Parachute_Ent[client], MOVETYPE_NOCLIP);
	DispatchSpawn(Parachute_Ent[client]);		
	hasModel[client]=true;
	TeleportParachute(client);
}

public void TeleportParachute(int client)
{
	if(hasModel[client] && IsValidEntity(Parachute_Ent[client]))
	{
		float Client_Origin[3], Client_Angles[3], Parachute_Angles[3] = {0.0, 0.0, 0.0};
		GetClientAbsOrigin(client,Client_Origin);
		GetClientAbsAngles(client,Client_Angles);
		Parachute_Angles[1] = Client_Angles[1];
		TeleportEntity(Parachute_Ent[client], Client_Origin, Parachute_Angles, NULL_VECTOR);
	}
}

public void CloseParachute(int client)
{
	if(hasModel[client] && IsValidEntity(Parachute_Ent[client]))
	{
		RemoveEdict(Parachute_Ent[client]);
		hasModel[client]=false;
	}
}

public void Check(int client)
{
	GetEntDataVector(client,g_iVelocity,speed);
	int cl_flags = GetEntityFlags(client);
	if(speed[2] >= 0 || (cl_flags & FL_ONGROUND)) EndPara(client);
}

public void OnGameFrame()
{
	for(x = 1; x <= g_maxplayers; x++)
	{
		if(IsClientInGame(x) && IsPlayerAlive(x))
		{
			cl_buttons = GetClientButtons(x);
			if(cl_buttons & USE_BUTTON)
			{
				if(!inUse[x])
				{
					inUse[x] = true;
					isfallspeed = false;
					StartPara(x,true);
				}
				StartPara(x,false);
				TeleportParachute(x);
			}
			else
			{
				if(inUse[x])
				{
					inUse[x] = false;
					EndPara(x);
				}
			}
			Check(x);
		}
	}
}