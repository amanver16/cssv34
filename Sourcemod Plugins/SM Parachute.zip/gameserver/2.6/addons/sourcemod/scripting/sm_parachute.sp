#include <sourcemod>
#include <sdktools>

#pragma semicolon 1
#pragma newdecls required

#define PARACHUTE_VERSION "2.6"

int g_iVelocity = -1;
int g_maxplayers = -1;
int USE_BUTTON = IN_USE;

char path_model[256], path_pack[256], path_texture[256];
ConVar g_fallspeed, g_enabled, g_linear, g_welcome, g_roundmsg, g_model, g_decrease, g_parachuteModel, g_prachuteTexture;
int x, cl_flags, cl_buttons, Parachute_Ent[MAXPLAYERS+1];
float speed[3];
bool isfallspeed, inUse[MAXPLAYERS+1], hasPara[MAXPLAYERS+1], hasModel[MAXPLAYERS+1];

public Plugin myinfo =
{
	name = "SM Parachute Lite",
	author = "SWAT_88, SuBu aka return 0; Vertigo™",
	description = "To use your parachute press and hold your E(+use) button while falling.",
	version = PARACHUTE_VERSION,
	url = "http://www.sourcemod.net/"
};

public void OnPluginStart()
{
	g_enabled = CreateConVar("sm_parachute_enabled", "1", "Enable/Disable parachute plugin.", _, true, 0.0, true, 1.0);
	g_fallspeed = CreateConVar("sm_parachute_fallspeed", "100", "Fallspeed when you use the parachute.", _, true, 0.0, true, 500.0);
	g_linear = CreateConVar("sm_parachute_linear", "1", "Enable/Disable linear fallspeed. (0 - Disabled, 1 - Enabled)", _, true, 0.0, true, 1.0);
	g_welcome = CreateConVar("sm_parachute_welcome", "1", "Enable/Disable parachute welcome message. (0 - Disabled, 1 - Enabled)", _, true, 0.0, true, 1.0);
	g_roundmsg = CreateConVar("sm_parachute_roundmsg", "1", "Enable/Disable chat messages about parachute between rounds. (0 - Disabled, 1 - Enabled)", _, true, 0.0, true, 1.0);
	g_model = CreateConVar("sm_parachute_model", "1", "Enable/disable show of the parachute model (0 - Disabled, 1 - Enabled).", _, true, 0.0, true, 500.0);
	g_decrease = CreateConVar("sm_parachute_decrease", "50", "Set the amount of realistic velocity-decrease.\n0 - Disable realistic velocity-decrease.", _, true, 0.0, true, 100.0);
	g_parachuteModel = CreateConVar("sm_parachute_pmodel", "parachute_carbon", "Specify your parachute model name.\nParachute model name is the name of your parachute .mdl file located in models/parachute folder");
	g_prachuteTexture = CreateConVar("sm_parachute_ptexture", "parachute_carbon", "Specify your parachute texture name.\nParachute texture name is the name of your parachute .vmt file located in materials/models/parachute folder");
	
	g_iVelocity = FindSendPropInfo("CBasePlayer", "m_vecVelocity[0]");
	g_maxplayers = GetMaxClients();
	
	InitModel();
	
	HookEvent("player_death",PlayerDeath);
	HookEvent("player_spawn",PlayerSpawn);

	g_enabled.AddChangeHook(CvarChange_Enabled);
	g_linear.AddChangeHook(CvarChange_Linear);
	g_model.AddChangeHook(CvarChange_Model);
	
	AutoExecConfig(true, "sm_parachute");
}

public void InitModel()
{
	char parachuteModel[256], parachuteTexture[256];
	g_parachuteModel.GetString(parachuteModel, sizeof(parachuteModel));
	g_prachuteTexture.GetString(parachuteTexture, sizeof(parachuteTexture));
	Format(path_model, sizeof(path_model) ,"models/parachute/%s",parachuteModel);
	Format(path_pack, sizeof(path_pack), "materials/models/parachute/pack");
	Format(path_texture, sizeof(path_texture),"materials/models/parachute/%s",parachuteTexture);
}

public void OnMapStart()
{
	char path[256];
	
	strcopy(path,255,path_model);
	StrCat(path,255,".mdl");
	PrecacheModel(path,true);

	strcopy(path,255,path_model);
	StrCat(path,255,".dx80.vtx");
	AddFileToDownloadsTable(path);

	strcopy(path,255,path_model);
	StrCat(path,255,".dx90.vtx");
	AddFileToDownloadsTable(path);

	strcopy(path,255,path_model);
	StrCat(path,255,".mdl");
	AddFileToDownloadsTable(path);

	strcopy(path,255,path_model);
	StrCat(path,255,".sw.vtx");
	AddFileToDownloadsTable(path);
	
	strcopy(path,255,path_model);
	StrCat(path,255,".vvd");
	AddFileToDownloadsTable(path);

	strcopy(path,255,path_model);
	StrCat(path,255,".xbox.vtx");
	AddFileToDownloadsTable(path);

	strcopy(path,255,path_pack);
	StrCat(path,255,".vmt");
	AddFileToDownloadsTable(path);
	
	strcopy(path,255,path_pack);
	StrCat(path,255,".vtf");
	AddFileToDownloadsTable(path);
	
	strcopy(path,255,path_texture);
	StrCat(path,255,".vmt");
	AddFileToDownloadsTable(path);
	
	strcopy(path,255,path_texture);
	StrCat(path,255,".vtf");
	AddFileToDownloadsTable(path);
}

public void OnEventShutdown()
{
	UnhookEvent("player_death",PlayerDeath);
	UnhookEvent("player_spawn",PlayerSpawn);
}

public void OnClientPutInServer(int client)
{
	inUse[client] = false;
	hasPara[client] = false;
	hasModel[client] = false;
	g_maxplayers = GetMaxClients();
	CreateTimer (20.0, WelcomeMsg, client);
}

public void OnClientDisconnect(int client)
{
	g_maxplayers = GetMaxClients();
	CloseParachute(client);
}

public Action PlayerSpawn(Handle event, const char[] name, bool dontBroadcast)
{
	int client;
	client = GetClientOfUserId(GetEventInt(event, "userid"));
	CreateTimer (1.0, RoundMsg, client);
	return Plugin_Continue;
}

public Action PlayerDeath(Handle event, const char[] name, bool dontBroadcast)
{
	int client;
	client = GetClientOfUserId(GetEventInt(event, "userid"));
	hasPara[client] = false;
	EndPara(client);
	return Plugin_Continue;
}

public Action RoundMsg(Handle timer, any client)
{
	if(g_roundmsg.IntValue == 1)
	{
		if(IsClientConnected (client) && IsClientInGame(client))
			PrintToChat(client,"\x01[\x04SM Parachute\x01]\x03 Press \x01E key \x04while falling to use the parachute.");
	}
	return Plugin_Continue;
}

public void StartPara(int client, bool open)
{
	float velocity[3], fallspeed;
	if (g_iVelocity == -1) return;
	if((g_enabled.IntValue== 1 && hasPara[client]) || g_enabled.IntValue == 1)
	{
		fallspeed = g_fallspeed.FloatValue*(-1.0);
		GetEntDataVector(client, g_iVelocity, velocity);
		if(velocity[2] >= fallspeed)
		{
			isfallspeed = true;
		}
		if(velocity[2] < 0.0) 
		{
			if(isfallspeed && g_linear.IntValue == 0)
			{
			}
			else if((isfallspeed && g_linear.IntValue == 1) || g_decrease.FloatValue == 0.0)
			{
				velocity[2] = fallspeed;
			}
			else
			{
				velocity[2] = velocity[2] + g_decrease.FloatValue;
			}
			TeleportEntity(client, NULL_VECTOR, NULL_VECTOR, velocity);
			SetEntDataVector(client, g_iVelocity, velocity);
			SetEntityGravity(client,0.1);
			if(open) OpenParachute(client);
		}
	}
}

public void EndPara(int client)
{
	if(g_enabled.IntValue== 1 )
	{
		SetEntityGravity(client,1.0);
		inUse[client]=false;
		CloseParachute(client);
	}
}

public void OpenParachute(int client)
{
	char path[256];
	strcopy(path,255,path_model);
	StrCat(path,255,".mdl");
	
	if(GetConVarInt(g_model) == 1)
	{
		Parachute_Ent[client] = CreateEntityByName("prop_dynamic_override");
		DispatchKeyValue(Parachute_Ent[client],"model",path);
		SetEntityMoveType(Parachute_Ent[client], MOVETYPE_NOCLIP);
		DispatchSpawn(Parachute_Ent[client]);
		
		hasModel[client]=true;
		TeleportParachute(client);
	}
}

public void TeleportParachute(int client)
{
	if(hasModel[client] && IsValidEntity(Parachute_Ent[client]))
	{
		float Client_Origin[3], Client_Angles[3], Parachute_Angles[3] = {0.0, 0.0, 0.0};
		GetClientAbsOrigin(client,Client_Origin);
		GetClientAbsAngles(client,Client_Angles);
		Parachute_Angles[1] = Client_Angles[1];
		TeleportEntity(Parachute_Ent[client], Client_Origin, Parachute_Angles, NULL_VECTOR);
	}
}

public void CloseParachute(int client)
{
	if(hasModel[client] && IsValidEntity(Parachute_Ent[client]))
	{
		RemoveEdict(Parachute_Ent[client]);
		hasModel[client]=false;
	}
}

public void Check(int client)
{
	if(g_enabled.IntValue== 1 )
	{
		GetEntDataVector(client,g_iVelocity,speed);
		cl_flags = GetEntityFlags(client);
		if(speed[2] >= 0 || (cl_flags & FL_ONGROUND)) EndPara(client);
	}
}

public void OnGameFrame()
{
	if(g_enabled.IntValue == 0) return;
	for (x = 1; x <= g_maxplayers; x++)
	{
		if (IsClientInGame(x) && IsPlayerAlive(x))
		{
			cl_buttons = GetClientButtons(x);
			if (cl_buttons & USE_BUTTON)
			{
				if (!inUse[x])
				{
					inUse[x] = true;
					isfallspeed = false;
					StartPara(x,true);
				}
				StartPara(x,false);
				TeleportParachute(x);
			}
			else
			{
				if (inUse[x])
				{
					inUse[x] = false;
					EndPara(x);
				}
			}
			Check(x);
		}
	}
}

stock int GetNextSpaceCount(char[] text, int CurIndex)
{
    int Count=0;
    int len = strlen(text);
    for(int i=CurIndex;i<len;i++)
	{
        if(text[i] == ' ') return Count;
        else Count++;
    }
    return Count;
}

public Action WelcomeMsg (Handle timer, any client)
{
	if(g_enabled.IntValue == 0) return Plugin_Continue;

	if (g_welcome.IntValue == 1 && IsClientConnected (client) && IsClientInGame (client))
	{
		PrintToChat(client,"\x01[\x04SM Parachute\x01]\x03 Welcome! This server is running SM Parachute.");
		PrintToChat(client,"\x01[\x04SM Parachute\x01]\x03 Press \x01E key \x04while falling to use the parachute.");
	}
	return Plugin_Continue;
}


public void CvarChange_Enabled(Handle cvar, const char[] oldvalue, const char[] newvalue)
{
	if (StringToInt(newvalue) == 0)
	{
		for (int client = 1; client <= g_maxplayers; client++)
		{
			if (IsClientInGame(client) && IsPlayerAlive(client))
			{
				if (hasPara[client])
				{
					SetEntityGravity(client,1.0);
					SetEntityMoveType(client,MOVETYPE_WALK);
				}
			}
		}
	}
}

public void CvarChange_Linear(Handle cvar, const char[] oldvalue, const char[] newvalue)
{
	if (StringToInt(newvalue) == 0)
	{
		for (int client = 1; client <= g_maxplayers; client++)
		{
			if (IsClientInGame(client) && IsPlayerAlive(client) && hasPara[client])
			{
				SetEntityMoveType(client,MOVETYPE_WALK);
			}
		}
	}
}

public void CvarChange_Model(Handle cvar, const char[] oldvalue, const char[] newvalue)
{
	if (StringToInt(newvalue) == 0)
	{
		for (int client = 1; client <= g_maxplayers; client++)
		{
			if (IsClientInGame(client) && IsPlayerAlive(client))
			{
				CloseParachute(client);
			}
		}
	}
}