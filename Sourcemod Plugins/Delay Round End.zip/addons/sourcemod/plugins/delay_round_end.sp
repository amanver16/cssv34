#include <sourcemod>
#include <cstrike>

#pragma semicolon 1

Handle g_hCvarNoRoundEnd, g_hCvarDelayRoundEnd;
bool g_bIgnore, g_bIgnoreStart;
float g_fDelay;

public Plugin myinfo =
{
	name = "Delay Round End",
	description = "Delays Round End for CS:S v34",
	author = "GoDtm666, Vertigo™",
	version = "1.0.1",
	url = "http://risserver.ddns.net/"
};

public void OnPluginStart()
{
	g_hCvarNoRoundEnd = CreateConVar("mp_ignore_round_win_conditions", "0", "Ignore conditions which would end the current round", 262400, true, 0.0, true, 1.0);
	HookConVarChange(g_hCvarNoRoundEnd, ConVarIgnoreRoundWin_OnSettingsChanged);
	ConVarIgnoreRoundWin_OnSettingsChanged(g_hCvarNoRoundEnd, "", "");
	g_hCvarDelayRoundEnd = CreateConVar("mp_round_restart_delay", "7.0", "Number of seconds to delay before restarting a round after a win", 262400, true, 0.0, true, 60.0);
	HookConVarChange(g_hCvarDelayRoundEnd, ConVarDelay_OnSettingsChanged);
	ConVarDelay_OnSettingsChanged(g_hCvarDelayRoundEnd, "", "");
	g_bIgnoreStart = true;
	AutoExecConfig(true, "delay_round_end");
}

public void ConVarIgnoreRoundWin_OnSettingsChanged(Handle convar, char[] oldValue, char[] newValue)
{
	g_bIgnore = GetConVarBool(convar);

	if (!g_bIgnore && g_bIgnoreStart)
	{
		CS_TerminateRound(3.0, view_as<CSRoundEndReason>(10), true);
	}
}

public void ConVarDelay_OnSettingsChanged(Handle convar, char[] oldValue, char[] newValue)
{
	g_fDelay = GetConVarFloat(convar);
}

public Action CS_OnTerminateRound(&Float:delay, &CSRoundEndReason:reason)
{
	if (g_bIgnore)
	{
		return Plugin_Handled;
	}
	switch (reason)
	{
		case 1:
		{
			CS_TerminateRound(g_fDelay, reason, true);
			return Plugin_Handled;
		}
		case 7:
		{
			CS_TerminateRound(g_fDelay, reason, true);
			return Plugin_Handled;
		}
		case 8:
		{
			CS_TerminateRound(g_fDelay, reason, true);
			return Plugin_Handled;
		}
		case 9:
		{
			CS_TerminateRound(g_fDelay, reason, true);
			return Plugin_Handled;
		}
		case 11:
		{
			CS_TerminateRound(g_fDelay, reason, true);
			return Plugin_Handled;
		}
		case 13:
		{
			CS_TerminateRound(g_fDelay, reason, true);
			return Plugin_Handled;
		}
		case 16:
		{
			CS_TerminateRound(5.0, reason, true);
			return Plugin_Handled;
		}
		default:
		{
			return Plugin_Changed;
		}
	}
	
	return Plugin_Handled;
}