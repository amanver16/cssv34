#include <sourcemod>
#include <clientmod>
#include <clientmod/multicolors>
#include <unixtime_sourcemod>

#pragma semicolon 1
#pragma newdecls required

Database g_DB;

public Plugin myinfo = 
{
    name        = "[IGN] In Game Name",
    author      = "Vertigo™",
    description = "Shows information about in game name of clients.",
    version     = "1.0",
    url         = "http://risserver.in/"
};

public void OnPluginStart()
{
	RegConsoleCmd("sm_name", Command_IGN, "Shows previous names of target.");
	RegConsoleCmd("sm_ign", Command_IGN, "Shows previous names of target.");
	RegConsoleCmd("sm_namelist", Command_IGNList, "Shows all the names used by client.");
	RegConsoleCmd("sm_ignlist", Command_IGNList, "Shows all the names used by client.");
	RegAdminCmd("sm_delign", Command_DeleteIGN, ADMFLAG_ROOT, "Deletes IGN data of a player.");
	InitializeDB();
}

public void InitializeDB()
{
	char sError[255];
	g_DB = SQL_Connect("ign", false, sError, 255);

	if(g_DB == null)
	{
		LogError("Could not connect to database. Error :: %s", sError);
	}

	SQL_LockDatabase(g_DB);

	if(!SQL_FastQuery(g_DB, "CREATE TABLE IF NOT EXISTS ign (steam_id TEXT, name TEXT, connection_time INTEGER);"))
	{
		SQL_GetError(g_DB, sError, 255);
		LogError("Could not create required Table. Error :: %s", sError);
	}

	SQL_UnlockDatabase(g_DB);
}

public void OnClientAuthorized(int iClient)
{
	if(!IsFakeClient(iClient))
	{
		char sName[100], sSteamId[100], sQuery[255];
		GetClientName(iClient, sName, 100);
		GetClientAuthId(iClient, AuthId_Engine, sSteamId, 100);
		int iLen = 2*strlen(sName) + 1;
		char[] sEscapedName = new char[iLen];
		g_DB.Escape(sName, sEscapedName, iLen);
		FormatEx(sQuery, 255, "SELECT * FROM ign WHERE steam_id='%s' AND name='%s'", sSteamId, sEscapedName);
		g_DB.Query(GetClientNameCallback, sQuery, GetClientSerial(iClient));
		FormatEx(sQuery, 255, "SELECT * FROM ign WHERE steam_id='%s' ORDER BY connection_time DESC", sSteamId);
		g_DB.Query(ShowClientNameCallback, sQuery, GetClientSerial(iClient));
	}
}

public void GetClientNameCallback(Database database, DBResultSet resultSet, const char[] sError, any clientSerial)
{
	if(database == null || resultSet == null || sError[0] != '\0')
    {
        LogError("Failed to get client information from Database. Error :: %s", sError);
    }

	int iClient = GetClientFromSerial(clientSerial);
	char sName[255], sSteamId[100], sQuery[255], sDBError[255];
	int iConnectionTime = GetTime();

	if(iClient <= 0)
	{
		return;
	}

	if(resultSet.RowCount == 0)
	{
		GetClientName(iClient, sName, 255);
		GetClientAuthId(iClient, AuthId_Engine, sSteamId, 100);
		int iLen = 2*strlen(sName) + 1;
		char[] sEscapedName = new char[iLen];
		g_DB.Escape(sName, sEscapedName, iLen);
		FormatEx(sQuery, 255, "INSERT INTO ign VALUES ('%s', '%s', %i)", sSteamId, sEscapedName, iConnectionTime);
		SQL_LockDatabase(g_DB);
		if(!SQL_FastQuery(g_DB, sQuery))
		{
			SQL_GetError(g_DB, sDBError, 255);
			LogError("Could not insert player ign details. Error :: %s", sError);
		}
		SQL_UnlockDatabase(g_DB);
	}
	else if(resultSet.RowCount > 0)
	{
		resultSet.FetchRow();
		resultSet.FetchString(0, sSteamId, 100);
		resultSet.FetchString(1, sName, 255);
		int iLen = 2*strlen(sName) + 1;
		char[] sEscapedName = new char[iLen];
		g_DB.Escape(sName, sEscapedName, iLen);
		FormatEx(sQuery, 255, "UPDATE ign SET connection_time=%i WHERE steam_id='%s' AND name='%s'", iConnectionTime, sSteamId, sEscapedName);
		SQL_LockDatabase(g_DB);
		if(!SQL_FastQuery(g_DB, sQuery))
		{
			SQL_GetError(g_DB, sDBError, 255);
			LogError("Could not update connection time. Error :: %s", sDBError);
			LogError("Query :: %s", sQuery);
		}
		SQL_UnlockDatabase(g_DB);
	}
}

public void ShowClientNameCallback(Database database, DBResultSet resultSet, const char[] sError, any clientSerial)
{
	if(database == null || resultSet == null || sError[0] != '\0')
    {
        LogError("Failed to get client information from Database. Error :: %s", sError);
    }

	int iClient = GetClientFromSerial(clientSerial);

	char sCurrentName[255], sPreviousName[255], sOldestName[255];
	GetClientName(iClient, sCurrentName, 255);

	if(resultSet.RowCount <= 1)
	{
		PrintToServer("%s connected. [Previous Name: %s] [Oldest Name: %s]", sCurrentName, sCurrentName, sCurrentName);
		MC_PrintToChatAll("{crimson}[{azure}IGN{crimson}] {yellow}%s {aqua}>>> {white}Previous Name: {fullred}%s {lime}| {white}Oldest Name: {fullred}%s", sCurrentName, sCurrentName, sCurrentName);
		C_PrintToChatAll("\x03[\x04IGN\x03] \x03%s \x01>>> \x04Previous Name: \x03%s \x01| \x04Oldest Name: \x03%s", sCurrentName, sCurrentName, sCurrentName);
	}
	else if(resultSet.RowCount == 2)
	{
		resultSet.FetchRow();
		resultSet.FetchRow();
		resultSet.FetchString(1, sPreviousName, 255);
		FormatEx(sOldestName, 255, "%s", sPreviousName);
		PrintToServer("%s connected. [Previous Name: %s] [Oldest Name: %s]", sCurrentName, sPreviousName, sOldestName);
		MC_PrintToChatAll("{crimson}[{azure}IGN{crimson}] {yellow}%s {aqua}>>> {white}Previous Name: {fullred}%s {lime}| {white}Oldest Name: {fullred}%s", sCurrentName, sPreviousName, sOldestName);
		C_PrintToChatAll("\x03[\x04IGN\x03] \x03%s \x01>>> \x04Previous Name: \x03%s \x01| \x04Oldest Name: \x03%s", sCurrentName, sPreviousName, sOldestName);
	}
	else if(resultSet.RowCount > 2)
	{
		resultSet.FetchRow();
		resultSet.FetchRow();
		resultSet.FetchString(1, sPreviousName, 255);
		while(resultSet.FetchRow())
		{
			resultSet.FetchString(1, sOldestName, 255);
		}
		PrintToServer("%s connected. [Previous Name: %s] [Oldest Name: %s]", sCurrentName, sPreviousName, sOldestName);
		MC_PrintToChatAll("{crimson}[{azure}IGN{crimson}] {yellow}%s {aqua}>>> {white}Previous Name: {fullred}%s {lime}| {white}Oldest Name: {fullred}%s", sCurrentName, sPreviousName, sOldestName);
		C_PrintToChatAll("\x03[\x04IGN\x03] \x03%s \x01>>> \x04Previous Name: \x03%s \x01| \x04Oldest Name: \x03%s", sCurrentName, sPreviousName, sOldestName);
	}
}

public Action Command_IGN(int iClient, int iArgs)
{
	int iTarget;

	if(iArgs < 1)
	{
		iTarget = iClient;
	}
	else
	{
		char sPattern[100], sBuffer[100];
		GetCmdArg(1, sPattern, 100);
		int[] iTargets = new int[MaxClients];
		bool bMl = false;
		int iCount = ProcessTargetString(sPattern, iClient, iTargets, MaxClients, COMMAND_FILTER_NO_IMMUNITY, sBuffer, 100, bMl);
		if(iCount <= 0)
		{
			MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {yellow}No player is available with that name.");
			C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04No player is available with that name.");
			return Plugin_Handled;
		}
		else if(iCount > 1)
		{
			MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {yellow}More than one player is having same name. Try more unique text phrase or user id.");
			C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04More than one player is having same name. Try more unique text phrase or user id.");
			return Plugin_Handled;
		}
		else
		{
			iTarget = iTargets[0];
		}
	}

	if(IsValidClient(iTarget) && !IsFakeClient(iTarget))
	{
		char sSteamId[50], sQuery[255];
		GetClientAuthId(iTarget, AuthId_Engine, sSteamId, 50);
		FormatEx(sQuery, 255, "SELECT * FROM ign WHERE steam_id='%s' ORDER BY connection_time DESC", sSteamId);
		g_DB.Query(GetClientNamesCallback, sQuery, GetClientSerial(iTarget));
	}
	
	return Plugin_Handled;
}

public void GetClientNamesCallback(Database database, DBResultSet resultSet, const char[] sError, any clientSerial)
{
	if(database == null || resultSet == null || sError[0] != '\0')
    {
        LogError("Failed to get client information from Database. Error :: %s", sError);
    }

	int iClient = GetClientFromSerial(clientSerial);

	if(!IsValidClient(iClient))
	{
		MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {yellow}Player has disconnected from server.");
		C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04Player has disconnected from server.");
		return;
	}

	if(resultSet.RowCount <= 1)
	{
		MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {azure}No previous name data found. This player has not changed name on this server.");
		C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04No previous name data found. This player has not changed name on this server.");
		return;
	}

	char sCurrentName[255], sPreviousName[255], sOldestName[255], sLastUsed[100], sLastUsedOld[100];
	int iTime, iYear, iMonth, iDay, iHour, iMinute, iSecond;
	int iTimeOld, iYearOld, iMonthOld, iDayOld, iHourOld, iMinuteOld, iSecondOld;
	GetClientName(iClient, sCurrentName, 255);

	if(resultSet.RowCount == 2)
	{
		resultSet.FetchRow();
		resultSet.FetchRow();
		resultSet.FetchString(1, sPreviousName, 255);
		FormatEx(sOldestName, 255, "%s", sPreviousName);
		PrintToServer("%s connected. [Previous Name: %s] [Oldest Name: %s]", sCurrentName, sPreviousName, sOldestName);
		MC_PrintToChatAll("{crimson}[{azure}IGN{crimson}] {yellow}%s {aqua}>>> {white}Previous Name: {fullred}%s {lime}| {white}Oldest Name: {fullred}%s", sCurrentName, sPreviousName, sOldestName);
		C_PrintToChatAll("\x03[\x04IGN\x03] \x03%s \x01>>> \x04Previous Name: \x03%s \x01| \x04Oldest Name: \x03%s", sCurrentName, sPreviousName, sOldestName);
	}
	else if(resultSet.RowCount > 2)
	{
		resultSet.FetchRow();
		resultSet.FetchRow();
		resultSet.FetchString(1, sPreviousName, 255);
		iTime = resultSet.FetchInt(2);
		UnixToTime(iTime, iYear, iMonth, iDay, iHour, iMinute, iSecond);
		FormatEx(sLastUsed, 100, "%02d/%02d/%d %02d:%02d:%02d", iDay, iMonth, iYear, iHour, iMinute, iSecond);
		while(resultSet.FetchRow())
		{
			resultSet.FetchString(1, sOldestName, 255);
			iTimeOld = resultSet.FetchInt(2);
		}
		UnixToTime(iTimeOld, iYearOld, iMonthOld, iDayOld, iHourOld, iMinuteOld, iSecondOld);
		FormatEx(sLastUsedOld, 100, "%02d/%02d/%d %02d:%02d:%02d", iDayOld, iMonthOld, iYearOld, iHourOld, iMinuteOld, iSecondOld);
		MC_PrintToChat(iClient, "{yellow}----------------------------------------------------");
		MC_PrintToChat(iClient, "{azure}In game name details of {fullred}%s :", sCurrentName);
		MC_PrintToChat(iClient, "{white}Previous Name: {deeppink}%s {lime}| {white}Last Used: {deeppink}%s", sPreviousName, sLastUsed);
		MC_PrintToChat(iClient, "{white}Oldest Name: {deeppink}%s {lime}| {white}Last Used: {deeppink}%s", sOldestName, sLastUsedOld);
		MC_PrintToChat(iClient, "{yellow}----------------------------------------------------");
		C_PrintToChat(iClient, "\x01----------------------------------------------------");
		C_PrintToChat(iClient, "\x04In game name details of \x03%s :", sCurrentName);
		C_PrintToChat(iClient, "\x04Previous Name\x01: \x03%s \x01| \x04Last Used\x01: \x03%s", sPreviousName, sLastUsed);
		C_PrintToChat(iClient, "\x04Oldest Name\x01: \x03%s \x01| \x04Last Used\x01: \x03%s", sOldestName, sLastUsedOld);
		C_PrintToChat(iClient, "\x01----------------------------------------------------");
	}
}

public Action Command_IGNList(int iClient, int iArgs)
{
	Menu ignListMenu = new Menu(MainMenuHandler_IGNList);
	char sSteamID[40], sName[100];
	
	for(int i=1; i <= MaxClients; i++)
	{
		if(IsValidClient(i) && !IsFakeClient(i))
		{
			GetClientName(i, sName, 100);
			GetClientAuthId(i, AuthId_Engine, sSteamID, 40);
			ignListMenu.AddItem(sSteamID, sName);
		}
	}

	ignListMenu.SetTitle("Select a Player: ");
	ignListMenu.Display(iClient, MENU_TIME_FOREVER);
	return Plugin_Handled;
}

public int MainMenuHandler_IGNList(Menu menu, MenuAction menuAction, int iParam1, int iParam2)
{
	if(menuAction == MenuAction_Select)
	{
		char sSteamID[40], sQuery[255];
		menu.GetItem(iParam2, sSteamID, 40);
		TrimString(sSteamID);
		FormatEx(sQuery, 255, "SELECT * FROM ign WHERE steam_id='%s' ORDER BY connection_time DESC", sSteamID);
		g_DB.Query(GetClientIGNListCallback, sQuery, GetClientSerial(iParam1));
	}
	else if(menuAction == MenuAction_End)
    {
        delete menu;
    }
}

public void GetClientIGNListCallback(Database database, DBResultSet resultSet, const char[] sError, any clientSerial)
{
	if(database == null || resultSet == null || sError[0] != '\0')
    {
        LogError("Failed to get client information from Database. Error :: %s", sError);
    }

	int iClient = GetClientFromSerial(clientSerial);

	if(!IsValidClient(iClient))
	{
		MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {yellow}Player has disconnected from server.");
		C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04Player has disconnected from server.");
		return;
	}

	if(resultSet.RowCount <= 1)
	{
		MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {azure}No previous name data found. This player has not changed name on this server.");
		C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04No previous name data found. This player has not changed name on this server.");
		return;
	}

	Menu ignListSubMenu = new Menu(SubMenuHandler_IGNList);
	int iTime, iYear, iMonth, iDay, iHour, iMinute, iSecond;
	char sUsedBy[100], sName[100], sLastUsed[100], sMenuData[255];
	resultSet.FetchRow();
	resultSet.FetchString(1, sUsedBy, 100);
	FormatEx(sMenuData, 255, "%s | Current", sUsedBy);
	ignListSubMenu.AddItem(sUsedBy, sMenuData, ITEMDRAW_DISABLED);

	while(resultSet.FetchRow())
	{
		resultSet.FetchString(1, sName, 100);
		iTime = resultSet.FetchInt(2);
		UnixToTime(iTime, iYear, iMonth, iDay, iHour, iMinute, iSecond);
		FormatEx(sLastUsed, 100, "%02d/%02d/%d %02d:%02d:%02d", iDay, iMonth, iYear, iHour, iMinute, iSecond);
		FormatEx(sMenuData, 255, "%s | Last Used On: %s", sName, sLastUsed);
		ignListSubMenu.AddItem(sName, sMenuData, ITEMDRAW_DISABLED);
	}

	ignListSubMenu.SetTitle("Names used by %s:", sUsedBy);
	ignListSubMenu.Display(iClient, MENU_TIME_FOREVER);
}

public int SubMenuHandler_IGNList(Menu menu, MenuAction menuAction, int iParam1, int iParam2)
{
	if(menuAction == MenuAction_End)
    {
        delete menu;
    }
}

public Action Command_DeleteIGN(int iClient, int iArgs)
{
	if(iArgs < 1)
	{
		MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {yellow}Usage : !delign <target>");
		C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04Usage : !delign <target>");
	}
	else
	{
		char sPattern[100], sBuffer[100];
		GetCmdArg(1, sPattern, 100);
		int[] iTargets = new int[MaxClients];
		bool bMl = false;
		int iCount = ProcessTargetString(sPattern, iClient, iTargets, MaxClients, COMMAND_FILTER_NO_IMMUNITY, sBuffer, 100, bMl);
		if(iCount <= 0)
		{
			MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {yellow}No player is available with that name.");
			C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04No player is available with that name.");
		}
		else if(iCount > 1)
		{
			MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {yellow}More than one player is having same name. Try more unique text phrase or user id.");
			C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04More than one player is having same name. Try more unique text phrase or user id.");
		}
		else
		{
			int iTarget = iTargets[0];
			char sSteamId[50], sQuery[255], sDBError[255];
			GetClientAuthId(iTarget, AuthId_Engine, sSteamId, 50);
			FormatEx(sQuery, 255, "DELETE FROM ign WHERE steam_id='%s'", sSteamId);
			SQL_LockDatabase(g_DB);
			if(!SQL_FastQuery(g_DB, sQuery))
			{
				SQL_GetError(g_DB, sDBError, 255);
				LogError("Could not delete player ign details. Error :: %s", sDBError);
			}
			else
			{
				MC_PrintToChat(iClient, "{crimson}[{azure}IGN{crimson}] {yellow}Successfully deleted all stored names.");
				C_PrintToChat(iClient, "\x03[\x04IGN\x03] \x04Successfully deleted all stored names.");
			}
			SQL_UnlockDatabase(g_DB);
		}
	}

	return Plugin_Handled;
}

stock bool IsValidClient(int iClient)
{
	if(iClient<=0 || iClient>MaxClients || !IsClientInGame(iClient))
	{
		return false;
	}

	return true;
}