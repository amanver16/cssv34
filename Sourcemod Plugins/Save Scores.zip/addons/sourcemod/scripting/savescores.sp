#include <sourcemod>
#include <clientprefs>
#include <morecolors>
#include <clientmod>

#include "savescores/globals.sp"
#include "savescores/cstrike.sp"

#pragma semicolon 1
#pragma newdecls required

#define PLUGIN_VERSION "2.1"

public Plugin myinfo = {
    name = "Savescores",
    author = "exvel, Vertigo™, SuBu aka return 0;",
    description = "Saves Cash and Score with ResetScore feature.",
    version = PLUGIN_VERSION,
    url = "http://risserver.ddns.net/"
};

public void OnPluginStart()
{	
	CS_Stuff();
	
	// Creating cvars
	CreateConVar("sm_save_scores_version", PLUGIN_VERSION, "Save Scores Version", FCVAR_SPONLY|FCVAR_REPLICATED|FCVAR_NOTIFY|FCVAR_DONTRECORD);
	cvar_save_scores = CreateConVar("sm_save_scores", "1", "Enable/Disable save scores functionality. (0 = off/1 = on)", 0, true, 0.0, true, 1.0);
	cvar_save_scores_tracking_time = CreateConVar("sm_save_scores_tracking_time", "0", "Amount of time in minutes to store a player score. If set to 0 the score will be tracked for the duration of the map.", 0, true, 0.0, true, 60.0);
	cvar_save_scores_forever = CreateConVar("sm_save_scores_forever", "0", "If set to 1 save scores will not clear scores on map change or round restart. Track players scores until admin will use \"sm_save_scores_reset\"", 0, true, 0.0, true, 1.0);
	cvar_save_scores_allow_reset = CreateConVar("sm_save_scores_allow_reset", "1", "Allow players to reset there scores. (0 = off/1 = on)", 0, true, 0.0, true, 1.0);
	cvar_lan = FindConVar("sv_lan");
	
	// Hooking cvar change
	cvar_lan.AddChangeHook(OnCVarChange);
	cvar_save_scores.AddChangeHook(OnCVarChange);
	cvar_save_scores_tracking_time.AddChangeHook(OnCVarChange);
	cvar_save_scores_forever.AddChangeHook(OnCVarChange);
	cvar_save_scores_allow_reset.AddChangeHook(OnCVarChange);
	
	// Hooking event
	HookEvent("player_team", Event_PlayerTeam);
	HookEvent("player_disconnect", Event_PlayerDisconnect);
	
	// Creating commands
	RegConsoleCmd("sm_rs", ResetScore, "Resets your deaths and kills back to 0.");
	RegConsoleCmd("sm_resetscore", ResetScore, "Resets your deaths and kills back to 0.");
	RegAdminCmd("sm_save_scores_reset", Command_Clear, ADMFLAG_GENERIC, "Resets all saved scores.");
	
	// Other regular stuff
	LoadTranslations("savescores.phrases");
	AutoExecConfig(true, "savescores");
	
	// Creating DB...
	InitDB();
	
	// ...and clear it
	ClearDB();
	
	// Creating timer that will save all players' scores each second if option for saving scores forever is enabled
	CreateTimer(1.0, SaveAllScores, _, TIMER_REPEAT);
}

// Here we will mark next round as a new game if needed
public void NewGameCommand(ConVar convar, const char[] oldValue, const char[] newValue)
{
	if (!save_scores || StringToInt(newValue) == 0)
	{
		return;
	}
	
	float fTimer = StringToFloat(newValue);
	
	if (isNewGameTimer)
	{
		CloseHandle(g_hNewGameTimer);
	}
	
	g_hNewGameTimer = CreateTimer(fTimer - 0.1, MarkNextRoundAsNewGame);
	isNewGameTimer = true;
} 

// Delayed action: mark next round as a new game
public Action MarkNextRoundAsNewGame(Handle timer)
{
	isNewGameTimer = false;
	g_NextRoundNewGame = true;
}

// If round is a new game we should clear DB or restore players' scores
public Action Event_NewGameStart(Event event, const char[] name, bool dontBroadcast)
{
	if (!g_NextRoundNewGame)
	{
		return Plugin_Continue;
	}
	
	g_NextRoundNewGame = false;
	ClearDB();
	
	if (!save_scores_forever || !save_scores || isLAN)
	{
		return Plugin_Continue;
	}
	
	for (int client = 1; client <= MaxClients; client++)
	{
		if (IsClientInGame(client) && !IsFakeClient(client) && !justConnected[client])
		{
			SetScore(client, g_iPlayerScore[client]);
			SetDeaths(client, g_iPlayerDeaths[client]);
			SetCash(client, g_iPlayerCash[client]);
		}
	}
	
	return Plugin_Continue;
}

// Here we will also mark next round as a new game if needed
public Action Event_RoundEnd(Event event, const char[] name, bool dontBroadcast)
{
	if (!save_scores_forever || !save_scores || isLAN)
	{
		return Plugin_Continue;
	}
	
	char szMessage[32];
	GetEventString(event, "message", szMessage, sizeof(szMessage));
	
	if (StrEqual(szMessage, "#Game_Commencing") || StrEqual(szMessage, "#Round_Draw"))
	{
		g_NextRoundNewGame = true;
	}
	
	return Plugin_Continue;
}

public void OnConfigsExecuted()
{
	GetCVars();
	
	// Set client settings menu item for resetting scores
	if (save_scores && save_scores_allow_reset && !g_isMenuItemCreated)
	{
		SetCookieMenuItem(ResetScoreInMenu, 0, "Reset Score");
		g_isMenuItemCreated = true;
	}
}

// Action that will be done when menu item will be pressed
public void ResetScoreInMenu(int client, CookieMenuAction action, any info, char[] buffer, int maxlen)
{	
	if (action == CookieMenuAction_DisplayOption)
	{
		Format(buffer, maxlen, "%T", "Reset Score", client);
		return;
	}
	
	if (!save_scores || !save_scores_allow_reset)
	{
		return;
	}
	
	SetDeaths(client, 0);
	SetScore(client, 0);
	RemoveScoreFromDB(client);
	if (CM_IsClientModUser(client))
	{
		CPrintToChat(client, "%t", "You have just reset your score");
	}
	else
	{
		PrintToChat(client, "\x01[\x03Resetscore\x01] \x04You have successfully reset your score.");
	}
}

// Player's command that resets score
public Action ResetScore(int client, int args)
{
	if (!save_scores || !save_scores_allow_reset)
	{
		return Plugin_Handled;
	}
	
	if (client > 0)
	{
		SetDeaths(client, 0);
		SetScore(client, 0);
		RemoveScoreFromDB(client);
		if (CM_IsClientModUser(client))
		{
			CPrintToChat(client, "%t", "You have just reset your score");
		}
		else
		{
			PrintToChat(client, "\x01[\x03Resetscore\x01] \x04You have successfully reset your score.");
		}
	}
	else
	{
		ReplyToCommand(client, "This command is only for players and can be used in game.");
	}
	
	return Plugin_Handled;
}

// Here we are creating SQL DB
public void InitDB()
{
	// SQL DB
	char error[255];
	g_hDB = SQLite_UseDatabase("savescores", error, sizeof(error));
	
	if (g_hDB == INVALID_HANDLE)
	{
		SetFailState("SQL error: %s", error);
	}
	
	SQL_LockDatabase(g_hDB);
	SQL_FastQuery(g_hDB, "VACUUM");
	SQL_FastQuery(g_hDB, "CREATE TABLE IF NOT EXISTS savescores_scores (steamid TEXT PRIMARY KEY, frags SMALLINT, deaths SMALLINT, money SMALLINT, timestamp INTEGER);");
	SQL_UnlockDatabase(g_hDB);
}

// Admin command that clears all player's scores
public Action Command_Clear(int admin, int args)
{
	if (!save_scores)
	{
		if (CM_IsClientModUser(admin))
		{
			CPrintToChat(admin, "%t", "Save scores disabled");
		}
		else
		{
			PrintToChat(admin, "\x01[\x03Resetscore\x01] \x04Save scores is currently disabled.");
		}
		return Plugin_Handled;
	}
	
	ClearDB(false);
	
	for (int client = 1; client <= MaxClients; client++)
	{
		if (IsClientInGame(client))
		{
			SetScore(client, 0);
			SetDeaths(client, 0);
			SetCash(client, g_CSDefaultCash);
		}
	}
	
	if (CM_IsClientModUser(admin))
	{
		CPrintToChat(admin, "%t", "Players Score Reset");
	}
	else
	{
		PrintToChat(admin, "\x01[\x03Resetscore\x01] \x04All the players score has been reset successfully.");
	}
	
	return Plugin_Handled;
}

// Just clear DB. Sometimes we need it to be delayed.
void ClearDB(bool Delay = true)
{
	if (Delay)
	{
		CreateTimer(0.1, ClearDBDelayed);
	}
	else
	{
		ClearDBQuery();
	}
}

// ...the same as above but delayed
public Action ClearDBDelayed(Handle timer)
{
	if (!save_scores_forever)
	{
		ClearDBQuery();
	}
}

// Doing clearing stuff
void ClearDBQuery()
{
	// Clearing SQL DB
	SQL_LockDatabase(g_hDB);
	SQL_FastQuery(g_hDB, "DELETE FROM savescores_scores;");
	SQL_UnlockDatabase(g_hDB);
}

// Marking native functions
public APLRes AskPluginLoad2(Handle myself, bool late, char[] error, int err_max)
{
	MarkNativeAsOptional("OnCalcPlayerScore");
	return APLRes_Success;
}

public void OnMapStart()
{
	// Clear DB
	ClearDB();
}



// If options for saving scores forever is set we will save player's score every second
public Action SaveAllScores(Handle timer)
{
	if (!save_scores_forever || !save_scores || isLAN)
	{
		return Plugin_Continue;
	}
	
	for (int client = 1; client <= MaxClients; client++)
	{
		if (IsClientInGame(client) && !IsFakeClient(client) && IsClientAuthorized(client) && !justConnected[client])
		{
			g_iPlayerScore[client] = GetScore(client);
			g_iPlayerDeaths[client] = GetDeaths(client);
			g_iPlayerCash[client] = GetCash(client);
		}
	}
	
	return Plugin_Continue;
}

// Syncronize DB with score varibles
public void SyncDB()
{
	for (int client = 1; client <= MaxClients; client++)
	{
		if (IsClientInGame(client) && !IsFakeClient(client) && IsClientAuthorized(client))
		{
			char steamId[30], query[200];
			GetClientAuthId(client, AuthId_Engine, steamId, sizeof(steamId));
			int frags = GetScore(client);
			int deaths = GetDeaths(client);
			int cash = GetCash(client);
			Format(query, sizeof(query), "INSERT OR REPLACE INTO savescores_scores VALUES ('%s', %d, %d, %d, %d);", steamId, frags, deaths, cash, GetTime());
			SQL_FastQuery(g_hDB, query);
		}
	}
}

// Most of the score manipulations will be done in this event
public Action Event_PlayerTeam(Event event, const char[] name, bool dontBroadcast)
{
	int client = GetClientOfUserId(GetEventInt(event, "userid"));
	
	if (!client || isLAN || !save_scores)
	{
		return Plugin_Continue;
	}
	
	if (IsFakeClient(client) || !IsClientInGame(client))
	{
		return Plugin_Continue;
	}
	
	// Player joined spectators and he already played so we will save his scores. Actually we need only cash but nevermind.
	if (GetEventInt(event, "team") == 1 && save_scores_css_spec_cash && !justConnected[client])
	{
		InsertScoreInDB(client);
		return Plugin_Continue;
	}
	// Player returned to the team from spectators. Lets set his cash back.
	else if (GetEventInt(event, "team") > 1 && GetEventInt(event, "oldteam") < 2 && save_scores_css_spec_cash && !justConnected[client])
	{
		onlyCash[client] = false;
		GetScoreFromDB(client);
	}
	// Player just connected and joined team
	else if (justConnected[client] && GetEventInt(event, "team") != 1)
	{
		justConnected[client] = false;
		GetScoreFromDB(client);
	}
	
	return Plugin_Continue;
}

// Get player's score
public int GetScore(int client)
{
	return GetClientFrags(client);
}

// Set player's score
public void SetScore(int client, int score)
{
	SetEntProp(client, Prop_Data, "m_iFrags", score);
}

// If game is not TF we will set player's death count
public void SetDeaths(int client, int deaths)
{
	SetEntProp(client, Prop_Data, "m_iDeaths", deaths);
}

// Get player's death count or return 0 if it is TF
public int GetDeaths(int client)
{
	return GetEntProp(client, Prop_Data, "m_iDeaths");
}

// Here we will put player's score into DB
public Action Event_PlayerDisconnect(Event event, const char[] name, bool dontBroadcast)
{
	int client = GetClientOfUserId(GetEventInt(event, "userid"));
	justConnected[client] = true;
	onlyCash[client] = false;
	
	if (!client || isLAN || !save_scores || !IsClientInGame(client) || IsFakeClient(client))
	{
		return;
	}
	
	InsertScoreInDB(client);
}


void InsertScoreInDB(int client)
{
	char steamId[30];
	int cash = 0;
	GetClientAuthId(client, AuthId_Engine, steamId, sizeof(steamId));
	int frags = GetScore(client);
	int deaths = GetDeaths(client);
	cash = GetCash(client);

	// Do not save scores if there are zero scores and default cash
	if(frags == 0 && deaths == 0 && cash == g_CSDefaultCash)
	{
		return;
	}

	InsertScoreQuery(steamId, frags, deaths, cash);
}

void InsertScoreQuery(const char[] steamId, int frags, int deaths, int cash)
{
	char query[200];
	Format(query, sizeof(query), "INSERT OR REPLACE INTO savescores_scores VALUES ('%s', %d, %d, %d, %d);", steamId, frags, deaths, cash, GetTime());
	SQL_TQuery(g_hDB, EmptySQLCallback, query);
}

// Now we need get this information back...
public void GetScoreFromDB(int client)
{
	if (!IsClientInGame(client))
	{
		onlyCash[client] = false;
		return;
	}
	
	char steamId[30], query[200];
	GetClientAuthId(client, AuthId_Engine, steamId, sizeof(steamId));
	Format(query, sizeof(query), "SELECT * FROM	savescores_scores WHERE steamId = '%s';", steamId);
	SQL_TQuery(g_hDB, SetPlayerScore, query, client);
}

public void OnMapEnd()
{
	if (save_scores_forever && save_scores && !isLAN)
	{
		SyncDB();
	}
}

// ...and set player's score and cash if needed
public void SetPlayerScore(Handle owner, Handle hndl, const char[] error, any client)
{
	if (hndl == INVALID_HANDLE)
	{
		LogError("SQL Error: %s", error);
		onlyCash[client] = false;
		return;
	}
	
	if (SQL_GetRowCount(hndl) == 0)
	{
		onlyCash[client] = false;
		return;
	}
	
	if (!IsClientInGame(client))
	{
		onlyCash[client] = false;
		return;
	}
	
	// If tracking time < time from DB and client didn't played after connection then remove score
	if ((save_scores_tracking_time * 60 < (GetTime() - SQL_FetchInt(hndl,4))) && save_scores_tracking_time != 0 && !onlyCash[client])
	{
		if (!save_scores_forever)
		{
			RemoveScoreFromDB(client);
			return;
		}
	}

	int score = SQL_FetchInt(hndl,1);
	int deaths = SQL_FetchInt(hndl,2);
	
	// Restore player's score if client didn't played after connection
	if (save_scores && !onlyCash[client])
	{
		if (score != 0 || deaths != 0)
		{
			SetScore(client, score);
			SetDeaths(client, deaths);
			if(CM_IsClientModUser(client))
			{
				CPrintToChat(client, "%t", "Score restored");
			}
			else
			{
				PrintToChat(client, "Your old score has been reloaded.");
			}
		}
	}
		
	// Restore client cash
	if (save_scores_css_cash && save_scores)
	{
		int cash = SQL_FetchInt(hndl,3);
		SetCash(client, cash);
		if(CM_IsClientModUser(client))
		{
			CPrintToChat(client, "%t", "Cash restored", cash);
		}
		else
		{
			PrintToChat(client, "Cash restored to $%d", cash);
		}
	}
	
	onlyCash[client] = false;
	
	if (!save_scores_forever)
	{
		RemoveScoreFromDB(client);
	}
}


// Removes player's score from DB
public void RemoveScoreFromDB(int client)
{
	char query[200], steamId[30];
	GetClientAuthId(client, AuthId_Engine, steamId, sizeof(steamId));
	Format(query, sizeof(query), "DELETE FROM savescores_scores WHERE steamId = '%s';", steamId);
	SQL_TQuery(g_hDB, EmptySQLCallback, query);
}

public void EmptySQLCallback(Handle owner, Handle hndl, const char[] error, any data)
{
	if (hndl == INVALID_HANDLE)
	{
		LogError("SQL Error: %s", error);
	}
}

public void OnCVarChange(ConVar convar_hndl, const char[] oldValue, const char[] newValue)
{
	GetCVars();
}

// Getting data from CVars and putting it into plugin's varibles
void GetCVars()
{
	isLAN = cvar_lan.BoolValue;
	save_scores = cvar_save_scores.BoolValue;
	save_scores_tracking_time = cvar_save_scores_tracking_time.IntValue;
	save_scores_forever = cvar_save_scores_forever.BoolValue;
	save_scores_allow_reset = cvar_save_scores_allow_reset.BoolValue;
	save_scores_css_cash = cvar_save_scores_css_cash.BoolValue;
	save_scores_css_spec_cash = cvar_save_scores_css_spec_cash.BoolValue;
	g_CSDefaultCash = cvar_startmoney.IntValue;
}