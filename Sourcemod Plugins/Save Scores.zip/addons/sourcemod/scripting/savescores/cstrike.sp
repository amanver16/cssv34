// CVars' handles
ConVar cvar_save_scores_css_cash;
ConVar cvar_save_scores_css_spec_cash;
ConVar cvar_startmoney;

// Cvars' variables
bool save_scores_css_cash = true;
bool save_scores_css_spec_cash = true;
int g_CSDefaultCash = 800;

// Offsets
int g_iAccount = -1;

// Loading CS stuff on plugin start
public void CS_Stuff()
{
	// Creating cvars
	cvar_save_scores_css_cash = CreateConVar("sm_save_scores_css_cash", "1", "If set to 1 the save scores will also restore player's cash. (0 = off/1 = on)", 0, true, 0.0, true, 1.0);
	cvar_save_scores_css_spec_cash = CreateConVar("sm_save_scores_css_spec_cash", "1", "If set to 1 the save scores will save spectator's cash and restore it after thry join team. (0 = off/1 = on)", 0, true, 0.0, true, 1.0);
	cvar_startmoney = FindConVar("mp_startmoney");
	
	// Hooking cvar change
	cvar_save_scores_css_cash.AddChangeHook(OnCVarChange);
	cvar_save_scores_css_spec_cash.AddChangeHook(OnCVarChange);
	cvar_startmoney.AddChangeHook(OnCVarChange);
	
	// Finding offset for CS cash
	g_iAccount = FindSendPropInfo("CCSPlayer", "m_iAccount");
	
	if (g_iAccount == -1)
	{
		SetFailState("m_iAccount offset not found");
	}
	
	// Hooking command for detecting of new game start
	cvar_restartgame = FindConVar("mp_restartgame");
	
	if (cvar_restartgame != INVALID_HANDLE)
	{
		cvar_restartgame.AddChangeHook(NewGameCommand);
	}
	
	// Hooking events for detecting of new game start
	HookEvent("round_start", Event_NewGameStart);
	HookEvent("round_end", Event_RoundEnd);
}

// Set player's cash
public void SetCash(client, cash)
{
	SetEntData(client, g_iAccount, cash, 4, true);
}

// Simply get player's cash
public int GetCash(client)
{
	return GetEntData(client, g_iAccount);
}