// CVars' handles
ConVar cvar_save_scores;
ConVar cvar_save_scores_tracking_time;
ConVar cvar_save_scores_forever;
ConVar cvar_save_scores_allow_reset;
ConVar cvar_lan;

// Commands' handles
ConVar cvar_restartgame;

// Cvars' variables
bool save_scores = true;
int save_scores_tracking_time = 20;
bool save_scores_forever = false;
bool save_scores_allow_reset = true;
bool isLAN = false;

// DB handle
Handle g_hDB = INVALID_HANDLE;

// Other stuff
bool onlyCash[MAXPLAYERS+1] = {false, ...};
bool justConnected[MAXPLAYERS+1] = {true, ...};
bool isNewGameTimer = false;
Handle g_hNewGameTimer = INVALID_HANDLE;
bool g_NextRoundNewGame = false;
bool g_isMenuItemCreated = false;

// Players info
int g_iPlayerScore[MAXPLAYERS+1];
int g_iPlayerDeaths[MAXPLAYERS+1];
int g_iPlayerCash[MAXPLAYERS+1];