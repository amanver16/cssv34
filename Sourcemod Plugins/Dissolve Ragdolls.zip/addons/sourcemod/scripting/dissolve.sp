#include <sourcemod>
#include <sdktools>

#pragma semicolon 1
#pragma newdecls required

#define PLUGIN_VERSION "1.0.0.2"

ConVar cvDelay, cvType;

public Plugin myinfo = {
  name = "Dissolve Ragdolls",
	author = "L. Duke, Vertigo™",
	description = "Dissolves dead bodies (Player Ragdolls) with nice effects.",
	version = PLUGIN_VERSION,
	url = "http://risserver.ddns.net/"
};

public void OnPluginStart() 
{ 
  CreateConVar("sm_dissolve_version", PLUGIN_VERSION, "Dissolve", FCVAR_SPONLY|FCVAR_REPLICATED|FCVAR_NOTIFY);
  cvDelay = CreateConVar("sm_dissolve_delay", "2", "Delay in seconds before the ragdoll dissolves.", _, true, 0.0);
  cvType = CreateConVar("sm_dissolve_type", "0", "Dissolve Type\n0 - Ragdoll rises from ground while dissolving.\n1 or 2 - Ragdoll dissolves on the ground.\n3 - Ragdoll dissolves faster.", _, true, 0.0, true, 3.0);
  HookEvent("player_death", PlayerDeath);
  AutoExecConfig(true, "dissolve");
}

public void OnEventShutdown()
{
	UnhookEvent("player_death", PlayerDeath);
}

public Action PlayerDeath(Handle event, const char[] name, bool dontBroadcast)
{
  int client;
  client = GetClientOfUserId(GetEventInt(event, "userid"));
  float delay = cvDelay.FloatValue;
  
  if(delay > 0.0)
  {
    CreateTimer(delay, Dissolve, client); 
  }
  else
  {
    Dissolve(INVALID_HANDLE, client);
  }
  
  return Plugin_Continue;
}

public Action Dissolve(Handle timer, any client)
{
  if(!IsValidEntity(client))
  {
    return;
  }
    
  int ragdoll = GetEntPropEnt(client, Prop_Send, "m_hRagdoll");

  if(ragdoll < 0)
  {
    return;
  }
    
  char dname[32], dtype[32];
  Format(dname, sizeof(dname), "dis_%d", client);
  Format(dtype, sizeof(dtype), "%d", cvType.IntValue);
  int ent = CreateEntityByName("env_entity_dissolver");
  
  if(ent > 0)
  {
    DispatchKeyValue(ragdoll, "targetname", dname);
    DispatchKeyValue(ent, "dissolvetype", dtype);
    DispatchKeyValue(ent, "target", dname);
    AcceptEntityInput(ent, "Dissolve");
    AcceptEntityInput(ent, "kill");
  }
}