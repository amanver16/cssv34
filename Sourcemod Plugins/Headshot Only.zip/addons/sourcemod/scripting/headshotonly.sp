#include <sourcemod>
#include <sdktools>

#pragma semicolon 1
#pragma newdecls required

#define VERSION "1.0.2"

public Plugin myinfo =
{
  name = "Headshot Only",
	author = "XARiUS, Vertigo™",
	description = "Plugin which prevents all damage but headshots.",
	version = VERSION,
	url = "http://risserver.ddns.net/"
};

char g_headsounds[256];
char headsounds[5][256];
bool g_enabled;
bool g_useambient;
int soundsfound;
ConVar g_Cvarenabled;
ConVar g_Cvarheadsounds;
ConVar g_Cvaruseambient;
int g_iHealth, g_Armor;

public void OnPluginStart()
{
  LoadTranslations("headshotonly.phrases");

  CreateConVar("sm_headshotonly_version", VERSION, "Headshot Only", FCVAR_SPONLY|FCVAR_REPLICATED|FCVAR_NOTIFY|FCVAR_DONTRECORD);
  g_Cvarenabled = CreateConVar("sm_headshotonly_enabled", "1", "Enable/disable this plugin. (0 = Disabled, 1 = Enabled)", 0, true, 0.0, true, 1.0);
  g_Cvarheadsounds = CreateConVar("sm_headshotonly_sounds", "", "Sound files to indicate headshots separated by comma. Leave blank for default sounds. (Maximum: 5 sounds)\nExample:headshotonly/headshot1.wav,headshotonly/headshot2.wav");
  g_Cvaruseambient = CreateConVar("sm_headshotonly_useambient", "0", "Emit sounds from victim to all players.  0 = Emit sound from victim only to attacker.", 0, true, 0.0, true, 1.0);

  g_Cvarenabled.AddChangeHook(OnSettingChanged);
  g_Cvaruseambient.AddChangeHook(OnSettingChanged);

  HookEvent("player_hurt", EventPlayerHurt, EventHookMode_Pre);
  AutoExecConfig(true, "headshotonly");

  g_iHealth = FindSendPropInfo("CCSPlayer", "m_iHealth");

  if(g_iHealth == -1)
  {
    SetFailState("[Headshot Only] Error - Unable to get offset for CSSPlayer::m_iHealth");
  }

  g_Armor = FindSendPropInfo("CCSPlayer", "m_ArmorValue");

  if(g_Armor == -1)
  {
    SetFailState("[Headshot Only] Error - Unable to get offset for CSSPlayer::m_ArmorValue");
  }
}

public void OnConfigsExecuted()
{
  g_enabled = g_Cvarenabled.BoolValue;
  g_useambient = g_Cvaruseambient.BoolValue;
  GetConVarString(g_Cvarheadsounds, g_headsounds, sizeof(g_headsounds));
  
  if(!StrEqual(g_headsounds, "", false))
  {
    char buffer[256];
    soundsfound = ExplodeString(g_headsounds, ",", headsounds, 5, 64);
    if(soundsfound > 0)
    {
      for(int i = 0; i <= soundsfound-1; i++)
      {
        Format(buffer, PLATFORM_MAX_PATH, "headshotonly/%s", headsounds[i]);
        if(!PrecacheSound(buffer, true))
        {
          SetFailState("HeadShot Only: Could not pre-cache sound: %s", buffer);
        }
        else
        {
          Format(buffer, PLATFORM_MAX_PATH, "sound/headshotonly/%s", headsounds[i]);
          AddFileToDownloadsTable(buffer);
          buffer = "headshotonly/";
          StrCat(buffer, sizeof(buffer), headsounds[i]);
          headsounds[i] = buffer;
        }
      }
    }
    return;
  }

  soundsfound = 5;
  headsounds[0] = "physics/flesh/flesh_squishy_impact_hard1.wav";
  headsounds[1] = "physics/flesh/flesh_squishy_impact_hard2.wav";
  headsounds[2] = "physics/flesh/flesh_squishy_impact_hard3.wav";
  headsounds[3] = "physics/flesh/flesh_squishy_impact_hard4.wav";
  headsounds[4] = "physics/flesh/flesh_bloody_break.wav";
  PrecacheSound(headsounds[0], true);
  PrecacheSound(headsounds[1], true);
  PrecacheSound(headsounds[2], true);
  PrecacheSound(headsounds[3], true);
  PrecacheSound(headsounds[4], true);
}

public void OnSettingChanged(ConVar convar, const char[] oldValue, const char[] newValue)
{
  if(convar == g_Cvarenabled)
  {
    if(newValue[0] == '1')
    {
			g_enabled = true;
			PrintHintTextToAll("%t", "Headshot enabled");
			EmitSoundToAll("player/bhit_helmet-1.wav");
    }
    else
    {
      g_enabled = false;
      PrintHintTextToAll("%t", "Headshot disabled");
      EmitSoundToAll("player/bhit_helmet-1.wav");
    }
  }

  if(convar == g_Cvaruseambient)
  {
    if(newValue[0] == '1')
    {
			g_useambient = true;
    }
    else
    {
      g_useambient = false;
    }
  }
}

public Action EventPlayerHurt(Event event, const char[] name, bool dontBroadcast)
{
  if(g_enabled)
  {
    int hitgroup = GetEventInt(event, "hitgroup");
    int victim = GetClientOfUserId(GetEventInt(event, "userid"));
    int attacker = GetClientOfUserId(GetEventInt(event, "attacker"));
    int dhealth = GetEventInt(event, "dmg_health");
    int darmor = GetEventInt(event, "dmg_armor");
    int health = GetEventInt(event, "health");
    int armor = GetEventInt(event, "armor");

    if(hitgroup == 1)
    {
      if(g_useambient)
      {
        float vicpos[3];
        GetClientEyePosition(victim, vicpos);
        EmitAmbientSound(headsounds[GetRandomInt(0, soundsfound -1)], vicpos, victim, SNDLEVEL_GUNFIRE);
      }
      else
      {
        if(attacker > 0)
        {
          EmitSoundToClient(attacker, headsounds[GetRandomInt(0, soundsfound -1)], SOUND_FROM_PLAYER, SNDCHAN_AUTO, SNDLEVEL_RAIDSIREN);
        }
      }
      return Plugin_Continue;
    }
    else if(attacker != victim && victim != 0 && attacker != 0)
    {
      if(dhealth > 0)
      {
        SetEntData(victim, g_iHealth, (health + dhealth), 4, true);
      }
      if(darmor > 0)
      {
        SetEntData(victim, g_Armor, (armor + darmor), 4, true);
      }
    }
  }

  return Plugin_Continue;
}
