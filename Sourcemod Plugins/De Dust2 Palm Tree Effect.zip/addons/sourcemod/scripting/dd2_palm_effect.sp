#include <sourcemod>
#include <sdktools>

#pragma semicolon 1
#pragma newdecls required

int PrecB, wS_color[4];
Handle wS_Timer;

float wS_vec[8][3] =
{
	{
		-988286485.0, -1004567075.0, 1143751838.0
	},
	{
		-991094388.0, 1139243467.0, 1141286388.0
	},
	{
		-995034729.0, 1139252654.0, 1141307535.0
	},
	{
		-999798643.0, 1159235683.0, 1139113850.0
	},
	{
		1155243279.0, 1155779170.0, 1141979588.0
	},
	{
		1148941378.0, 1131314330.0, 1141394413.0
	},
	{
		1138317743.0, -1012278602.0, 1141095078.0
	},
	{
		-1016281523.0, 1142642002.0, 1141361500.0
	}
};

public Plugin myinfo =
{
	name = "DD2 Palm Tree Effect",
	description = "Adds beautiful light effect on de_dust2 palm trees.",
	author = "wS (Schmidt), Vertigo™",
	version = "1.1",
	url = "http://world-source.ru/"
};

public void OnPluginStart()
{
	wS_color[3] = 255;
}

public void OnMapStart()
{
	char wS_map[16];
	GetCurrentMap(wS_map, 15);
	if (StrEqual(wS_map, "de_dust2", false))
	{
		PrecB = PrecacheModel("materials/sprites/laser.vmt", true);
		wS_Effect();
	}
}

public void OnMapEnd()
{
	wS_StopTimer();
}

void wS_Effect()
{
	wS_GetRandomColor();
	int i = 0;
	while (i < 8)
	{
		TE_SetupBeamRingPoint(wS_vec[i], 10.0, 65.0, PrecB, PrecB, 0, 0, 10.0, 99.0, 0.0, wS_color, 45, 0);
		TE_SendToAll(0.0);
		i++;
	}
	wS_Timer = CreateTimer(10.0, wS_Timer_Effect, view_as<any>(0), 0);
}

public Action wS_Timer_Effect(Handle timer)
{
	wS_Effect();
	return Plugin_Continue;
}

void wS_GetRandomColor()
{
	int i=0;
	while (i < 3)
	{
		wS_color[i] = GetRandomInt(10, 255);
		i++;
	}
}

public void OnPluginEnd()
{
	wS_StopTimer();
}

void wS_StopTimer()
{
	if (wS_Timer)
	{
		KillTimer(wS_Timer, false);
		wS_Timer = null;
	}
}

