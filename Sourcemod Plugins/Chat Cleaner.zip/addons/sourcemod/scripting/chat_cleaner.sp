#include <sourcemod>

#pragma semicolon 1
#pragma newdecls required

ConVar g_enable, g_connect, g_disconnect, g_team, g_cvar, g_connectCM;

public Plugin myinfo =
{
	name = "Chat Cleaner",
	author = "Vertigo™, Reg1oxeN",
	description = "Cleans up extra messages from chat area.",
	version = "1.0",
	url = "http://risserver.ddns.net/"
};

public void OnPluginStart()
{
	CreateConVar("sm_chatcleaner_version", "1.0", "Chat Cleaner Version", FCVAR_SPONLY|FCVAR_REPLICATED|FCVAR_NOTIFY);
	
	g_enable = CreateConVar("sm_chatcleaner_enable", "1", "Enable/Disable Chat Cleaner. (0 - Disabled, 1 - Enabled)", _, true, 0.0, true, 1.0);
	g_connect = CreateConVar("sm_chatcleaner_connect", "1", "Enable/Disable Connect Announce Messages. (0 - Disabled, 1 - Enabled)", _, true, 0.0, true, 1.0);
	g_disconnect = CreateConVar("sm_chatcleaner_disconnect", "1", "Enable/Disable Disconnect Announce Messages. (0 - Disabled, 1 - Enabled)", _, true, 0.0, true, 1.0);
	g_team = CreateConVar("sm_chatcleaner_team", "1", "Enable/Disable Team Join Messages. (0 - Disabled, 1 - Enabled)", _, true, 0.0, true, 1.0);
	g_cvar = CreateConVar("sm_chatcleaner_cvar", "1", "Enable/Disable CVAR Change Messages. (0 - Disabled, 1 - Enabled)", _, true, 0.0, true, 1.0);
	g_connectCM = CreateConVar("sm_chatcleaner_connect_cm", "1", "Enable/Disable ClientMod Connect Announce Message. (0 - Disabled, 1 - Enabled)", _, true, 0.0, true, 1.0);
	
	HookEvent("player_connect", Event_Connect, EventHookMode_Pre);
	HookEvent("player_disconnect", Event_Disconnect, EventHookMode_Pre);
	HookEvent("player_team", Event_TeamJoin, EventHookMode_Pre);
	HookEvent("server_cvar", Event_CvarChange, EventHookMode_Pre);
	HookUserMessage(GetUserMessageId("TextMsg"), MessageHandler, true); // #Game_connected 
	
	AutoExecConfig(true, "chat_cleaner");
}

public Action Event_Connect(Handle event, const char[] name, bool dontBroadcast)
{
	if(g_enable.IntValue && g_connect.IntValue)
	{
		SetEventBroadcast(event, true);
	}	
	return Plugin_Continue;
}

public Action Event_Disconnect(Handle event, const char[] name, bool dontBroadcast)
{
	if(g_enable.IntValue && g_disconnect.IntValue)
	{
		SetEventBroadcast(event, true);
	}
	return Plugin_Continue;
}

public Action Event_TeamJoin(Handle event, const char[] name, bool dontBroadcast)
{
	if(g_enable.IntValue && g_team.IntValue)
	{
		if(!GetEventBool(event, "silent"))
		{
			SetEventBroadcast(event, true);
		}
	}
	return Plugin_Continue;
}

public Action Event_CvarChange(Handle event, const char[] name, bool dontBroadcast)
{
	if(g_enable.IntValue && g_cvar.IntValue)
	{
		SetEventBroadcast(event, true);
	}
	return Plugin_Continue;
}

// To block ClientMod special "Client Entered the game" Message
public Action MessageHandler(UserMsg msg_id, Handle bf, const players[], int playersNum, bool reliable, bool init)
{
	if(g_enable.IntValue && g_connectCM.IntValue)
	{
		if (BfReadByte(bf) == 1)
		{
			char message[256];
			// Catch #Game_connected
			if (BfReadString(bf, message, sizeof(message)) == 15 && message[0] == '#' && message[1] == 'G' && message[6] == 'c')
			{
				return Plugin_Handled;
			}
		}
	}
	return Plugin_Continue;
}