#include <sourcemod>
#include <sdktools>

public Plugin myinfo =
{
	name = "AWP LEGO 2 TOWER BLOCKER",
	author = "Danyas (private), Vertigo", // New Syntax + Code Optimization
	description = "Blocks players from climbing the tower in awp lego 2 map.",
	version = "1.0",
	url = "vertigocss@gmail.com"
};

static char sModel[] = "models/props/de_inferno/de_inferno_boulder_01.mdl";
char sMap[32];

public void OnMapStart()
{
	if(!IsModelPrecached(sModel)) PrecacheModel(sModel);	
	GetCurrentMap(sMap, sizeof(sMap));	
	if(StrEqual(sMap, "awp_lego_2")) HookEvent("round_start", Event_RoundStart);
}

public void Event_RoundStart(Handle event, const char[] name, bool silent)
{
	if(!StrEqual(sMap, "awp_lego_2")) UnhookEvent("round_start", Event_RoundStart);	
	int entity = CreateEntityByName("prop_dynamic_override");

	if(entity != -1)
	{
		SetEntityModel(entity, sModel);
		DispatchKeyValue(entity, "Solid", "6");
		DispatchSpawn(entity);
		TeleportEntity(entity, Float:{-25.0, 33.0, -168.0}, NULL_VECTOR, NULL_VECTOR);
	}
}